# Package Content Source Stats — Antigence publication

- Generated: `2026-08-04T02:53:21+00:00`
- Package status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:d1471fee5bd961f2444c5c74a118cc5bd3e2a52052793c93cf165367f69bd17d`
- Files analyzed: `43`
- Nonblank lines: `3310`
- Knowledge-atom lines: `456` (13.78%)
- Seed-of-truth lines: `475` (14.35%)
- Frontier/inference prose lines: `2379` (71.87%)

## Deterministic Classification

- `knowledge_atom`: lexical evidence anchors such as hashes, receipts, EXP IDs, manifests, seals, PASS/FAIL/ABSTAIN rows, DOI/PMID/Zenodo/accession references.
- `seed_of_truth`: source/citation/provenance/SeedGraph/operator-decision lines that identify origin material but are not themselves the terminal atom.
- `frontier_inference`: unanchored explanatory prose, interpretation, recommendations, limitations, and Codex/assistant-authored synthesis.

## Deposit Boundary

- Local package is ready for operator review as a private/staged package.
- No public upload, live KG writeback, claim promotion, or visibility switch was performed by this script.

## Highest-Inference Files

| File | Nonblank | Atom | Seed | Inference |
|---|---:|---:|---:|---:|
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/corruption_summary.json` | 27 | 0 | 0 | 27 |
| `experiments/antigence_hierarchy_fcg/runs/20260709T131812Z/model_celltype_training_map.json` | 161 | 1 | 0 | 160 |
| `experiments/antigence_hierarchy_fcg/runs/20260709T131812Z/publication_stats.json` | 274 | 1 | 2 | 271 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/extract_manifest.json` | 154 | 1 | 1 | 152 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/poison_mechanism_leaf.json` | 89 | 0 | 2 | 87 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/testset_summary.json` | 36 | 1 | 0 | 35 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/detectors_summary.json` | 21 | 1 | 0 | 20 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/CUSTODY_MANIFEST.json` | 64 | 4 | 0 | 60 |
| `experiments/antigence_hierarchy_fcg/runs/20260709T131812Z/ollarma_fco_seal.json` | 46 | 3 | 0 | 43 |
| `experiments/antigence_hierarchy_fcg/runs/20260710T223016Z/ollarma_fco_seal.json` | 46 | 3 | 0 | 43 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/antigence_result/ollarma_fco_seal.json` | 46 | 3 | 0 | 43 |
| `experiments/antigence_hierarchy_fcg/runs/fco007_build_20260710/antigence_result/receipt.json` | 199 | 12 | 1 | 186 |
