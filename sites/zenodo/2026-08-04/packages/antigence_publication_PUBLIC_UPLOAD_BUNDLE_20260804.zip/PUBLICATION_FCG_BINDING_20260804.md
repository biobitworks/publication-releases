# Publication FCG Binding — Antigence publication

- Status: `PASS_WITH_NONSHIPPING_LIMITATIONS`
- Binding leaf: `sha256:caa1245592ec963b5ad133f7b295a0920fda08f1719efad30e388f6b83cdba60`
- Claim ceiling: `SOFTWARE_GOVERNANCE_AND_CUSTODY_ONLY`
- Live KG writeback: `False`
- External upload: `False`
- New scientific claims authored: `False`

## Copied Source Assets

- `antigence_zenodo_preprint_v2.fcg.json` ← `/Users/byron/projects/active/gtm-cellico/PUBLICATION_SEQUENCING/packages/antigence-v2/history/outbox-archive/260717-antigence-preprint-v2-zenodo-update/antigence_zenodo_preprint_v2.fcg.json` sha256 `ca3f0564680d7fde61d1949be37faffc2eefbc35de434ad0f2eac8cc36baee5a`
- `publication_backbone.fcg.json` ← `/Users/byron/projects/active/gtm-cellico/PUBLICATION_SEQUENCING/incoming/antigence_federation_handoff_2026-07-16/handoff/to_gtm_cellico/publication_backbone.fcg.json` sha256 `e200788b84000e02a16760b7674b64b0028f0c10e54eabdd5804a1f4b1a4e682`

## Limitation Handling

- `operator-only-visibility`: manual upload/visibility switch remains operator-only
- `no-live-writeback`: FCG is copied as package-local evidence; live KG writeback remains deferred
