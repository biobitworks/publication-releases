# Package Ready Receipt — Antigence publication

- Status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:d1471fee5bd961f2444c5c74a118cc5bd3e2a52052793c93cf165367f69bd17d`
- Stats: `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/evidence/PACKAGE_CONTENT_SOURCE_STATS_20260804.json`
- Upload bucket: `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready`
- Evidence bucket: `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/evidence`
- Metadata bucket: `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/metadata`
- Boundary: private/staged only; operator controls public upload and visibility.

## Warnings

- None.
