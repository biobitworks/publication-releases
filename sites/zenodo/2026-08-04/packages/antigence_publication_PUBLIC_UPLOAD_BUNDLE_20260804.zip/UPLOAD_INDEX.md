# Upload Index

- Package: `antigence_publication`
- Generated: `2026-08-04T03:13:51+00:00`
- Claim scope: Antigence FCO007 evidence bundle approved for publication staging; no clinical or security product efficacy overclaim
- Do not upload any `do_not_upload/` content.
- Claim promotion is limited to publication-version framing; forbidden scientific/capability claims remain blocked.

## Files

- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/ANTIGENCE_IMMUNE_MATRIX_MANUSCRIPT_v1_DRAFT.md`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/CLAIMS_LEDGER.md`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/PUBLICATION_EVIDENCE_BUNDLE.md`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/RESULTS_v2_publication.md`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/FCO007_SEAL_VERIFY.json`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/FCO007_SHIP_RECEIPT.json`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/PACKAGE_CONTENT_SOURCE_STATS_20260804.md`
- `/Users/byron/projects/active/ollarma/outbox/260804-antigence-publication-package-ready/upload_when_ready/PACKAGE_READY_RECEIPT_20260804.md`
