# Custody-Verified Classification of AI Model Outputs in a Self/Non-Self × Safe/Unsafe Matrix — with an Honest Confirmatory-Negative on Detector Accuracy

**Draft v1 · claim tier: EXPLORATORY · status: DRAFT — pre-review, not for submission**
**Assembled by:** ollarma (Claude Code) from the FCO immune-matrix dossier + publication-grade statistics + the EXP-OLLARMA-FCO-007 confirmatory run, cross-verified with the antigence measurement peer.
**Governance:** AI-agent-custody (`model_provenance`) lane only. No biological FCG content (that lane is `GTM_GOVERNANCE_ONLY`). Publication-sequencing decision is operator/counsel-gated (gtm-cellico). All citations below are marked **[VERIFY]** and must be DOI/arXiv-verified before submission.

---

## Abstract

We present an immune-inspired system that assigns every AI model-output instance to a cell of a **self/non-self × safe/unsafe** matrix, where each disposition (ADMIT / LEARN / REVIEW / REJECT) is backed by a **recompute-verifiable custody proof** (a fractal custody graph, FCG, over named bytes). We evaluate two *orthogonal* claims and are careful never to conflate them. **(1) The custody/matrix claim is ESTABLISHED:** across two independent agent instances (a GPU measurement peer and a CPU verification peer), every reported metric recomputes byte-for-metric from named inputs and is placed in a matrix cell with a tamper-evident disposition — end-to-end, today. **(2) The detector-accuracy claim, tested confirmatorily, is NEGATIVE:** on a frozen-before-data, atom-disjoint test set of 200 clinical-claim atoms with mechanism-defined labels (EXP-OLLARMA-FCO-007), the frozen anomaly detector achieves ROC-AUC **0.585**, below a logistic-on-embeddings prior-art floor (0.627) and failing a pre-registered two-gate (AUC > 0.75 *and* DeLong lower bound > 0.75) on every failure-mode cell. An independent human plausibility review and an orthogonal surface-artifact baseline (AUC 0.509) confirm the negative is a **genuine capability gap, not a construction artifact**. The result converges with an external prompt-injection benchmark on which the same detector family sits at chance (AUROC 0.524). We argue that a working, auditable **custody** layer plus an **honestly bounded** accuracy result is a more useful contribution than an unaudited accuracy headline, and we release the full recompute-verifiable protocol.

---

## 1. Introduction

Deploying AI assistants in science and engineering raises a verification problem: given a model output (a cited claim, a code change, a data transformation), can we (a) *account* for how it was judged, and (b) *trust* the judgment? These are different questions. The first is a **custody** question — is the disposition reproducible and tamper-evident? The second is a **capability** question — is the detector actually good at telling safe from unsafe?

A recurring failure mode in this space is to answer (a) and quietly claim to have answered (b): to report a high in-distribution AUC and present it as "the system is accurate." We structure this paper to keep the two claims separate by construction, and we report an honest negative on (b) rather than an in-distribution number that would not survive a fresh test.

**Contributions.**
1. An immune-inspired **self/non-self × safe/unsafe matrix** with a per-instance disposition and a recompute-verifiable custody proof (§3.1–3.2).
2. A demonstration that the **custody claim is ESTABLISHED** end-to-end across two independent agent instances (§4.1).
3. A **pre-registered, frozen-before-data confirmatory test** of detector accuracy (§3.3) whose result is a **registered negative** (§4.2), corroborated by an orthogonal surface baseline and independent human review (§4.4), and converging with an external injection benchmark (§4.3).
4. A **claims-boundary discipline** (§6) and a fully **recompute-verifiable protocol** (§7) that others can rerun.

## 2. Background

**Artificial immune systems / negative selection.** Negative-selection detectors model "self" from clean examples and flag deviations as "non-self" [Forrest et al. 1994]. Prior Antigence work established a SciFact baseline and the NegSel-AIS framing (Zenodo 10.5281/zenodo.18109862).

**Self/non-self × safe/unsafe as a 2×2 (refined to 2×3).** Identity (self / non-self) is orthogonal to behavior (safe / unsafe). The measurement peer uses a 2×2; the verification peer adds an `indeterminate` behavior axis (the admit-gate could-not-judge state) → a 2×3, folded back into the 2×2 by routing every `*_unjudged → REVIEW` (fail-safe).

**Custody / fractal custody graphs (FCG).** Each reported number is a leaf that recomputes from *named bytes* (input hashes) under a fixed procedure; leaves compose into a fractal root. A disposition of ADMIT means "recomputes from named bytes and clears the gate" — it is a **custody** statement, **not** a correctness statement (hash-tree lineage: [Merkle 1979]).

## 3. Methods

### 3.1 The matrix and dispositions
Every model-output instance is placed by identity (self/non-self, from provenance) and behavior (safe/unsafe/indeterminate, from the detector + admit gate) into a cell with a disposition: **ADMIT** (self·safe, recompute-clean), **LEARN** (self·unsafe, add to training), **REVIEW** (any `*_unjudged`/indeterminate — fail-safe), **REJECT** (non-self·unsafe or custody failure → `compromised_insider`).

### 3.2 Custody recompute-verify protocol
The measurement peer (GPU) computes metrics and emits a receipt + out-of-fold predictions; the verification peer (CPU) independently recomputes every headline metric from the named bytes. A metric that fails to recompute **rejects the leaf** → `compromised_insider` → REVIEW, never ADMIT. Weights are hashed (`weights_root`) from their little-endian float64 bytes; the test set, corruption operators, and prereg are content-hashed and frozen before any scoring.

### 3.3 Confirmatory accuracy test (EXP-OLLARMA-FCO-007) — prereg-before-data
To avoid an in-distribution illusion we pre-registered the detector, the fusion weights, the operating threshold, and the hypotheses **before** any test atom was embedded (prereg leaf `be2a7c47…`), enforcing the discipline that an uncommitted prereg is void.
- **Corpus / labels.** Clean base atoms are *held-out* Vitalogy-1927 (US public-domain) atoms, atom-id-disjoint from the 102-atom fit set. Anomalies are produced by **disclosed, deterministic per-cell corruption operators** (dosage, unit, causal, delay, temporal) — the label is a mechanical function of (clean atom, operator, seed), never a model judgment. N = 200 (80 anomaly / 120 clean), fixed-prevalence stratified, ≥ 8 anomalies/cell.
- **Detector (frozen).** `orchestrator_ensemble_v2`: `score = mean( minmax(clip(orch, 0, 0.396)), MLP_prob )`; the MLP head (768→32→1 tanh) is trained on the 102 fit atoms only; threshold τ = 0.4189 (q90-of-clean). Numeric constants frozen and committed before scoring.
- **Floors.** A logistic-regression-on-embeddings prior-art floor (0.627) and a naive **surface-artifact** baseline (0.509) computed on the same atoms, the latter to control the artifact-detection confound.
- **Two-gate hypothesis.** H1: ROC-AUC > 0.75 (MESI) **and** DeLong 95% CI lower bound > 0.75, Holm-corrected across the 5 per-cell tests + global; reported **per cell, never pooled**.
- **Red-team guardrails (RT2).** Template near-duplicate check (0/200 above a 0.95 cosine ceiling), period-plausible unit corruptions only, the surface-artifact baseline, and an independent **human plausibility spot-check** (n = 12/cell).

## 4. Results

### 4.1 Custody claim — ESTABLISHED
The two-instance protocol ran end-to-end: the GPU peer sealed the FCO-007 frozen-ensemble receipt; the CPU peer recompute-verified `weights_root` (`bed4dc14…`) and all four detector-level AUCs (admitted = 4, rejected = 0, integrity OK), placing the run at self·safe → ADMIT (custody), fractal root `sha256:721b3646…`. Every headline number in §4.2 reproduces byte-for-metric on an independent machine. This is what "end-to-end classified in the matrix" means, and it holds **today**.

### 4.2 Detector-accuracy claim — CONFIRMATORY-NEGATIVE
On the frozen, fresh-disjoint test set:

| Level / cell | ROC-AUC | Note |
|---|---|---|
| **Frozen ensemble (headline)** | **0.585** | aggregate discrimination, *not* a per-cell claim; DeLong 95% CI [0.505, 0.665] |
| MLP head only | 0.598 | reproduces the pre-registered head |
| Negative-selection (GPU) | 0.531 | |
| Orchestrator (fused) | 0.500 | |
| — dosage | 0.656 | fails two-gate |
| — unit | 0.605 | fails two-gate |
| — causal | **0.347** | anti-correlated |
| — delay | 0.611 | fails two-gate |
| — temporal | 0.707 | best cell; still < 0.75 |
| logistic floor / surface floor | 0.627 / 0.509 | ensemble does **not** exceed the logistic floor |

**Verdict: CONFIRMATORY-NEGATIVE.** No cell (nor the global test) clears the two-gate; the ensemble does not exceed the prior-art floor. `claim_promotion = false`. This is a large, pre-registered regression from the in-distribution cross-validation figure (aggregate ensemble CV AUC **0.863**, DeLong 95% CI [0.771, 0.921]; honest ensemble-vs-best-single-head uplift +0.045, p = 0.017). Critically, **that CV figure was leakage-audited and is not inflated**: the suspected global-minmax fusion leakage was refuted (leave-one-out Δ = 0.000000, independently red-team-verified). The collapse to 0.585 on fresh-disjoint data is therefore a **genuine winner's-curse regression, not an artifact of removing leakage** — exactly what the prereg anticipated (red-team HIGH-2). N-sizing was pre-registered for this regression (fresh 0.84 → N=184; at the DeLong lower bound 0.771 → N≈3696), and a sub-powered result was pre-specified INCONCLUSIVE, not FAIL; the observed 0.585 is unambiguously below the floor regardless.

### 4.3 External convergence — a second domain, the same lesson
A sibling detector in the same family (prompt-injection detection) was frozen after internal training and scored **zero-shot** on two external benchmarks from other groups:

| Eval | Group | Benigns | AUROC |
|---|---|---|---|
| internal 262-corpus (grouped CV) | ours | ours | 0.977 |
| InjecAgent [Zhan et al. 2024] | UIUC | homogeneous | 0.809 |
| **BIPIA [Yi et al. 2023]** | **Microsoft** | **real, diverse** | **0.524 (chance)** |

The internal 0.977 survives its own leakage and confound audits (StratifiedGroupKFold on (tool, arguments) moved it only 0.982 → 0.977; a length-only detector was neutralized 0.924 → 0.160 by length-matched benign twins while content recall held at 0.909; keyword-only baseline 0.628). Yet on BIPIA's diverse real benigns the detector sits at chance. **Two independent domains (clinical anomaly, prompt injection), two carefully audited high in-distribution CVs, two fresh-data collapses:** the consistent lesson is that single-corpus cross-validation measures in-distribution fit, not transferable capability — and that **data diversity, not architecture, is the binding constraint** on real detection. One mechanistic signal does survive and is worth reporting: an ablation shows the `tool_output`-provenance feature contributes ΔAUC +0.448, i.e. the *trust-of-origin* axis carries real information even where the learned head does not generalize.

**Leave-one-benchmark-out (LOBO) confirms diversity, not pooling, is the lever.** To test whether the collapse is merely a *coverage* gap that more training data would close, a distilled detector (DistilBERT, CPU) was retrained under leave-one-benchmark-out: for each benchmark, train on the pooled *other two* and score the held-out one zero-shot (n=2707; seed 1729). Held-out AUROCs:

| Held-out benchmark | Benigns | AUROC |
|---|---|---|
| InjecAgent (n=2108) | homogeneous, lexically similar | 0.797 |
| **BIPIA (n=398)** | **real, diverse** | **0.504 (chance; recall 0.995 / precision 0.50 — degenerate all-positive)** |
| internal (n=201) | hand-authored | 0.532 (chance) |

Transfer is **asymmetric**: pooling recovers InjecAgent (its imperative injections are lexically close to the training benchmarks), but pooling InjecAgent + internal still leaves BIPIA and the hand-authored internal set at chance. This *reinforces* rather than rescues the thesis — you cannot pool your way to a diverse benchmark from narrower ones; the diversity must be present *in training*. The practical consequence is the two-track posture: the quantized rung-1 antibody stays a **high-precision in-distribution** detector, and out-of-distribution inputs escalate to human review rather than being scored as if in-domain. (Independently seal-verified: ollarma re-pulled the Kaggle kernel output and byte-matched the measurement peer's committed `metrics.json`, sha256 `103fdd80…`.)

### 4.4 The negative is genuine, not an artifact
The surface-artifact baseline is near-random (0.509), so the corruptions are not surface/construction-detectable. An independent human plausibility review (60 atoms) found the corrupted atoms period-native with surgical edits (targeted-only rate = 1.0 across all cells); the single cell flagged as confounded (dosage, 0.75 native-pass) was confounded by **class-invariant OCR source noise**, not corruption seams, and failed the gate regardless. Most tellingly, `causal` reads 100% native to human reviewers yet the detector scored it anti-correlated (0.347) — a **genuine capability gap**, not a masked seam. An independent artifact-vs-clinical countersign by the measurement peer concurred (RT2-2d = PASS).

## 5. Discussion
The value of this work is the **separation** it enforces. The custody layer is real, auditable, and cross-instance reproducible — a deployable contribution for accountable AI verification. The accuracy result is a **registered negative** that maps a capability boundary: an anomaly detector fit on a single small corpus, however carefully sealed, does not generalize to fresh disjoint data or to a different domain. Reporting the negative (rather than the flattering in-distribution number) is what the custody discipline is *for*: the same recompute-verify that would catch a forged number also refuses to let an in-distribution AUC masquerade as capability.

## 6. Limitations & claims boundary
- **Tier is EXPLORATORY.** The accuracy claim is a bounded negative on a single public-domain corpus era; a general capability claim would need **cross-corpus + cross-mechanism external validation**.
- **Data quality.** ~108 image-only pages produced OCR-garbled atoms; a cleaner rebuild should filter them before any re-measure.
- **Custody honest limit.** A fully-consistent forgery would need a deferred signature/SeedGraph anchor; until then `trust = PROVISIONAL`.
- **FORBIDDEN (do not write):** any context-free accuracy %, "ADMIT = correct" (ADMIT is custody, not correctness), any pooled-across-cell AUC presented as a per-cell claim, or "end-to-end classified" phrased to imply accuracy.

## 7. Reproducibility
Prereg `PREREG_FCO007_confirmatory_disjoint.json` (leaf `be2a7c47…`); frozen constants (τ 0.4189, orch clip [0,0.396]); antigence receipt + `oof_predictions.jsonl`; ollarma `FCO007_SEAL_VERIFY.json` (independent recompute); human review `rt2_2c_spotcheck_score.json`; RT2-2d countersign; registered in `NEGATIVE_RESULTS_REGISTRY.md`. `weights_root bed4dc14…` reproduces from the shipped embedding cache via `fco007_train_head.py` (seed 42, CPU==GPU).

## References

**Web-verified 2026-07-11 (arXiv/venue confirmed):**
1. Yi, Xie, Zhu, Kiciman, Sun, Xie, Wu. "Benchmarking and Defending Against Indirect Prompt Injection Attacks on Large Language Models" (**BIPIA**). arXiv:2312.14197, 2023; KDD 2025.
2. Zhan, Liang, Ying, Kang. "**InjecAgent**: Benchmarking Indirect Prompt Injections in Tool-Integrated Large Language Model Agents." arXiv:2403.02691; ACL 2024 Findings.
3. Debenedetti, Zhang, Balunović, Beurer-Kellner, Fischer, Tramèr. "**AgentDojo**: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents." arXiv:2406.13352; NeurIPS 2024.
4. Greshake, Abdelnabi, Mishra, Endres, Holz, Fritz. "Not what you've signed up for: Compromising Real-World LLM-Integrated Applications with Indirect Prompt Injection." arXiv:2302.12173; ACM AISec '23.

**Canonical/standard references (confirm exact formatting at submission):**
5. Forrest, Perelson, Allen, Cherukuri. "Self-Nonself Discrimination in a Computer." IEEE S&P, 1994. (negative-selection / AIS origin)
6. Merkle. "Secrecy, Authentication, and Public Key Systems." Stanford PhD thesis, 1979. (hash-tree lineage)
7. DeLong, DeLong, Clarke-Pearson. "Comparing the Areas under Two or More Correlated ROC Curves: A Nonparametric Approach." *Biometrics* 44(3):837–845, 1988.

**Project artifact (deposit verified 2026-07-11):**
8. Lee, B. "Antigence: Hypothesis and Software Overview." Zenodo, 2025-12-31. DOI 10.5281/zenodo.18109862. (Tier-0 concept overview; "No empirical results are reported in this Tier 0 release" — **this manuscript is the empirical follow-up.**)

---
*Open items before this DRAFT can become a submission: (1) ✅ all citations verified 2026-07-11 (refs 1–7 web-verified; ref 8 Zenodo deposit confirmed live); (2) ✅ in-distribution CV numbers reconciled with the leakage audits (§4.2 clinical global-minmax Δ=0; §4.3 injection StratifiedGroupKFold 0.982→0.977 + length-confound neutralized) — both fresh-data collapses are genuine, not leakage-removal artifacts; (3) operator/counsel publication-sequencing decision via gtm-cellico; (4) optional: fold the full 7-detector × 3-domain benchmark (DETECTOR_BENCHMARK.json) as an expanded companion or a distinct second preprint (external-validation summary now in §4.3).*
