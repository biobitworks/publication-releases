# Publication-grade statistical analysis — Antigence hierarchy anomaly detector

**Run:** `hierarchy_auc_fcg_20260709T131812Z` · **Analysis:** `publication_stats.py` (pure numpy,
seed=42, recompute-auditable) · **Governance:** prereg `7d323bd4…` (EXP-OLLARMA-FCO-006),
`CLAIM_CEILING.md` · **Claim tier: EXPLORATORY** (5-fold CV on the same 102-atom set).

> **Two claims, two tiers (do not conflate — see `CLAIM_CEILING.md`).**
> (1) **Custody/matrix disposition**: every run is end-to-end classified in the
> safe/non-safe × self/non-self matrix with a recompute proof — **ESTABLISHED today**.
> (2) **Detector accuracy**: AUC discrimination — **EXPLORATORY**, upgraded to CONFIRMATORY
> only by the powered fresh-disjoint run (prereg frozen).
> Numbers below are the EXPLORATORY evidence for claim (2). **Independently red-team verified**
> (`REDTEAM_RECEIPT_20260709.md`): all arithmetic reproduces byte-for-byte; the suspected
> global-minmax leakage is REFUTED (Δ=0.000000); framing/baseline/sizing defects fixed below.

## 1. Discrimination with confidence intervals (per level, never pooled)

| Level | scorer | AUC | DeLong 95% CI | bootstrap-BCa 95% CI | Holm p |
|---|---|---|---|---|---|
| antibody | NegSel one-class (GPU) | 0.367 | [0.265, 0.483] | [0.268, 0.478] | 0.019 |
| antibody | supervised MLP (GPU) | 0.817 | [0.722, 0.885] | [0.733, 0.891] | <1e-3 |
| orchestrator | fused (rule+embed) | 0.768 | [0.677, 0.840] | [0.677, 0.844] | <1e-3 |
| **orchestrator** | **+ MLP ensemble** | **0.863** | **[0.771, 0.921]** | **[0.777, 0.925]** | <1e-3 |

- DeLong (parametric) and bootstrap-BCa (nonparametric) **agree** at every level → mutual
  validation of the CI machinery.
- The one-class NegSel head's CI **[0.265, 0.483] lies entirely below 0.5**: it is significantly
  *worse* than random — an honest negative, now bounded. Only the *supervised* head earns its place.
- The ensemble **0.863** is an **aggregate discrimination figure over all 40 anomalies, not a
  per-cell claim** — reported here only alongside the full per-cell decomposition (§8), per the
  amended CLAIM_CEILING FORBIDDEN #3 (RT HIGH-4). It must never stand alone as a headline.

## 2. The ensemble uplift is statistically real (measured honestly)

The ensemble embeds the MLP, so the honest value-add is **ensemble vs its best single component
(the MLP)**: paired DeLong ΔAUC = **+0.045, z = 2.40, p = 0.017** — significant, CI excludes 0.
(Secondary, vs the *weakest* head: ensemble vs fused ΔAUC +0.094, p=0.0043 — but the fused
orchestrator is **not** significantly better than the MLP alone, p=0.27, so ~half of that larger
gap is just the MLP beating a weak baseline. Red-team RT HIGH-1.) The primary +0.045/p=0.017 is
the number to headline.

## 3. Statistical power / sample size (the process-control gold standard)

- Powered to reject AUC=0.5 at n=102: power ≈ **1.0** (trivial).
- Against a pre-registered **MESI floor of AUC 0.75** (clinical-triage minimum effect size of
  interest): achieved power at n=102 is only **0.756**.
- **N ≥ 114 (≥45 anomaly / ≥69 clean)** confirms AUC>0.75 at 80% power — **but only if the fresh
  AUC equals the CV estimate 0.863.** Fresh-disjoint sets regress below CV (winner's curse), and N
  is steeply sensitive: **fresh AUC 0.84 → N=184; 0.82 → 312; 0.80 → 626; at the DeLong lower bound
  0.771 → N≈3696** (red-team RT HIGH-2). So 114 is a best-case *floor*; the prereg sizes the
  confirmatory run for regression-to-the-mean (aim ≥184), and a sub-powered result is reported
  INCONCLUSIVE, not FAIL.

## 4. Statistical process control (SPC)

- **Process capability** at a 10%-FPR operating point (q90-of-clean threshold 0.419):
  misclassification rate 0.186 → **0.89σ actual (unshifted) / 2.39σ with the 1.5σ short-term shift**,
  DPMO ≈ 186,000. Both are reported (RT LOW/MED-1: the shift adds 1.5σ "for free"). Mediocre either
  way — an honest improvement target; the sigma level depends on the chosen operating point.
- **Rational-subgroup homogeneity** (Shewhart Rule 1 on 6 non-overlapping randomized subgroups):
  **PASS** — no out-of-control subgroup (rates 0.12–0.24, all within 3σ). The error process is in
  statistical control.
- **Temporal charts (CUSUM / EWMA / Nelson runs-rules 2–4): SPECIFIED but DEFERRED** to the
  production streaming monitor. A CV evaluation set is *exchangeable* (no acquisition-time order);
  charting it over any fixed atom order reports ordering artifacts as drift. (Contrast FCO, whose
  CUSUM runs on genuinely time-ordered loss trajectories — valid there.)

## 5. Prior-art floor (must be exceeded)

The raw-NegSel floor (AUC 0.367) is *below random*, so beating it (p<1e-6) is a **sanity check
only, not evidence** (RT MEDIUM-1). The prereg-mandated **logistic-regression-on-embeddings** floor
is **NOT YET RUN** (the OOF file exposes only scalar heads, not the 768-d embeddings) → floor verdict
is **INCOMPLETE**; no "EXCEEDS floor" claim is made. The honest in-hand baselines are the MLP (0.817)
and fused (0.768), and the ensemble's margin over those (§2) is the real novelty test.

## 6. Measurement System Analysis (MSA / Gauge R&R)

- **Repeatability = 0** (seed=42, temperature=0 → deterministic recompute; bounded to 1 fp32 ULP
  (2⁻²³) on Apple MPS, per FCO's determinism ladder). The true metrological gauge is exact.
- Reproducibility "across heads" is EXPECTED disagreement between different detectors, not
  instrument error — reported for completeness (%GRR-vs-unit ≈ 22.8%) but flagged as detector
  divergence, not gauge error.

## 7. Calibration & omnibus

- Calibration (needs work): ensemble Brier 0.152 / ECE 0.118; MLP Brier 0.200 / ECE 0.173.
  Discrimination ≠ calibration — deployment needs a separate calibration gate.
- Friedman omnibus over the 4 heads' per-atom scores: χ²=150.8, df=3, p≈0 (heads differ).

## 8. Per-cell AUC (ENSEMBLE detector, this-anomaly-type vs all clean)

> **Not comparable to `receipt.json` cell_types** (which is the one-class NegSel head's
> one-vs-rest AUC — a different detector AND contrast; RT HIGH-3). n_pos<10 cells use a bootstrap
> CI + a perfect-separation fraction because the parametric CI understates boundary-piling at n=4.

| cell | n_pos | AUC | 95% CI | perfect-sep frac | flag |
|---|---|---|---|---|---|
| causal | 13 | 0.820 | [0.641, 0.921] (DeLong) | — | ok |
| dosage | 13 | 0.805 | [0.644, 0.904] (DeLong) | — | ok |
| delay | 5 | 0.906 | [0.755, 1.000] (boot) | 0.04 | **degenerate** |
| unit | 5 | 0.987 | [0.958, 1.000] (boot) | 0.21 | **degenerate** |
| temporal | 4 | 0.976 | [0.927, 1.000] (boot) | 0.14 | **degenerate** |

The small-n cells (n_pos 4–5) look excellent but are **degenerate**: 10–22% of bootstrap resamples
give *perfect* separation, so the point estimates are false precision — **directional only**. This
is exactly why the confirmatory prereg mandates ≥8 anomalies/cell-type.

## 9. What this does and does not license

- **Licenses**: the EXPLORATORY statement that the ensemble discriminates disclosed clinical
  anomalies at AUC 0.86 [0.77–0.92] on CV, with the +0.094 supervised-head uplift significant, the
  error process in control, and the whole run recompute-verified and matrix-classified (self/safe →
  ADMIT).
- **Does NOT license**: any CONFIRMATORY accuracy claim (CV-on-same-set), a context-free "X%
  accurate" number, "ADMIT = correct", pooled AUC, or generalization beyond the disclosed anomaly
  mechanism. Those are gated on EXP-OLLARMA-FCO-006 (fresh-disjoint, N≥114).
