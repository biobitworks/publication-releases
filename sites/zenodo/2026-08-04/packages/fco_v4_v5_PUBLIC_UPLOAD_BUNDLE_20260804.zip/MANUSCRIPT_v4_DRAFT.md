# Fractal Custody Objects — vNEXT unified manuscript body (superseding assembly)

> **Status: PROPOSED · v-next superseding draft · assistant-assembled 2026-07-16 · NOT signed, NOT
> certified, NOT merged, NOT deposited.** This is the single unified body the eventual FCO/FMO/FCG
> publication is meant to be, with every settled external-review v2 disposition folded in. It **supersedes**
> the frozen, individually signed section bodies below — it does **not** edit them in place (each carries a
> `.sig.json` custody sibling; editing it would break the seal). Supersession, not erasure: the superseded
> bodies remain append-only in the repo as history.
>
> **Supersedes (byte-frozen, retained):**
> - v2 assembled — `handoff/MANUSCRIPT_v2_ASSEMBLED_2026-07-10.md` (content_leaf `d813825a`)
> - v3 assembled — `handoff/MANUSCRIPT_v3_ASSEMBLED_2026-07-10.md` (content_leaf `364dbefe`)
> - merged 6-section — `handoff/MANUSCRIPT_MERGED_v2v3_6section_2026-07-12.md`
> - FMO/FCG body — `MANUSCRIPT_PUBLIC_v1.md` (FMO/FCG novelty + EXP-027 surfaces)
>
> **v1 stays frozen** (Zenodo `10.5281/zenodo.21210575`, `paper_cid 291f3364`, zip sha `916bf4c4`) and is
> referenced, never rewritten — read through its retirement erratum (`RETIREMENT_ERRATA_v1_2026-07-10.jsonl`,
> content_leaf `2e347058`).
>
> **What changed vs the superseded bodies (the v-next deltas folded in here):**
> 1. one uniform **claim grammar** applied everywhere — Committed / Recomputed / Authenticated / Validated
>    (§0), retiring the overclaim vocabulary flagged by the RV2-P0-3 sweep;
> 2. the v3 detector result **upgraded from the exploratory "re-opens / seed-sensitive" register to the
>    powered N16 confirmatory disposition** — *superiority not established; complementarity ceiling* under a
>    preregistered TOST (§3);
> 3. Arm B reported as its **margin over the trivial `mean_loss` baseline (N13)**, not as a bare near-ceiling
>    AUC (§3);
> 4. the two distinct **complementarity claims disambiguated** — Arm-B-vs-fair-floor (NOT demonstrated,
>    N14/N15) vs the banked Arm-A/Arm-B division of labor (MCC 0.9417, leaf `7e88b6cb`) (§3, §7);
> 5. FMO/FCG **novelty narrowed to the profile + reference implementation** with an explicit prior-art
>    crosswalk (§4, Appendix A);
> 6. **EXP-027 reframed** as a null capability result with the 3/7 = 0.4286 modal-baseline pilot correction
>    (§4);
> 7. causality / citation / mechanical-science / "at power" ceilings tightened to the verbatim review
>    language (§4, §7);
> 8. the **signed-root vs unsigned-seal** discrepancy reconciled honestly (§4.5, default: seal is unsigned);
> 9. **model-role sentences + an AI-use disclosure** block added (§8);
> 10. the **D2 CI-direction correction** referenced as a separate append-only errata object, not restated
>    (§3.4, Appendix B).
>
> **Governing ceiling (travels with every section):** reproducible ≠ interpretable; recompute-not-certify;
> the tiny model is a determinism/provenance demonstration substrate, never a capability, interpretability,
> security-effectiveness, or superiority claim; the surviving contribution is a domain-specific custody +
> admission **profile with a reference implementation**, not a new primitive. Nothing here self-authorizes a
> GO, a certification, a signature, a deposit, or a `.backup-hold` release — those are operator/PI actions.
> `.backup-hold` intact.

---

## §0. Claim grammar (the governing lens — applied to every claim below)

Every claim in this manuscript is stamped at exactly one of four levels. **No level is ever substituted for
a higher one.** This is the external review's central cross-package rule and it governs the wording of every
section.

| Level | What it means | Licensed statement | NOT licensed |
|---|---|---|---|
| **Committed** | A digest/root names a byte/object state under a canonical recipe. | "The root `<x>` commits these bytes." | possession, authorship, truth |
| **Recomputed** | A verifier regenerated the same digest from the disclosed bytes + recipe. | "Recomputing from the named bytes reproduces `<x>` for that run." | authentication, scientific validity |
| **Authenticated** | A trusted identity/key signed the commitment and the verifier checked the trust path. | "Signed by key `<id>`; trust path verified." | scientific/statistical validity |
| **Validated** | An independently designed test supports a scientific/statistical/security claim. | "An independent test at α=… supports …" | — (top of the ladder) |

**Retired vocabulary (this manuscript uses none of it as a load-bearing claim):** "proves possession",
"certified" / "fully verified", "independently reproduced" (for a second run by the same project),
"proven" (device/operation), "non-removable", "cryptographic certainty", "capability-independent", "Gauge
R&R" / "stable gauge", "complementary on a shared task" (as an undifferentiated claim), "re-opens / beats /
superior" (v3). Each is replaced below by its grammar-appropriate form.

**Authentication labeling rule.** Every root/seal is labeled **unsigned** unless a verifiable signature is
actually present and its trust path checked. A matching self-declared root proves internal byte agreement
under the recipe (Recomputed) — not who created, authorized, or possessed the source.

---

## §1. v1 — self-verifying publication object model (FROZEN)

v1 is the immutable published base (Zenodo `10.5281/zenodo.21210575`, `paper_cid 291f3364`, zip sha256
`916bf4c4`). It is referenced here, never embedded or rewritten. It established the Fractal Custody Object: a
content-addressed root that doubles as a knowledge-graph node, with typed custody leaves, the admission
semantics *admit-iff-recomputes-from-named-bytes / reject-not-annotate / recursive admission*, route-comparable
divergence localization, and an explicit claim ceiling. v1's binding ceiling carries over verbatim:
proof-of-concept; a recomputing root **Committed**/**Recomputed** a fact, it does not establish the fact's
truth, authorship, or efficacy — a recomputing root can bind a false fact. See the v1 deposit for the object
model, `scripts/`, `figures/`, custody manifests, and `VERIFY.md`. v1 is read **as corrected** through its
retirement erratum (`RETIREMENT_ERRATA_v1_2026-07-10.jsonl`, content_leaf `2e347058`).

---

## §2. v2 — custody of the model-training interior

v2 extends custody from data pipelines into the **interior of model training**. It ADDS to v1 and never
contradicts or re-deposits it. Every numeric claim below is quoted from a banked result-leaf that recomputes
from bytes under the pinned `fco_train.custody` (sha256 `e116f9ff`); none is restated from memory.

### 2.1 Model role (see §8)

v2 trains a **Pythia-14M (GPT-NeoX family) language model from scratch as a controlled experimental
fixture** — a determinism/custody test object at epochs=1, never a capability claim.

### 2.2 The multi-root spine

A from-scratch Pythia-14M run over a fully-vaulted public-domain corpus commits the spine
`dataset_root → recipe_root → trajectory_root → weights_root → result_leaf`, each node **Recomputed** from
named bytes. This makes a model's *interior* a custody object, not just its I/O. **Prior art conceded first:**
Proof-of-Learning (Jia et al. 2021) is the nearest neighbour — deterministic recompute-of-training. FCO's
narrowed contribution is the multi-root custody spine + reject-not-annotate over that interior, **not**
deterministic recompute per se. The CPU single-thread bit-identity leaf `f66ce21a` is the gating result,
verified from bytes (leaf recomputes MATCH; `dataset_root 7ccc4780`, `weights_sha 5beb9c17`).

### 2.3 Merkle-root-as-vault: custody by hash

`tokenize(corpus, pinned GPT-NeoX BPE)` is a deterministic, recomputable derivation edge producing
`dataset_root`.

> **[grammar-corrected — retires "proves possession"]** A verifier that recomputes the root from the named
> corpus bytes **confirms byte-level agreement** with the committed corpus for that run (Recomputed). The root
> alone does **not** prove possession, authorization, provenance, or lawful access to those bytes.

Load-bearing ceiling: a root is a **COMMITMENT, not encryption** — tokens decode to text, so confidentiality
lives in *where the corpus is stored*, not in the root. Fine for public-domain corpora; a hard line at PHI (a
custody hash of PHI is still PHI). Content-addressing is **not** HIPAA de-identification.

### 2.4 The 9-rung determinism ladder

Nine training runs of the identical G1 Pythia-14M configuration, each anchoring the vaulted corpus
(`dataset_root 7ccc4780`), executed across CPU, GPU-T4, TPU-v5e, and Apple-MPS. Every landed leaf recomputes
from bytes; all three negative controls fire on every rung. (Canonical single source: 9 rungs,
`all_anchor_vault=true`, `all_recompute=true`, `unaudited=[]`, `comparison_root 292b7a19…`.)

> **Canonical gating sentence [grammar-corrected]:** CPU single-thread is the sole gating bit-identity claim;
> every accelerator result is a **non-gating, eps-disclosed peer observation**.

Per-rung, each with its binding ceiling:

- **CPU 1-thread** (`f66ce21a`): bit-identical, **gating**. The sole graded bit-identity claim.
- **GPU-T4** (`9e7b3979`) / **TPU-v5e** (`c808f6ff`): reproduce bit-identically **within their own silicon**
  (`used_warn_only` lane). The three deterministic cores produce **three distinct** `weights_sha`
  (`5beb9c17` / `4724b237` / `a6b3eb9e`) over the identical input — cross-device bit-identity does **not**
  hold and is not claimed.
- **Apple-MPS ×2 + cross-session ×2** (`ba001731` / `5363f314` / `5ea8fc98` / `62fe9e57`):
  > **[grammar-corrected — MPS sentence]** Apple-MPS showed **stable, bounded one-ULP drift**
  > (`2⁻²³ = 1.1920928955078125e-07`) across the tested sessions (`unique_weights_sha = 8`); it is an
  > eps-disclosed non-gating peer, **not** a bit-identical gauge. **The mechanism remains unresolved**
  > (`unknown_hardware_contingent`) — no ablation isolated a cause, and none is asserted.
- **TPU cross-session** (`06299c47`): `weights_sha a6b3eb9e` reproduces across a fresh session. The env string
  is byte-identical to the XLA-on-CPU-fallback signature, so `weights ≠ fallback` is
  **necessary-not-sufficient**;
  > **[grammar-corrected — TPU evidence]** the `tpu_diag` report provides **separate evidence consistent
  > with** operation on a v5litepod-8; it is **not a cryptographic hardware attestation**.
- **CPU-unify** (`1142cb47`): under the unified accelerator code (`053686f4`), CPU `weights_sha` reproduces
  `5beb9c17` with the env byte-identical to the graded leaf — removes the `code_sha` confound **for the CPU
  rung only**, nil `lib_versions` residual; it does not license a pure-silicon claim for accelerator rungs,
  whose lib stacks still vary.
- **GPU cross-session — NOT a rung.** A quota/pragmatic deferral documented as a negative; the T4 leaf
  `9e7b3979` stands. Not a claim that a T4 is unattainable.

### 2.5 Metrological framing — a fixed-input repeatability/reproducibility study

> **[grammar-corrected — heading and scope, retires "Gauge R&R" as a claim]** *Metrological framing: a
> fixed-input repeatability/reproducibility study informed by MSA terminology.* This is **not a full Gauge R&R
> study** and does not estimate general measurement-system capability or variance components across
> representative parts, operators, and gauges.

Read as a measurement problem, the ladder is a fixed-input repeatability/reproducibility study of the
training run as the measurement instrument, with the vaulted corpus (`dataset_root 7ccc4780`) as the fixed
part measured repeatedly. Naming the MSA vocabulary is a **concession, not a novelty claim**. The narrower
addition, within the ceilings above: each measurement — each rung — is itself a recomputable custody object
(leaf + `weights_sha` + `PI_AUDIT_STATUS_LEDGER.json status=clean`), not a logged number taken on faith.

- **Repeatability** (within-core): zero on CPU/GPU-T4/TPU within each core's own silicon (CPU alone gating);
  bounded (one fp32 ULP, stable) on Apple-MPS.
- **Reproducibility** (across-core, same input): the three deterministic cores land three distinct
  `weights_sha` — a disclosed reproducibility gap between measurement systems, not a repeatability failure.

This framing changes no ceiling. Custody here attests the **observed** repeatability/reproducibility
statistics of the training-run-as-instrument — never their cause, and never that any one core's `weights_sha`
is the "correct" measurement.

### 2.6 v2 binding ceilings (verbatim)

1. Custody **attests** identity and provenance and records **observed** behaviour — never the CAUSE of a
   difference, and never semantic correctness.
2. CPU single-thread is the sole gating bit-identity claim; every accelerator rung is a non-gating,
   eps-disclosed peer observation.
3. Code-match is **necessary but not sufficient** for a silicon signature — `lib_versions` must also match or
   be argued non-causal; only the CPU-unify rung is lib-clean.
4. The ladder demonstrates same-vaulted-input reproducibility across environments; reproducible ≠
   interpretable; a 14M model at epochs=1 is a **demonstration substrate**, not a capability claim.

### 2.7 Evidence binding

Every rung cites its `result_leaf`, `PI_AUDIT_STATUS_LEDGER.json status=clean`, and the canonical
`FCG_LADDER_COMPARISON_FULL.json` (`comparison_root 292b7a19…`, 9 rungs, all recompute, `unaudited=[]`) as the
single source. The manuscript quotes that object; it does not restate numbers from memory.

---

## §3. v3 — custody as a detector: the benchmark (complementarity, powered disposition)

### 3.1 Model role (see §8)

v3 uses the same Pythia-14M fixture plus a **separate Markov loss-trajectory detector**; it makes no
capability or interpretability claim.

### 3.2 The category resolution and the two arms

An FCO custody spine is a **Fractal Custody Process** — deterministic, append-only, acyclic-through-versioning
— NOT a Markov chain. The detector arms are formulated as complements to the spine, prereg'd and benchmarked,
**never as substitutes** for recompute-identity. On one shared vaulted substrate (real G1 CPU graded leaf
`f66ce21a`, `dataset_root 7ccc4780`, `weights_sha 5beb9c17`, R=50/condition, matched clean negatives):

- **Arm A — deterministic FCO custody detector** (pure recompute-from-named-bytes; reject-iff-mismatch).
- **Arm B — Markov stochastic loss-trajectory detector** (binned per-step loss levels; transition-surprisal
  > `tau_clean` = p97.5), the complement to Arm A.

**Per-condition (MCC / ROC-AUC / FPR; bootstrap 95% CI on MCC) — NEVER pooled across conditions:**

| Condition | Arm A (custody) — **banked** | Arm B (Markov traj) |
|---|---|---|
| **poison** (byte-valid token substitution) | MCC **0.0** [0.0,0.0] · AUC 0.5 · FPR 0.0 — real H1 ceiling: byte-valid poison is invisible to pure recompute | MCC **0.9417** [0.87,1.0] · AUC **1.0** · FPR 0.06 (50/50 caught) |
| **alter_ckpt** (post-training ckpt tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | not scored — post-training tamper leaves the training trajectory = clean; requires a unified substrate |
| **retune** (post-training re-tune tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | not scored — same reason |

*(Power caveat: every AUC cell is a point estimate at N=50/type — UNDERPOWERED vs the Hanley-McNeil N≥114/class
floor and, at perfect separation, carries a degenerate DeLong CI. Reproducible point findings, not powered
claims; `POWER_MATRIX_G3.json`.)*

### 3.3 Superiority over the fair floor: NOT established (powered N16 disposition)

> **[UPGRADED — replaces the exploratory "re-opens / seed-sensitive / inconclusive" register of the superseded
> v3 body with the confirmatory powered disposition, per delta DELTA_v3_2026-07-16 (a)/(b)]**

The frozen prereg required Arm B to **exceed**, not tie, a polarity-fair prior-art floor (a two-sided chart on
loss first-differences, orientation fixed from calibration only — the fair comparator to Arm B's binned Markov).
The question is now **settled by a powered hierarchical confirmatory analysis**, not by a seed tally:

- **The task is trivially separable (N13, leaf `52095927`).** A single trivial feature — `mean_loss` — already
  reaches **AUC 1.0 across the corrected K=15 seeds**. Bare Arm-B AUC is therefore **not** evidence of a hard
  detection signal. Arm B's discrimination must be reported as its **margin over the trivial `mean_loss`
  baseline**, not as a bare AUC. On the corrected `[8,11]` re-score that margin is **at or near zero**.
- **The powered confirmatory reading (N16).** Under a preregistered hierarchical test (DerSimonian–Laird
  pooling with a two-one-sided-test equivalence check against the preregistered margin; frozen prereg
  `63170e81`, freeze `ff92bb16`; aggregate `4ddcb728`, endpoint `7476c282`), the pooled Arm-B advantage over
  the fair floor is **statistically nonzero but falls within the frozen equivalence margin** (TOST
  δ=0.019916).

> **Verdict:** The earlier K5 observation did **not** establish superiority. Under the powered hierarchical
> confirmatory test the superiority question is **closed** as *superiority not established; complementarity
> ceiling* (**N16**). State this via the TOST equivalence, **never** a seed tally. The retired phrasing — "Arm
> B beats the floor", "CI excludes zero → superior", "re-opens the beats-the-floor question", "Issue 2
> RE-OPENED" — is superseded; the legacy "CI-excludes-zero ⇒ beats" rendering was **also separately sign-wrong**
> (see §3.4).

### 3.4 The two complementarity claims — never conflated

> **[UPGRADED — per delta DELTA_v3 (c); the superseded body used "complementary on a shared task" as one
> undifferentiated claim]**

The word "complementary" carries two distinct claims here. They are separated permanently and neither carries
the other's evidentiary weight:

- **(c-i) Arm-B-vs-fair-floor complementarity — NOT demonstrated.** OR-combining Arm B with the best
  fair-floor detector does not beat the better single detector: **OR-gain ≤ 0 on 14/15 corrected K=15 seeds**
  (N14, consolidated leaf `52095927`); and OR-gain **−0.149** with error-correlation **φ 0.851, 25/25 poison
  items co-detected** (0 unique catches either side) on the standalone single-seed carve (N15, leaf
  `fcf31a55`). Empirical complementarity between Arm B and the fair floor is **not demonstrated** at this
  operating point on this symbolic-poison substrate.
- **(c-ii) Arm-A / Arm-B complementarity — banked, untouched.** The distinct Arm-A / Arm-B division of labor
  (Arm A perfect on tamper it can see, blind to byte-valid poison; Arm B catches exactly that poison; **MCC
  0.9417, leaf `7e88b6cb`**) is unaffected by (c-i) and is not re-litigated by the comparative-benchmark
  negatives. It is a separate claim over a separate pairing.

> **Non-conflation rule (standing note):** *Arm-A/Arm-B complementarity* (banked, `7e88b6cb`) and
> *Arm-B-vs-fair-floor complementarity* (not demonstrated, N14/N15) are two different claims over two different
> comparisons. Neither substitutes for the other; no sentence may blur them.

### 3.4b Append-only CI-direction (D2) correction — reference only

The legacy "CI-excludes-zero ⇒ Arm B beats floor" endpoint rule was **sign-agnostic** and mislabeled the
landed K=15 object as "Arm B superior" when the paired CI actually excluded zero on the **losing** side. That
sign/direction fix is captured as a **separate append-only correction object**,
`handoff/vnext/FCO_V3_D2_CORRECTION.DRAFT.json` (reason `CI_DIRECTION_BUG`), referenced from the errata trail
(Appendix B) and **not restated here**. It records **only** the D2 fix on the superseded landed bytes
(`0e3ccbd1`): **custody VALID / scientific endpoint INVALID (SCORING-SUPERSEDED)**. The scientifically
**adopted** reading is not the as-scored superseded object but the D1-corrected `[8,11]` re-score
(`6d6f1649` → pooled `1ec4b48e`) and the powered R5 confirmatory (§3.3) → the N16 disposition. The correction
draft still carries `TODO_PI_RECOMPUTE` fields and is `unsigned` — a draft for the PI/operator, not a
certified artifact.

### 3.5 What is NOT yet scored (honest blockers, not omissions)

- **Arm C′ / dominance.** A real combined arm needs each test instance to carry **both** a real custody status
  (Arm A) and a real loss trajectory (Arm B) across all tamper types. The G2 substrate (custody, symbolic
  tamper) and the G3 substrate ({clean,poison} real trajectories, no custody channel) are **disjoint** — a
  unified both-channel substrate does not exist yet and has not been fabricated by stitching the two.
- **G5 dominance.** BLOCKED on **GAP1**: Arm A's tamper is SYMBOLIC
  (`weights_fidelity: hash_level_real_with_symbolic_tamper`), admissible for the Arm-A mechanism demo ONLY.
  Per the frozen ruling, **dominance may never bank on symbolic tamper** — real raw-shard / real-checkpoint
  byte tamper must be wired and its taxonomy pre-registered first. Dominance stays **future work, not a
  result**.

### 3.6 v3 binding ceilings (verbatim)

1. **Symbolic tamper is mechanism-illustration ONLY; dominance needs real-byte tamper (GAP1).**
2. Custody attests identity/provenance/OBSERVED behaviour — never CAUSE, never semantic correctness. A
   detector cell is not a custody proof of correctness.
3. "Best" is best on THIS shared task/corpus at epochs=1, never universal; reproducible ≠ interpretable; the
   14M model is a demonstration substrate.
4. Head-to-head dominance rides on a real-byte benchmark (G5), never on an N=1 anecdote — and remains
   GATED/FUTURE.

### 3.7 Evidence binding

Arm A quoted from `92711545` (`GATE_G2_pass:true`, PI-audited clean). Arm B + fair-floor sub-table from
`7e88b6cb` (gate-2 cleared; fit substrate `25ca2389`, clean test `3f5d65ba`, poison test `49a7f666`, poison
mechanism `7d138a56`, binning `[8,11]`). The powered disposition quoted from the R5 confirmatory
(prereg `63170e81`, aggregate `4ddcb728`, endpoint `7476c282`) and the D1-corrected re-score
(`6d6f1649` → `1ec4b48e`). The trivial-baseline / OR-gain findings from consolidated leaf `52095927` (N13/N14)
and standalone `fcf31a55` (N15). Every blocked/dominance cell fills ONLY from a landed PI-audited G5 leaf on a
real both-channel substrate.

---

## §4. FMO / FCG — the custody + admission profile (novelty, EXP-027, ceilings)

FMO/FCG **invokes local assistant models as workflow actors only and trains no model** (see §8). This section
carries the object-model contribution and its honest boundary.

### 4.1 Novelty — a narrowed profile claim, not a new primitive

> **[UPGRADED — per delta DELTA_FMO_FCG §1; the N08 novelty bakeoff RETRACTED any standalone-mechanism
> novelty. Verbatim replacement text:]**

> "We present a domain-specific, recursively content-addressed custody and admission profile that binds
> scientific/model artifacts, authorization policy, claim ceilings, and result claims into one operational
> object graph, together with a reference implementation. We do not claim novelty for hashing, Merkle DAGs,
> provenance graphs, signatures, deterministic replay, or policy gates individually."

The claim-by-claim prior-art crosswalk defending this narrowed conjunction against W3C PROV, RO-Crate /
Workflow Run Crate, in-toto, SLSA, SWHID, IPLD, C2PA, nanopublications, and Trusty URIs is **Appendix A**.
Concede-first: we claim novelty for **no** individual mechanism. What survives is the *narrowed conjunction* —
the specific scientific-domain profile + reference implementation binding the typed artifact spine,
authorization policy, claim ceilings, and result claims into one recomputable, fail-closed object graph, with
single-object first-divergence localization and typed divergence categories. **FUTURE, not now:** a recursive
claim-ceiling inheritance with an *anti-downgrade guarantee mechanized as a root preimage* (today it is a
docstring/policy convention, not a cryptographic property of the root).

### 4.2 EXP-027 — pilot correction (append-only) and null capability result

> **[UPGRADED — per delta DELTA_FMO_FCG §2 and §3. Verbatim replacement text:]**

Pilot correction:

> "An earlier seven-task pilot used an incorrect 0.10 chance baseline; re-analysis gives a modal-guess
> baseline of 3/7 = 0.4286. That pilot is superseded by the preregistered 40-task experiment reported here and
> is not used as evidence."

The pilot is marked **superseded / non-evidentiary**; the raw pilot record is retained append-only
(nothing-is-throwaway) — not deleted or rewritten.

Result:

> "On this preregistered 40-task battery, none of the nine tested local models exceeded the realized modal
> baseline after multiplicity correction. This is a null capability result for the tested models and tasks.
> Separately, the exact-match custody rule rejected all submitted wrong values by definition of the admission
> predicate."

The 0/90 exact-hash rejection is **implementation conformance to the admission predicate — not a capability,
security-effectiveness, or semantic-validity result.**

### 4.3 "At power" is reserved

> **[per delta DELTA_FMO_FCG §7]** Exact-match rejection is largely **definitional**; "power" pertains to
> probabilistic tests against specified alternatives. The experiments **test implementation conformance and
> selected failure modes. They do not establish broad security effectiveness or capability-independent
> validity.** *Standing note:* the phrase "at power" appears nowhere in this body unless the sentence states
> the effect size, design, alpha, multiplicity plan, and achieved power (or sensitivity analysis) it
> presupposes.

### 4.4 Tightened ceilings (verbatim)

> **[per delta DELTA_FMO_FCG §4/§5/§6]**
>
> - **Causality:** "The verifier localizes the first committed divergence and assigns a declared divergence
>   category; causal attribution may require additional investigation." (Not "the system names/classifies its
>   own cause.")
> - **Citation:** "The digest gives the atom an intrinsic integrity identifier; durable citation additionally
>   requires resolvable storage and metadata." (The digest alone does not make an atom citable.)
> - **Mechanical science:** "The system mechanizes selected custody, replay, and admission steps within a
>   broader scientific workflow; it does not automate semantic judgment, causal inference, or scientific
>   validity." (Not "scientific method made mechanical.")

### 4.5 Signed-root vs. unsigned-seal — reconciled honestly (default: unsigned)

> **[per delta DELTA_FMO_FCG §8; the review bundle's `SEALED_FCG.json` family is unsigned]**

The prose must not assert a signed public root the shipped bundle does not contain. **Default reconciliation
(Option B) for this bundle:** signing is a **future public-release gate**; the FCG seal in this review bundle
is **unsigned**. Recomputing the declared root from the disclosed bytes reproduces it for that run
(**Recomputed** level) — it is **not Authenticated**. A matching self-declared root proves internal byte
agreement under the recipe, not who created, authorized, or possessed the source. If and when the operator
signs the public artifact with a documented key and the verifier checks the trust path, the claim is promoted
to **Authenticated** ("signed by key `<id>`; trust path verified"); the signing key is **operator-only** — no
session self-signs.

---

## §5. Elementary cellular automata — a transparent worked example + 256-rule primitive benchmark

*Carried from the superseded body; already hedged, no delta beyond grammar. Deterministic (master seed
20260708); every figure and dataset recomputes. Supplementary: `SUPP_DATA_eca_256rule_custody_matrix.csv`,
`SUPP_DATA_eca_hyperfcg_record.json`.*

The 14M training interior (§2) is opaque — you cannot *see* a poison propagate through weights. An elementary
cellular automaton (ECA) is the transparent analogue: a fully deterministic system where each committed row is
visible, so poison propagation, custody-root divergence, and detector separation can be shown directly on the
page. The ECA is a **demonstration substrate**, not a claim that CA dynamics model training.

Every rule is committed two ways over the same seed evolution (T=96 rows × S=96 cells): an **FCO** (whole grid
as one content-addressed root) and an **FCG** (horizontal root over rows × vertical root over columns,
combined). All 256 rule-FCG roots merkle into one **Hyper-FCG** (`hyper_fcg_root 270a0556…`). All 256 FCO and
all 256 FCG roots are distinct: the custody layer separates every rule deterministically (FPR=0), independent
of any detector.

**The worked question — is any CA rule a better custody primitive than SHA-256? No.** Scored on *detector
separation*, Rule 90 is perfect (Cliff's δ = 1.0) — but Rule 90 is **linear** (XOR of neighbours): trivially
invertible, zero preimage resistance, poor avalanche (0.097). Its perfect separation is a symptom of
structure, and structure is what an adversary exploits. Scored on *custody-primitive suitability* (nonlinear ×
strict-avalanche→0.5) the ranking inverts: all 16 linear rules disqualified; strongest nonlinear candidates
Rule 184 (0.848), Rule 122 (0.741), Rule 161 (0.733); Rule 30 middling (0.617); Rule 90 scores 0.000.

The honest ceiling: avalanche and nonlinearity are **necessary, not sufficient** — this benchmark ranks *toy
suitability* on two properties; it does not run full cryptanalysis and **does not certify any rule as secure**.
The value is the rigorous **negative** — it justifies why FCO uses SHA-256 and records the result so a reviewer
need not re-derive it. (Single master seed 20260708; a multi-seed robustness sweep is stated as supplementary
future work.)

---

## §6. Motivating application — federated computational biology with AI agents as scientists

*Illustrative worked scenario for the Discussion — **not a validated result and not a run performed in a bio
consortium.** Every capability is tagged **[DEMONSTRATED]** (toy/mechanism scale this program) or **[FUTURE]**.
No biological claim is attached to the aggregation-propensity task used as an illustrative substrate. Prior art
conceded first. Grammar-corrected per the RV2-P0-3 sweep.*

**Significance.** As AI models increasingly act as *scientists* — proposing hypotheses, training their own
models, running analyses autonomously and at machine scale — the binding constraint shifts from **generating**
findings to **trusting** them. Federated biology compounds this: the cohorts that would adjudicate a finding
are private (PHI/IP) and legally un-poolable. FCO makes each agent-scientist's training/analysis interior a
recomputable custody object, so a federation admits a contribution **only when it recomputes from named
bytes** — rejecting fabrication and drift at the boundary rather than aggregating them, and comparing results
across labs over **commitments** while raw bytes stay local.

**The gap current tools leave.** Federated learning *aggregates*; it does not admit-or-reject (optimized
model-poisoning defeats Byzantine-robust FL aggregation precisely because aggregation weighs rather than
admits — Shejwalkar & Houmansadr 2021, doi:10.14722/ndss.2021.24498). Provenance (PROV/RO-Crate, SLSA/in-toto)
and even Proof-of-Learning record *that* a step ran; none binds an agent's *multi-root training interior* as
one content-addressed object with reject-not-annotate against a domain oracle (PoL conceded FIRST as nearest
prior art). SMPC/federated analysis compute over hidden data but give no cross-lab, tamper-evident,
route-comparable custody graph over the interiors. Agent output is trusted by reputation, not bytes.

**Worked scenario (illustrative — NOT run):** several labs, each holding a private patient-derived cohort it
cannot share, ask which disordered protein regions are aggregation-prone. Each lab runs an AI agent-scientist
that locally tokenizes/curates, fine-tunes a predictor, and asserts findings. Walking the FCG through it:

1. **Commit, don't ship.** Each agent emits `dataset_root` over its vaulted cohort; two matching roots
   **confirm byte-level agreement on identical input without shipping PHI** — **[DEMONSTRATED]** toy scale
   (`7ccc4780` reproduced on independent machines). Ceiling: a root is a **commitment, not encryption**;
   content-addressing is **not** HIPAA de-identification. The root confirms *sameness*, not privacy.
2. **The interior is a custody object.** Each agent emits the full spine; another lab admits the model **iff it
   recomputes from the named bytes** — **[DEMONSTRATED]** toy scale (G1 CPU bit-identity leaf). PoL conceded
   first.
3. **Reject at the boundary, not aggregate.** A contribution enters only if it recomputes *and* clears the
   shared oracle; a hallucinated, silently retuned, or drifted contribution is **rejected and localized to its
   rung** — **[DEMONSTRATED]** mechanism scale (v1's 0-false-admission runs; the fabricated-value and
   empty-tool-list catches; the fail-closed truth table).
4. **Compare across hardware; catch a bad node.**
   > **[grammar-corrected — "no orphan reference can enter" retired]** The admission policy **can reject
   > references lacking declared ancestors / resolvable targets; it does not establish their truth.** The
   > custody hash confirms same-input/same-recipe route-equivalence across cores **and** unmasks a mislabeled
   > accelerator (a "TPU" node whose committed output equals the known CPU-fallback hash is caught) —
   > **[DEMONSTRATED]** this program. `weights_sha ≠ 6e5b6aa9` is *necessary, not sufficient*; the compute is a
   > supply-chain component whose numerical signature is an **INFERRED, class-not-chip** lane complementing (not
   > replacing) hardware attestation.
5. **Attribute every disagreement.** When two agents disagree (the CAID situation), route comparison localizes
   the divergence to the first differing sub-object and *types* it — **[DEMONSTRATED]** as v1's typed divergence
   localization; **[FUTURE]** at consortium scale.

> **[grammar-corrected — retires "privacy-preserving by construction" and "capability-independent"]** The
> narrowed contribution, in the domain, is the conjunction — a multi-root custody spine over the AI-agent's
> training interior *plus* a head-to-head custody-vs-detector complementarity over one shared substrate, run as
> a determinism ladder that doubles as a compute-provenance detector, over **commitments** so that comparison
> transfers **raw bytes by architecture, subject to equality-leakage / dictionary+metadata attacks and separate
> legal controls** (never "privacy-preserving by construction"). Catching a *maliciously compromised* node is a
> **[FUTURE]/adversarial** lane — a motivated adversary can mimic a signature; what is demonstrated is the
> mislabel/counterfeit catch, not attestation against a faker.

**Honest ledger.** Federated bio consortium on real private cohorts with a real aggregation claim = **[FUTURE]**,
NOT run, no biological claim. Correctness-under-privacy (prove a hidden-data result is *correct*, not just
consistent) = **[OPEN EDGE]** (needs ZK/MPC; Merkle roots are not zero-knowledge). Seal-time integrity (a
federation can agree on a poisoned root) = **[OPEN EDGE]** (trust-on-first-write; the graph proves sameness +
tamper-evidence, not seal-time integrity).

**Prior art conceded FIRST** (all in v1's frozen reference set unless marked new): FL over private cohorts
[ProCanFDL / Cai 2025]; SMPC over genomes [Cho 2018]; PROV/RO-Crate, SLSA/in-toto/sigstore; CAID as the
multi-model route-comparison matrix [Necci 2021; Del Conte 2023]; ZK property proofs [Yadav 2024]; KERI
receipts [Smith 2019]. New v2/v3 refs (CrossRef/PubMed-verified, not in v1's 66-ref list): Proof-of-Learning
[Jia 2021] + PoL-spoofing [Zhang 2022]; agents-as-scientists [Gao 2024, doi:10.1016/j.cell.2024.09.022, PMID
39486399; Boiko 2023, doi:10.1038/s41586-023-06792-0, PMID 38123806]; FL model-poisoning [Shejwalkar &
Houmansadr 2021]. Any *new* citation round-trips through SeedGraph/CrossRef/PubMed before entering the
manuscript.

---

## §7. Unified limitations & claim ceiling

*Reconciles v2 §2.6, v3 §3.6, and the FMO/FCG ceilings into one binding set with the folded-in dispositions.
No new claim is introduced.*

### 7.1 Limitations

**Determinism (v2).** Bit-identity is **CPU single-thread only**; accelerator bit-identity holds within a
device's own silicon (eps-disclosed lane), never across devices. Apple-MPS drift (one fp32 ULP, stable) is
**observed**, mechanism `unknown_hardware_contingent`. Code-match is necessary but not sufficient; only the
CPU-unify rung is lib-clean. 14M at epochs=1 = demonstration substrate.

**Detector arm (v3), at the powered disposition.** Symbolic tamper is mechanism-illustration ONLY; dominance
needs a real-byte both-channel substrate (GAP1) and stays **gated/future**. Superiority over the fair floor is
**not established**: the task is trivially separable (`mean_loss` AUC 1.0, N13), and under the powered
hierarchical confirmatory TOST (δ=0.019916; prereg `63170e81`, aggregate `4ddcb728`, endpoint `7476c282`) the
pooled Arm-B advantage is **statistically nonzero but within the frozen equivalence margin** →
*complementarity ceiling* (N16). Report the margin over `mean_loss`, never a bare AUC, never a seed count.

**Two complementarity claims (never conflated).** Arm-B-vs-fair-floor complementarity is **NOT demonstrated**
(OR-gain ≤ 0 on 14/15 seeds, N14 `52095927`; OR-gain −0.149, φ 0.851, 25/25 co-detected, N15 `fcf31a55`). The
banked Arm-A/Arm-B division of labor (MCC 0.9417, `7e88b6cb`) is a **separate, untouched** claim.

**FMO/FCG.** Novelty is the **profile + reference implementation**, not a new primitive (Appendix A). EXP-027
is a **null capability result**; 0/90 exact-hash rejection is **conformance**, not capability/security/semantic
validity. The anti-downgrade guarantee is **un-mechanized (docstring, not a root preimage) → FUTURE**. The
review-bundle FCG seal is **unsigned** (Recomputed, not Authenticated).

### 7.2 Unified binding ceiling (verbatim, deduplicated)

1. **Custody attests identity, provenance, and OBSERVED behaviour — never the CAUSE of a difference, and never
   semantic correctness.**
2. **CPU single-thread is the sole gating bit-identity claim**; every accelerator rung is a non-gating,
   eps-disclosed peer observation.
3. **Code-match is necessary but not sufficient** for a silicon signature.
4. **Reproducible ≠ interpretable**; a 14M model at epochs=1 is a demonstration substrate, not a capability
   claim; perplexity/accuracy are sanity numbers, never headlines.
5. **"Best" is best on THIS shared task/corpus at epochs=1, never universal.**
6. **Head-to-head dominance rides on a real-byte benchmark (G5), never on an N=1 anecdote — and remains
   GATED/FUTURE** (GAP1). What v3 establishes is the **banked Arm-A/Arm-B complementarity** (MCC 0.9417); the
   Arm-B-vs-fair-floor comparison is *superiority not established / complementarity ceiling* (N16).
7. **The surviving FMO/FCG contribution is a domain-specific custody + admission profile with a reference
   implementation** — novelty of no individual primitive is claimed.
8. **Every root/seal is labeled by claim-grammar level** (Committed / Recomputed / Authenticated / Validated);
   an unsigned seal is never described as signed.

### 7.3 Status of the dominance question (honest, current)

Smoke-scale evidence shows the naive `A OR B` combination does **not** weakly dominate `retune` (MCC-at-a-fixed
-threshold penalises the OR's added false positives — the same failure an FPR-controlled combine fixed at the
three-arm-detector level). Dominance therefore stays **future work, not a result**; this manuscript claims
complementarity (Arm-A/Arm-B) + determinism, **not** dominance.

### 7.4 Future work (stated as future, not claimed)

- **Dominance:** an FPR-controlled *joint* C′ decision + dual AUC/MCC metric + powered paired difference on a
  real-byte both-channel substrate (redesign pre-registered before any confirmatory re-run).
- **Shared-instance complementarity (optional, prereg-gated):** ONE preregistered instance set (clean + all
  tamper classes) scored on BOTH arms per instance, reporting per-arm confusion / paired disagreement / joint
  OR-AND / incremental utility. Does **not** block deposit; the symbolic-poison substrate may never bank
  complementarity.
- **Anti-downgrade guarantee mechanized as a root preimage** (today a docstring/policy convention).
- **CA custody-spine primitive:** the 256-rule negative already justifies SHA-256; a multi-seed robustness
  sweep is future.

### 7.5 Evidence binding (from bytes, never from memory)

- **v2:** `FCG_LADDER_COMPARISON_FULL.json` (`comparison_root 292b7a19…`, 9 rungs, all recompute,
  `unaudited=[]`), CPU gating leaf `f66ce21a`.
- **v3:** Arm A `92711545` (`GATE_G2_pass:true`); Arm B `7e88b6cb` (MCC 0.9417). Powered disposition: prereg
  `63170e81`, aggregate `4ddcb728`, endpoint `7476c282`; D1-corrected re-score `6d6f1649` → pooled `1ec4b48e`.
  Trivial-baseline/OR-gain: `52095927` (N13/N14), `fcf31a55` (N15). D2 correction: `FCO_V3_D2_CORRECTION.DRAFT.json`
  over superseded `0e3ccbd1`.
- **FMO/FCG:** the prior-art crosswalk (Appendix A); the unsigned `SEALED_FCG.json` family.

---

## §8. Model-role statements & AI-use disclosure

**Model role (one sentence per work):**
- **FCO v2** trains a Pythia-14M (GPT-NeoX family) language model from scratch as a controlled experimental
  fixture — a determinism/custody test object, never a capability claim.
- **FCO v3** uses the same Pythia-14M fixture plus a separate Markov loss-trajectory detector; it makes no
  capability or interpretability claim.
- **FMO/FCG** invokes local assistant models as workflow actors only and trains no model.
- **Fragmentum** (cross-repo, Substrata) involves no model; it is a deterministic coordinate-substrate
  generator and a possible future model substrate — reframed and remediated in the `substrata` repo, not here.

**AI-use disclosure (in each release):**
1. All source manuscripts, prompts, data, and negative ledgers are **user-supplied**.
2. Review prose, rewrite proposals, schemas, and drafting assistance are **AI-generated and labeled as such**.
3. SHA-256 values are **integrity digests, not authorship or identity signatures**.

---

## Appendix A — prior-art crosswalk (GAP-10): the narrowed conjunction vs standards

**Claim under defense (narrowed conjunction, NOT a new primitive):** a domain-specific, recursively
content-addressed custody + admission profile that binds scientific/model artifacts, authorization policy,
claim ceilings, and result claims into ONE operational object graph, with a reference implementation and
fail-closed verification workflow. **Concede-first:** novelty for **no** individual mechanism.

| Standard | What it covers | Provides toward the claim (CONCEDE) | Residual delta the profile adds |
|---|---|---|---|
| **W3C PROV** | Entities/activities/agents, derivation, attribution | The general provenance-graph vocabulary | A vocabulary, not intrinsic content-integrity or admission enforcement; the profile binds content digests + fail-closed recompute-gated admission + claim ceilings **into** the graph |
| **RO-Crate / Workflow Run Crate** | Packages data/software/metadata + run provenance | Research-object packaging + run-provenance profile | Describes, does not **enforce** recomputation-gated admission; no recursive claim-ceiling into a single recomputable root |
| **in-toto** | Signed layouts/links, authorized functionaries, verification rules | The authorization-policy + step-verification + signed-attestation side — closest prior art to admission | Governs software supply-chain steps; profile adds a domain-typed scientific spine (dataset→recipe→trajectory→weights→result), claim-ceiling inheritance, first-divergence localization across one graph |
| **SLSA** | Verifiable build provenance | Build-provenance attestation model | Build-focused; no scientific claim ceilings, result claims, or recursive custody of the experiment interior |
| **SWHID** | Intrinsic content-based identifiers for software | The intrinsic content-identity primitive | Identity-only; no admission policy, no graph semantics binding policy + claims |
| **IPLD** | Content-addressed hash-linked Merkle DAGs | The content-addressed DAG structure — **conceded fully** | A data model only; no authorization policy, claim ceiling, or fail-closed admission |
| **C2PA** | Signed, tamper-evident asset claims + content binding | The signed-assertion + content-binding pattern | Media-asset domain; profile applies it to dataset/model/experiment artifacts under recompute-gated admission |
| **Nanopublications** | Small machine-readable assertions with provenance | The atomic citable-assertion + provenance pattern | Makes assertions citable; does not bind recomputable custody of the **generating** artifacts or fail-closed admission |
| **Trusty URIs** | Hash-bearing URIs making RDF artifacts verifiable | "citable atom = hash-verifiable reference" — **conceded** | Verifies a reference's bytes; no recursive claim-ceiling / anti-downgrade or admission across a graph |
| **Composed stack** (in-toto sublayouts + OPA monotone policy + Merkle-DAG diff) | An engineered combination a competent team could assemble | **Expresses every candidate FCO wedge** (the N08 bakeoff finding) | **Honest residual: integration + reference implementation for the scientific-artifact domain, plus first-divergence typing. The anti-downgrade guarantee is currently un-mechanized (docstring, not a root preimage) → FUTURE work, not a present claim.** |

**Survives:** the narrowed conjunction (profile + reference implementation). **Does NOT survive (N08):** any
standalone-mechanism novelty. **FUTURE:** anti-downgrade mechanized as a root preimage. *Descriptive prior-art
positioning only; evidenced by schemas, conformance vectors, and a reference implementation — not by asserting
absence of prior art.*

---

## Appendix B — supersession ledger, errata trail, and provenance manifest

**Supersession (this body supersedes; superseded bodies retained append-only):**

| Superseded body | content_leaf | Superseded by (this file) |
|---|---|---|
| `handoff/MANUSCRIPT_v2_ASSEMBLED_2026-07-10.md` | `d813825a` | §2 |
| `handoff/MANUSCRIPT_v3_ASSEMBLED_2026-07-10.md` | `364dbefe` | §3 (upgraded to N16) |
| `handoff/MANUSCRIPT_MERGED_v2v3_6section_2026-07-12.md` | (merged) | §1–§7 |
| `MANUSCRIPT_PUBLIC_v1.md` (FMO/FCG surfaces) | — | §4 |

**Errata trail (append-only; supersedes, never erases):**
- **D2 CI-direction correction** — `handoff/vnext/FCO_V3_D2_CORRECTION.DRAFT.json` (reason `CI_DIRECTION_BUG`),
  superseding landed `0e3ccbd1`: custody VALID / scientific endpoint INVALID (SCORING-SUPERSEDED). Still
  carries `TODO_PI_RECOMPUTE` fields; `unsigned`. Adopted reading = D1-corrected `[8,11]` re-score → N16.
- **v1 retirement erratum** — `RETIREMENT_ERRATA_v1_2026-07-10.jsonl` (content_leaf `2e347058`); v1 read as
  corrected.
- **K5 pilot / EXP-027** — 3/7 = 0.4286 modal-baseline correction (§4.2); raw pilot retained non-evidentiary.

**Section provenance (each section traces to named source bytes):**

| § | Section | Source (superseded body / delta) |
|---|---|---|
| 0 | Claim grammar | `handoff/vnext/CLAIM_GRAMMAR_GLOSSARY.md` |
| 1 | v1 pointer (frozen) | v1 Zenodo deposit (`paper_cid 291f3364`) |
| 2 | v2 custody of training interior | `…v2_ASSEMBLED` `d813825a` + `patches/FCO_V2_EXACT_REWRITES.md` |
| 3 | v3 custody-as-detector | `…v3_ASSEMBLED` `364dbefe` + `handoff/vnext/DELTA_v3_2026-07-16.md` |
| 4 | FMO/FCG profile | `handoff/vnext/DELTA_FMO_FCG_2026-07-16.md` + `patches/FMO_FCG_EXACT_REWRITES.md` |
| 5 | ECA transparent example | `OUTGOING_chatgpt_review_2026-07-10/03_CA_section.md` (`0aa9c73d`) |
| 6 | Federated comp-bio motivation | `…SECTION_distributed_compbio_AI_scientists.md` (`2d0cb92d`) + RV2-P0-3 sweep |
| 7 | Unified limitations & ceiling | `…UNIFIED_limitations_ceiling_MERGED_2026-07-12.md` (`199b05db`) + DELTA_v3 |
| 8 | Model role + AI disclosure | `handoff/vnext/MODEL_ROLE_AND_AI_DISCLOSURE_2026-07-16.md` |
| A | Prior-art crosswalk | `handoff/vnext/PRIOR_ART_CROSSWALK_2026-07-16.md` |

---

## Gates / ceiling (this document does not self-authorize any of the following)

- **PROPOSED / unsigned / uncertified / unmerged / undeposited.** Signing, sealing, minting a new root, Zenodo
  deposit (as a **new version** of `10.5281/zenodo.21210575`, not a fresh record), arXiv endorsement, license
  resolution (CC BY 4.0 vs BY-NC-ND), and `.backup-hold` release are **operator/PI/counsel** actions
  (remediation items RV2-P0-1, RV2-P1-3, RV2-P4-*, RV2-GATE).
- **Do not edit the frozen signed bodies in place.** This v-next body supersedes them; wording fixes fold in
  here at the next authorized, atomic regeneration (regenerate prompt + manifest + seal together — never patch
  under a stale leaf).
- **Gated files stay pointers** (name + sha256): the FCO object schema/root recipe, the fragment-identity
  construction, the AI-agent admission module, `scripts/build_fmo_custody.py`. Do not reconstruct them.
- **Master release gate (RV2-GATE)** — no package is public-ready until all 8 boxes hold: artifacts present;
  every claim mapped to evidence or labeled hypothesis; raw inputs + executable analysis per numeric claim;
  direction & uncertainty unit-tested; "independent" = separate actor/lineage; public roots Authenticated by a
  documented key path; withheld inputs released/escrowed or claim narrowed; IP/license counsel-reviewed &
  consistent.

*Ceiling: reproducible ≠ interpretable; recompute-not-certify; the tiny model / reference implementation is a
demonstration, never a capability, security-effectiveness, interpretability, or novelty-of-primitive claim.
Assistant-assembled v-next draft; nothing certified, signed, merged, or pushed; `.backup-hold` intact.*
