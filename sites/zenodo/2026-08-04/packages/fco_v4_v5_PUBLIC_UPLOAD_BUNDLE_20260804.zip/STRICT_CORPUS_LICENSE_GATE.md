# Corpus license gate — v4 G1 (FMO-EXP-039r)

**Verdict: PASS** (open-source AND commercial-use AND no share-alike — the LOCKED corpus policy).
Public domain is the **strongest** fit: no two-layer wrapper analysis, no attribution/share-alike obligation.

## Selected corpus (D-b, locked)
- **Vitalogy 1927** — the *Encyclopedia of Health and Home*, 1927 edition; canonical corpus of the
  operator's own **vitaology** project (per `vitaology/LICENSE.md`).
  - **License:** **US public domain**. Commercial use: yes. Share-alike/copyleft: none. Open access: yes.
  - **Bytes:** `vitaology/source/vitalogy_1927.pdf`, sha256 `c64af690…` — **verified equal to its pin**
    `vitalogy_1927.sha256`. Read-only copy-out; vitaology untouched.
  - **Ownership:** operator's own project (biobitworks origin) — no third-party rights question.

## Per-scope determination
| Scope | Verdict | Basis |
| --- | --- | --- |
| Local content-addressed vault + deterministic replay | **ALLOW** | US public domain |
| Private Kaggle dataset (vaulted subset) | **ALLOW** | US public domain; kept private per IP posture |
| Public release (hashes / weights / derived corpus) | **ALLOW** | US public domain — no attribution or share-alike obligation |

## Cross-project move (PI-authorized, conditions)
Bringing vitaology's corpus into `fractal-custody-objects` is a governed data move, authorized by the PI
under binding conditions: clean copy with recorded provenance (source path + `vitalogy_1927.sha256`),
vitaology stays read-only/untouched, PDF→text extraction pinned (determinism surface), and the historical
content disclaimer carried verbatim. See `../corpus/CORPUS_PROVENANCE.md`.

## Content disclaimer (binding)
Not medical advice/diagnosis/treatment. The historical *Vitalogy* corpus contains obsolete, harmful,
unsupported, and offensive medical claims; historical bylines are corpus/provenance data, not evidence
authorities. The FCO claim is **corpus-agnostic** — we hash bytes and test CPU bit-identity, never endorse
or evaluate the text.

## Supersede chain (audit trail)
1. **Prior corpus — REJECTED.** A share-alike-licensed corpus (CDLA-Sharing-1.0) was rejected under the
   LOCKED policy (no share-alike). Rejection evidence retained (name-free) in `decision_log.jsonl` rows;
   the standalone named gate doc was removed per operator directive ("do not mention it again").
2. **Draft pg19 gate — SUPERSEDED.** A first re-prereg drafted on `deepmind/pg19` (Apache-2.0 over PD) was
   frozen prematurely (leaf `1e3a602f`, void-before-data) before D-b was settled; superseded, no data taken.
3. **Current — Vitalogy 1927 (US public domain).** Operative gate; strongest license posture.

## Binding note
The exact 1927 shard selection (byte budget / section rule), pinned extractor version, tokenizer, and
per-shard `sha256` are bound in the run manifest at execution time (RAW_DATA_REPLAY_CONTRACT) — not
fabricated in the prereg. See `../preregs/G1r_FMO-EXP-039r_prereg.json` (leaf `0cfd2e32…`).
