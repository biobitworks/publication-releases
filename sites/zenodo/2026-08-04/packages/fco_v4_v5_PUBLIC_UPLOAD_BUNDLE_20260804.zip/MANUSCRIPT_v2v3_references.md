**Status:** DRAFT — HELD for PI red-team before commit. v2/v3-scoped per operator task-7 ruling (golden-reference/antigence cites EXCLUDED as separate-paper).

**Scope note.** This file lists only citations actually used by the v2/v3 draft content read for this pass:
`MANUSCRIPT_v2v3_SECTION_determinism_ladder.md`, `MANUSCRIPT_v2v3_SECTION_detector_benchmark_RESULTS.md`,
`MANUSCRIPT_v2v3_SECTION_limitations_and_ceiling.md`, `MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md`,
`MANUSCRIPT_v2v3_KEY_POINTS_2026-07-07.md`. v1 (`MANUSCRIPT_PUBLIC_v1.md`) is FROZEN — its 66-entry `## References`
list (lines 639–708) is not renumbered or edited here; `FCO_REFERENCES.jsonl` is not edited here. All golden-reference
/ antigence / NegSel / ECC positioning cites (Hamming, Reed, Merkle-immune-analogy, Roth, Hochschild, Hopfield,
Ninio, Forrest, Timmis, Ji, Greensmith, etc.) are excluded as out-of-scope for this later, separate paper. A small
number of items that appear only in v2/v3's "carried forward from v1 (unchanged core thesis)" restatement bullet
(Nextflow/Snakemake, SWHID/IPLD, C2PA — `MANUSCRIPT_v2v3_KEY_POINTS_2026-07-07.md` lines 16–17) are NOT re-listed
below: that bullet restates v1's own existing positioning language, not a new v2/v3 citation use, and grepping the
five draft files confirms none of those four terms appears anywhere else in the v2/v3 drafts.

---

## A. Already in v1's frozen 66 (reused, do NOT renumber v1)

Every row below was confirmed by `grep` against `MANUSCRIPT_PUBLIC_v1.md`'s numbered `## References` list
(lines 639–708) before being listed — none is asserted from memory. All are drawn from the explicit
"Prior art conceded FIRST" / citation-discipline paragraph in
`MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md` (§X.5), which is where v2/v3 actually cites them.

| v2/v3 use | v1 ref # | v1 entry (verbatim) |
|---|---|---|
| ProCanFDL / Cai 2025 — federated learning over private cohorts (aggregates, does not admit-or-reject) | **64** | Cai X, Boys EL, Noor Z, et al. (2025). Federated Deep Learning Enables Cancer Subtyping by Proteomics. Cancer Discovery. doi:10.1158/2159-8290.CD-24-1488 |
| Cho 2018 — SMPC over genomes (parties compute over hidden data, no admit/reject-by-recompute) | **60** | Cho H, Wu DJ, Berger B (2018). Secure genome-wide association analysis using multiparty computation. Nature Biotechnology 36:547-551. doi:10.1038/nbt.4108 |
| CAID round 1 — Necci 2021, the multi-model route-comparison matrix with no single ground truth | **56** | Necci M, Piovesan D, Tosatto SCE, et al. (2021). Critical assessment of protein intrinsic disorder prediction. Nature Methods 18(5):472-481. doi:10.1038/s41592-021-01117-3 |
| CAID round 2 — Del Conte 2023, model-dependence persists | **57** | Del Conte A, Mehdiabadi M, Bouhraoua A, Miguel Monzon A, Tosatto SCE, Piovesan D (2023). Critical assessment of protein intrinsic disorder prediction (CAID) — Results of round 2. Proteins 91(12):1925-1934. doi:10.1002/prot.26582 |
| PROV — PROV-O (records the wrapper, not the training interior) | **32** | Lebo T, Sahoo S, McGuinness D, et al. (2013). PROV-O: The PROV Ontology. W3C Recommendation (30 Apr 2013). https://www.w3.org/TR/prov-o/ |
| RO-Crate | **33** | Leo S, Crusoe MR, Rodriguez-Navas L, et al. (2024). Recording provenance of workflow runs with RO-Crate. PLOS ONE 19(9):e0309210. doi:10.1371/journal.pone.0309210 |
| SLSA | **42** | OpenSSF (2025). SLSA: Supply-chain Levels for Software Artifacts. Open Source Security Foundation, v1.2 (accessed 2026-06). https://slsa.dev |
| in-toto | **48** | Torres-Arias S, Afzali H, Kuppusamy TK, Curtmola R, Cappos J (2019). in-toto: Providing farm-to-table guarantees for bits and bytes. USENIX Security Symposium. https://www.usenix.org/conference/usenixsecurity19/presentation/torres-arias |
| sigstore | **41** | Newman Z, Meyers JS, Torres-Arias S (2022). Sigstore: Software Signing for Everybody. ACM SIGSAC Conference on Computer and Communications Security (CCS 2022):2353-2367. doi:10.1145/3548606.3560596 |
| Lawson 2021 — data-use ontologies | **61** | Lawson J, Cabili MN, Kerry G, et al. (2021). The Data Use Ontology to streamline responsible access to human biomedical datasets. Cell Genomics 1(2):100028. doi:10.1016/j.xgen.2021.100028 |
| Yadav 2024 — ZK property proofs (FairProof) | **62** | Yadav C, Roy Chowdhury A, Boneh D (2024). FairProof: Confidential and Certifiable Fairness for Neural Networks. arXiv:2402.12572. https://arxiv.org/abs/2402.12572 |
| Smith 2019 — KERI receipts | **63** | Smith SM (2019). Key Event Receipt Infrastructure (KERI). arXiv:1907.02143. https://arxiv.org/abs/1907.02143 |

**12 reused v1 references, spanning 8 distinct v1 numbers** (56, 57, 32, 33, 41, 42, 48, 60–64) — do not renumber
any of them; v1's `## References` stays untouched.

---

## B. NEW v2/v3 citations (verified in `FCO_REFERENCES.jsonl`, NOT in v1)

Continuing v1's numbering from its last entry (**66**). Each of the five is explicitly cited in the v2/v3 draft
text (`MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md` §X.1/§X.2/§X.5 and
`MANUSCRIPT_v2v3_KEY_POINTS_2026-07-07.md` items 1 and 5) and confirmed present in `FCO_REFERENCES.jsonl` (rows
67–71) with a resolved verification string. **Absence-from-v1 double-checked by grep**, not assumed: a naive
`grep -i zhang` on v1 hits only "Wang Y, **Zhang** J, Cai T, et al. (2026)" — v1 ref #52, a co-author on an
unrelated 2026 arXiv survey — which is NOT Zhang 2022's PoL-spoofing paper; `grep -i jia` and `grep -i "gao.*cell"`
/ `grep -i boiko` / `grep -i shejwalkar` return nothing in v1 at all. v1's only "Gao" (ref #19, Gao CA 2023,
*npj Digital Medicine*) is a different author/paper from v2/3's Gao et al. 2024 *Cell*.

67. Jia H, Yaghini M, Choquette-Choo CA, Dullerud N, Thudi A, Chandrasekaran V, Papernot N (2021). Proof-of-Learning: Definitions and Practice. 2021 IEEE Symposium on Security and Privacy (SP). doi:10.1109/sp40001.2021.00106
    — verification (verbatim from `FCO_REFERENCES.jsonl`): `"verified_2026-07-06 crossref-resolved; preprint arXiv:2103.05633 (no DOI on arXiv record)"`

68. Zhang R, Liu J, Ding Y, Wang Z, Wu Q, Ren K (2022). "Adversarial Examples" for Proof-of-Learning. 2022 IEEE Symposium on Security and Privacy (SP). doi:10.1109/sp46214.2022.9833596
    — verification (verbatim): `"verified_2026-07-06 crossref-resolved (title/authors/venue); arXiv id NOT byte-verified this session, cited by DOI"`

69. Gao S, Fang A, Huang Y, et al. (2024). Empowering biomedical discovery with AI agents. Cell 187(22):6125-6151. doi:10.1016/j.cell.2024.09.022
    — verification (verbatim): `"verified_2026-07-08 crossref+pubmed (resolves; PMID 39486399) [seedgraph:citeatom-4d2dd7bbb8837db2 leaf:58aa9cb6622415b3]"`

70. Shejwalkar V, Houmansadr A (2021). Manipulating the Byzantine: Optimizing Model Poisoning Attacks and Defenses for Federated Learning. Proceedings 2021 Network and Distributed System Security Symposium (NDSS), Internet Society. doi:10.14722/ndss.2021.24498
    — verification (verbatim): `"verified_2026-07-08 crossref (resolves; NDSS CS venue, no PMID) [seedgraph:citeatom-4d2dd7bbb8837db2 leaf:6316fe54593ca1b9]"`

71. Boiko DA, MacKnight R, Kline B, Gomes G (2023). Autonomous chemical research with large language models. Nature 624(7992):570-578. doi:10.1038/s41586-023-06792-0
    — verification (verbatim): `"verified_2026-07-08 crossref+pubmed (resolves; PMID 38123806, PMC10733136) [seedgraph:citeatom-4d2dd7bbb8837db2 leaf:cd45e5c24418841c]"`

**Excluded from this section (present in `FCO_REFERENCES.jsonl` but not actually cited in any v2/v3 draft read):**
`nist-2019-fips-140-3` (FIPS 140-3, row 72 of `FCO_REFERENCES.jsonl`). The limitations addendum mentions
"hardware attestation (TPM/TEE)" in prose (`MANUSCRIPT_v2v3_SECTION_limitations_and_ceiling.md` §B.3) but does not
attach a citation marker to it, and `grep -in "nist\|fips"` across all five v2/v3 draft files returns no hit. Per
the operator's "only citations actually used" rule, it is left out here; flag for the PI if a future revision adds
an explicit NIST/FIPS citation to that TPM/TEE sentence.

**5 new verified v2/v3 references (67–71), continuing v1's numbering.**

---

## C. OWED / NOT-YET-VERIFIED (flag, do not fabricate)

Checked against `FCO_REFERENCES.jsonl` by `grep -in`: no match for `shewhart`, `1954`, `biometrika`,
`continuous inspection`, `1931`, `economic control`, or `aiag` anywhere in the file. All three items below are
used in v2/v3 draft prose today but have **no corresponding row** in `FCO_REFERENCES.jsonl` — citation owed —
must be added + verified before the results/methods sections that use it are committed. No DOI is invented here.

1. **Shewhart (1931), *Economic Control of Quality of Manufactured Product*.** Used as the SPC prior-art floor
   in `MANUSCRIPT_v2v3_SECTION_detector_benchmark_RESULTS.md` ("Scored against a **prior-art floor**: Shewhart
   (SPC) + Page CUSUM"; per-condition table rows "SPC — plain Shewhart 3σ" and "SPC — calibrated Shewhart
   (FPR-matched)"). **NOT in `FCO_REFERENCES.jsonl`.** Owed: full bibliographic entry + identifier (this is a
   1931 monograph; likely no DOI exists — verify via publisher/library record, do not invent one) + `verified_*`
   status before the detector-benchmark RESULTS section is committed.

2. **Page ECS (1954), "Continuous Inspection Schemes," Biometrika 41(1/2):100–115.** Used as the CUSUM prior-art
   floor in the same section ("CUSUM — Page (calibrated p97.5)" row). **NOT in `FCO_REFERENCES.jsonl`.** Owed:
   full entry with a real DOI if one is registered for this Biometrika article (check Biometrika/JSTOR/CrossRef —
   do not invent), else cite without DOI and mark `verified_no_doi` per this project's existing convention (cf.
   `crosby-2009-tamper-evident-logging`, v1 ref #13, `"verified_no_doi_usenix"`).

3. **AIAG MSA (Measurement Systems Analysis), 4th ed.** — designation-only, no DOI. Used as the Gauge R&R framing
   citation in `MANUSCRIPT_v2v3_SECTION_determinism_ladder.md` ("Measurement-System-Analysis (Gauge R&R, AIAG MSA
   4th ed. — the designation is the citation; no DOI)") and restated in
   `MANUSCRIPT_v2v3_SECTION_limitations_and_ceiling.md` §B.1. **NOT in `FCO_REFERENCES.jsonl`.** Owed: add a
   designation-only row (publisher: Automotive Industry Action Group; no DOI expected — do not invent one) with a
   `verified_designation_only` (or equivalent honest) status before the MSA-framing paragraphs are committed.

**3 owed / not-yet-verified citations** — none may be added to `FCO_REFERENCES.jsonl` or cited with a DOI until
independently resolved; this file only flags the gap per the operator's no-fabrication instruction.
