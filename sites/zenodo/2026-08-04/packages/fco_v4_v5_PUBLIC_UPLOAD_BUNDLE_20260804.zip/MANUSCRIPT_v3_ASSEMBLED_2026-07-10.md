# FRACTAL CUSTODY OBJECTS — v3: Custody as a Detector — the Benchmark
**Preprint v3 (assembled 2026-07-10).** Extends v1 (Zenodo 10.5281/zenodo.21210575) and v2 (custody of the
training interior). v1/v2 are anchors; v3 ADDS. Every number is quoted from a banked, PI-verified leaf under
pinned `fco_train.custody` (e116f9ff); a `TBD` is never a zero. v1 is an anchor **as corrected** — v3 reads v1
through the v1 retirement erratum (`RETIREMENT_ERRATA_v1_2026-07-10.jsonl`, content_leaf `2e347058`), not as an
intact foundation; each v1 claim v3 relies on is taken in its corrected form.

## Abstract
v3 asks whether deterministic custody (Arm A) and a probabilistic loss-trajectory detector (Arm B), each
committed as a continuous Merkle object, are **complementary** on a shared tamper-detection task — and whether
a combined arm could weakly dominate either alone without losing tamper-evidence. On a shared vaulted
substrate (real G1 CPU leaf `f66ce21a`, `dataset_root 7ccc4780`, R=50/condition), Arm A is perfect on tamper
it can see (`alter_ckpt`/`retune`: MCC 1.0) and blind to byte-valid poison (MCC 0.0); Arm B (Markov binned
loss-trajectory) catches exactly that poison (MCC 0.9417, ROC-AUC 1.0). We do **not** claim Arm B beats a
*polarity-fair* prior-art floor: under an orientation-fair re-scoring (FMO-EXP-041c, result leaf `2934a629`;
independently reproduced from checked-in code `score_g3_polarity_fair.py` and robust across 9 calibration/graded
carves, leaves `678c242c`/`5d39fbb4`), a **two-sided chart on loss first-differences** — orientation fixed from
calibration only — **matches** Arm B on the first fresh generation seed tested (R4.2, leaf `ca439117`;
graded **N=119/119**, Arm B ROC-AUC 0.989 [0.966, 0.997], correlated **DeLong p=0.674**, difference CI
[−0.016, 0.027] includes 0). **A K=5 fresh-generation-seed hardening (FMO-EXP-MULTISEED; corrected aggregate
leaf `aca3d29c`, superseding `d257761c`; external adversarial review `aa47c5ca`) shows this relationship is
SEED-SENSITIVE**, not settled: the paired-bootstrap CI of the difference **excludes 0 on 3/5 fresh seeds**
(Arm B exceeds the floor — EXPLORATORY, with the observed differences at/near the DeLong-detectable difference
at N=119/class and achieved power < 0.80) and **includes 0 on 2/5** (**superiority not established —
inconclusive**, which is *not* a statistical tie/equivalence: no equivalence margin is pre-registered). Under
the frozen rule (≥2 seeds excluding 0) this **re-opens** the "beats the floor" question rather than settling it;
the single-seed reading was a generation-seed artifact. We therefore make **no** superiority claim **and no**
tie/equivalence claim over sequential/change-point detection. The earlier upper-tail-only "beats the floor"
figures (−0.0586 Shewhart / 0.0 CUSUM) remain retracted — they came from an orientation that structurally
misses the *calmer* byte-valid poison. The banked
result is the **complementarity** of Arm A (deterministic custody, tamper-evident) and Arm B (distributional,
poison-catching) — **not** superiority over sequential/change-point detection. Dominance (Arm C',
G5) is **not** claimed: it is gated on a unified both-channel, real-byte-tamper substrate (GAP1) that does not
yet exist, and — per the frozen ruling — dominance may never bank on symbolic tamper.

## 1. The category resolution (from v1/v2)
An FCO custody spine is a **Fractal Custody Process** — deterministic, append-only, acyclic-through-versioning
— NOT a Markov chain. The semantic layer may cycle; the custody layer never does. The detector arms below are
formulated as detector-arm complements to the spine, prereg'd and benchmarked, **never as substitutes** for
recompute-identity in the custody spine.

## 2. The custody-vs-detector benchmark

## What the benchmark scores

One shared substrate: the real G1 CPU graded leaf `f66ce21a` (vault `dataset_root 7ccc4780`, `weights_sha
5beb9c17`, `n_shards 385`); R=50 per condition, matched clean negatives.

- **Arm A — deterministic FCO custody detector** (pure recompute-from-named-bytes; reject-iff-mismatch).
- **Arm B — Markov stochastic loss-trajectory detector** (binned per-step loss levels, transition-surprisal >
  `tau_clean`=p97.5), the complement to Arm A. Scored against a **prior-art floor**: Shewhart (SPC) + Page CUSUM.
- **Arm C' — FPR-controlled combination** (Arm A OR Arm B(P_calib) > `tau_frozen`; H3 weak-dominance).

## Per-condition results (MCC / ROC-AUC / FPR; bootstrap 95% CI on MCC) — NEVER pooled across conditions

| Condition | Arm A (custody) — **BANKED** | Arm B (Markov traj) — **gate-2 cleared** | Arm C' (combo) |
|---|---|---|---|
| **poison** (byte-valid token substitution) | MCC **0.0** [0.0,0.0] · AUC 0.5 · FPR 0.0 — *real H1 ceiling: byte-valid poison is invisible to pure recompute* | MCC **0.9417** [0.87,1.0] · AUC **1.0** · FPR 0.06 (50/50 caught) | `TBD` — blocked (§below) |
| **alter_ckpt** (post-training ckpt tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | *not scored* — post-training tamper leaves the training trajectory = clean, so Arm B ≈ 0 by construction; requires a unified substrate to score, not yet built | `TBD` — blocked |
| **retune** (post-training re-tune tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | *not scored* — same reason | `TBD` — blocked |

**The complementarity is the point:** Arm A is perfect on tamper it can see (`alter_ckpt`/`retune`) and blind to
byte-valid poison; Arm B catches exactly the poison Arm A misses. Each arm's blind spot is the other's strength —
which is *why* a combined Arm C' is the natural closure (and why it needs both channels on the same instances).
*(Power caveat: the AUC cells above are point estimates at N=50/type; every ROC-AUC=1.0/0.5 here is UNDERPOWERED vs
the Hanley-McNeil N≥114/class floor and, at perfect separation, carries a degenerate DeLong CI — see the statistical-
power footnote below and `POWER_MATRIX_G3.json`. These are reproducible point findings, not powered claims.)*

## Arm B vs the prior-art floor (poison condition) — the novelty check (RETRACTED → complementarity)

The frozen prereg (`17cce077`) requires Arm B to **exceed**, not tie, a prior-art floor. Reported at both a fixed
operating point (MCC) and threshold-free (ROC-AUC):

| detector | MCC | FPR | ROC-AUC (DeLong 95% CI) | note |
|---|---|---|---|---|
| **Arm B (Markov, binned levels)** | **0.9417** | 0.06 | **1.0** [1.0, 1.0] † | catches the poison; CI degenerate (perfect separation) |
| SPC — plain Shewhart 3σ (prereg-literal) | 0.0 | **1.0** | 0.0512 [0.0178, 0.1388] | degenerate flag-everything operating point on 351-step trajectories |
| **SPC — calibrated Shewhart (FPR-matched)** | **−0.0586** | 0.04 | 0.0512 [0.0178, 0.1388] | fair floor: threshold = p97.5 of clean max‑\|z\|, same 2.5% FPR budget as Arm B |
| CUSUM — Page (calibrated p97.5) | 0.0 | 0.0 | 0.0076 [0.0021, 0.0271] | fairly calibrated, no power on this poison |

> **† Statistical-power footnote (binding; `POWER_MATRIX_G3.json`, `publication_stats.py`).** DeLong CIs shown are
> per `publication_stats.py`. At **N=50/50** this comparison is **UNDERPOWERED** against the Hanley-McNeil floor of
> **N≥114/class** — no row here is a deposit-ready powered claim. Arm B's ROC-AUC=1.0 gives a **degenerate CI
> [1.0, 1.0]** (perfect separation). In *this* (framing-A, upper-tail) table the correlated DeLong test of Arm B vs
> each floor is significant (p≈2.8e-268 vs Shewhart, ≈0 vs CUSUM) — but that is **orientation-unfair** (the floors
> anti-detect at AUC<0.5). Under the polarity-fair re-scoring (041c) the floor is **not distinguished from** Arm B (inconclusive, not a tie/equivalence; DeLong **p=0.335**, not
> significant), also underpowered at N=25/25. **The framing-A metrics in *this* table remain reproducible point
> findings, not powered claims** (N=50 < 114). Whether Arm B **exceeds** the polarity-fair floor was then tested on
> **K=5 fresh generation seeds** (FMO-EXP-MULTISEED; corrected aggregate `aca3d29c` superseding `d257761c`; external
> review `aa47c5ca`): the result is **SEED-SENSITIVE** — the paired-difference CI excludes 0 on **3/5** seeds and
> includes 0 on **2/5** (**superiority not established — inconclusive**, *not* a statistical tie/equivalence). Powered
> on the PAIRED near-ceiling difference (not AUC-vs-0.5), the observed differences sit at/near the DeLong-detectable
> difference at N=119/class (achieved power < 0.80 on all 5 seeds). So neither a superiority nor a tie claim is
> supported; the framing-A "beats the floor" figures above remain retracted.

**RETRACTED (FMO-EXP-041c): Arm B does not beat a *polarity-fair* floor.** The table's calibrated Shewhart/CUSUM
figures use a **fixed upper-tail** orientation, so their ROC-AUC ≈ 0.05/0.008 is strong signal *in the reversed
orientation* (1 − 0.0512 = 0.9488): byte-valid substitution makes the loss trajectory *calmer*, so upper-tail charts
structurally miss it. That is an **orientation** deficiency, not a power deficiency — and a fair comparator must get
the same omnibus/orientation freedom Arm B's binned Markov already has. Under a polarity-fair re-scoring
(FMO-EXP-041c, leaf `2934a629`; orientation fixed from a disjoint calibration split only, no test-label peek), a
**two-sided Shewhart on loss first-differences MATCHES Arm B** (ROC-AUC 1.0 = 1.0; paired-bootstrap 95% CI of the
difference [0, 0]). This is **independently reproduced from checked-in code** (`score_g3_polarity_fair.py`, leaf
`678c242c`) and **robust across 9 calibration/graded carves** (Arm B 1.0 vs best polarity-fair baseline 0.9904–1.0;
CI of the difference includes 0 in **9/9**; leaf `5d39fbb4`). On this single-generation-seed corpus Arm B does
**not** establish that it exceeds a polarity-fair floor (**superiority not established — inconclusive**; not a claim
of equivalence), so it does **not** clear the prereg's "exceed, not tie" novelty bar over sequential/change-point
detection. What survives is **complementarity**: Arm A is tamper-evident and blind to byte-valid poison, Arm B is
distributional and catches it — a genuine division of labor, not a superiority result. *(Fresh-generation-seed
robustness — R4.2, K=5 — has since RUN: corrected aggregate `aca3d29c`; the exceed/floor relationship is
**seed-sensitive** (3/5 exclude 0, 2/5 include 0), red-team Issue 2 RE-OPENED, EXPLORATORY — not settled in either
direction. Complementarity is unaffected.)*

**Statistical support and the one soft spot (disclosed).** N=50/type, **single generation seed** (test base
`20260805`); the bootstrap (B=2000) resamples those same 50+50 trajectories, so it quantifies metric sampling
variability, not variability across *fresh* training runs. AUC=1.0 reflects **complete class separation** on this
substrate (every poison trajectory scored above every clean one) — but at N=50/type this is **UNDERPOWERED** against a
Hanley-McNeil floor of **N≥114/class** (`publication_stats.py`; audit in `POWER_MATRIX_G3.json`), and perfect
separation yields a **degenerate DeLong CI [1.0, 1.0]**. The MCC bootstrap lower bound (0.869) excludes chance but does
**not** power the AUROC, and the polarity-fair floor comparison (041c) is a **non-significant DeLong difference
(p=0.335)** — **superiority not established (inconclusive)**, not a tie/equivalence and not a superiority. We
therefore report every detector metric here as a reproducible **point finding, not a deposit-ready powered claim**.
The R4.2 rerun at test R=144 → graded ≥114/class has since RUN across K=5 fresh seeds and returned a **seed-sensitive**
result (corrected aggregate `aca3d29c`; Issue 2 RE-OPENED, EXPLORATORY). The natural robustness check is a **second
independent generation seed** scored against the *frozen* Arm B fit (P and `tau_clean` unchanged, prereg-before-data
intact) — run as a held-out generalization test, so a reviewer sees the AUC=1.0 is not a lucky partition. *(The FP=3
→ Arm B's own FPR is 6%, above the 2.5% budget the floors were pinned to; the threshold-free AUC is the fairer
headline than the MCC on the FPR axis.)*

## What is NOT yet scored (honest blockers, not omissions)

- **Arm C' / G4r (H3 weak dominance).** H3 requires `MCC(C') ≥ max(MCC(A),MCC(B))` on *every* type in {poison,
  alter_ckpt, retune}. A real Arm C' needs each test instance to carry **both** a real custody status (Arm A) and a
  real loss trajectory (Arm B) across all three tamper types. The G2 substrate (custody, symbolic tamper) and the
  G3 substrate ({clean,poison} real trajectories, no custody channel) are **disjoint** — a unified both-channel
  substrate does not exist yet. It has NOT been fabricated by stitching the two.
- **G5 dominance.** BLOCKED on **GAP1**: Arm A's tamper is SYMBOLIC (`weights_fidelity:
  hash_level_real_with_symbolic_tamper`), admissible for the Arm-A mechanism demo ONLY. Per the prereg ruling,
  **dominance may never bank on symbolic tamper** — real raw-shard / real-checkpoint byte tamper must be wired and
  its taxonomy pre-registered first; no such harness exists (`no *.shard files / no raw checkpoints committed`).
- Consequence: **G4r-real and G5 are the same GAP1-gated frontier.** A mechanism-illustration Arm C' could be built
  on the symbolic substrate, but it would carry the G2 claim tier (mechanism-illustration), never the H3 dominance
  claim — so it is deferred rather than dressed up as a result.

## Binding ceilings on this table (carried into the caption at assembly)

1. **Symbolic tamper is mechanism-illustration ONLY; dominance needs real-byte tamper (GAP1).**
2. Custody proves identity/provenance/OBSERVED behavior — never CAUSE, never semantic correctness. A detector cell
   is not a custody proof of correctness.
3. "Best" is best on THIS shared task/corpus at epochs=1, never universal; reproducible ≠ interpretable; the 14M
   model is a demonstration substrate.
4. Dominance rides on the benchmark (G5), never on the N=1 anecdote.

## Evidence binding
Arm A quoted from `92711545…` (`GATE_G2_pass: true`, audited clean). Arm B + the floor sub-table quoted from
`7e88b6cb…` (gate-2 cleared, human-PI-pending; fit substrate `25ca2389`, test set `3f5d65ba`/`49a7f666`, poison
mechanism `7d138a56`, binning [8,11]). Every `TBD`/blocked cell will be filled ONLY from a landed, PI-audited
G4r/G5 leaf built on a real both-channel (and, for dominance, real-byte-tamper) substrate — never from memory,
never from the synthetic-trajectory Arm B/C numbers the G2 run also computed.


## 3. Motivating application — federated computational biology
*(Full scenario in the companion section MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md.)*
The benchmark's target setting: distributed AI-scientist agents contributing to a shared knowledge graph,
where custody localizes which contributed atom diverged and the detector arm flags trajectory-level poison a
recompute check cannot see. The claim ceiling holds — auditable provenance and error localization support
faster science; they do not validate a therapeutic, replace trials, or make a treatment safe.

## 4. v3 Limitations & claim ceiling
Carries the four binding ceilings of the benchmark table verbatim:
1. Symbolic tamper is mechanism-illustration ONLY; dominance needs real-byte tamper (GAP1).
2. Custody proves identity/provenance/OBSERVED behaviour — never CAUSE, never semantic correctness.
3. "Best" is best on THIS shared task/corpus at epochs=1, never universal; reproducible ≠ interpretable.
4. Dominance rides on the benchmark (G5), never on an N=1 anecdote.
One disclosed soft spot: Arm B is a **single generation seed** (N=50/type); the bootstrap quantifies metric
sampling variability, not fresh-run variability. The natural robustness check — a second independent
generation seed scored against the *frozen* Arm B fit — is stated as a held-out generalization test, not yet
run.

## 5. Evidence binding
Arm A: leaf `927115456c` (`GATE_G2_pass:true`, PI-audited clean). Arm B + floor sub-table: leaf `7e88b6cb`
(gate-2 cleared, PI-verified recompute MATCH this session; fit substrate `25ca2389`, clean test `3f5d65ba`,
poison test `49a7f666`, poison mechanism `7d138a56`, binning [8,11]). Every blocked cell fills ONLY from a
landed PI-audited G4r/G5 leaf on a real both-channel substrate — never from memory, never from the synthetic
Arm B/C numbers the G2 run also computed.
