# Upload Index

- Package: `fco_v4_v5`
- Generated: `2026-08-04T03:13:51+00:00`
- Claim scope: publication-version framing approved with PASS/FAIL/ABSTAIN table; N1/N3 content promotion blocked
- Do not upload any `do_not_upload/` content.
- Claim promotion is limited to publication-version framing; forbidden scientific/capability claims remain blocked.

## Files

- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/MANUSCRIPT_v3_ASSEMBLED_2026-07-10.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/MANUSCRIPT_MERGED_v2v3_6section_2026-07-12.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/MANUSCRIPT_vNEXT_ASSEMBLED_2026-07-16.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/MANUSCRIPT_v4_DRAFT.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/MANUSCRIPT_v2v3_KEY_POINTS_2026-07-07.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/ZENODO_METADATA_DRAFT_FROM_PREVIOUS.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/STRICT_CORPUS_LICENSE_GATE.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/PACKAGE_CONTENT_SOURCE_STATS_20260804.md`
- `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready/PACKAGE_READY_RECEIPT_20260804.md`
