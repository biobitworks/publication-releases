# Seeds of Truth — 2026-07-29 (verified atoms only)

Every load-bearing sentence below carries at least one verified atom (result leaf, proof id, or receipt). The document is its own evidence: each sentence decomposes into skeleton + bindings (see SENTENCE_LOGIC_REPORT), and its leaf recomputes from the atoms.

## Custody spine

1. The FCO v1 fractalization replays bit-identically across machines: 7/7 figure fractal roots and the manuscript knowledge root recomputed on a clean Studio venv in FMO-EXP-062 [leaf:8995e241].
2. The G-BRIDGE protocol rerun reproduced all four gates with the banked values (0/3000 false admits, Wilson-95 0.00128, bit-identical theta, tamper-evident retune) [leaf:e5c3c3a6].
3. The FPR-controlled G4r confirmatory passed its single pre-registered attempt: Arm C' scored MCC 1.0/1.0/1.0 at FPR 0 on all three tamper types [leaf:b702089a].
4. The R5 confirmatory landed with the preregistered within-margin verdict: a real but practically negligible Arm-B edge (95% CI [0.00684, 0.013755] inside delta 0.019916) [leaf:19dc6ac8].
5. The agent-signature benchmark prereg FMO-EXP-061 was frozen after operator id confirmation, binding TPR 1.0 on structural faults and FPR 0 on the no-op [leaf:93e627ad].

## External sources (SeedGraph-verified)

6. Jansma's Tarski argument — no definable probe over a model's representation space captures truth — is custody-verified as prior art for the custody-not-truth ceiling [proof:pubatom-4c80773126594d1a].
7. The ralphmerkle.com full-site import verified 52 members, including the primary source for the public/private pointer route, Certified1979.pdf [proof:pubatom-c0395679aae34502].
8. Gwern's replication essay is custody-verified with 47 DOIs and 297 external links catalogued, grounding the replication-guardian bar [proof:pubatom-651c28f1c82d418a].
9. All three source packets pass the 14-gate import/ingest completeness audit after closeout remediation [audit:COMPLETENESS_AUDIT_2026-07-29].

## Honest negatives and drift

10. The B3 pilot found the continued checkpoint degrades 14.5 percent relative to the frozen parent on 32 locked N2 shards, so the prior continue recipe fails prior preservation [leaf:26968ed7].
11. The earlier FMO-060 improvement reading was synthetic-batch in-distribution, not prior preservation, and is banked as such [registry:FMO-EXP-060-B3-ABSTAIN-SYNTHETIC].
12. The v1/v2 packages show three self-containment failures: non-deterministic builds, four-cid churn, and a manifest leaf recipe that does not recompute even in the signed Zenodo zip [forensics:SELF_CONTAINED_PACKAGE_STANDARD_2026-07-29].
13. The v4 deposit therefore requires a self-containment gate: RECIPES.json, shipped builder, and a passing RECOMPUTE script [gate:V4-14].

## Governance state

14. The v4 manuscript is assembled and its content leaf recomputes, but the deposit is blocked on dossier seal, PI signature, ed25519 ratification, license, counsel, backup-hold release, staged metadata, and operator approval [audit:fco_v4v5_zenodo_readiness_2026-07-29].
15. The v5 preprint has not started: it requires the powered B3 correction on a non-synthetic corpus before any Antigentic micro-EXP [prompt:PROMPT-FMO-063].
16. The ollarma route lane was degraded by a stale selection artifact; the refresh bench was relaunched on magicSTUDIObox with corrected PATH [receipt:2026-07-29].
