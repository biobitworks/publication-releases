# Publication FCG Binding — FCO v4/v5 + Vithia

- Status: `PASS_WITH_NONSHIPPING_LIMITATIONS`
- Binding leaf: `sha256:8dfcbda78a58e3fee29c7305039a1f5b0303f0d36286709ec331d87ea2601ec2`
- Claim ceiling: `REPRODUCIBLE_PROVENANCE_COMPLETE_ONLY_NO_CAPABILITY_NO_INTERPRETABILITY`
- Live KG writeback: `False`
- External upload: `False`
- New scientific claims authored: `False`

## Copied Source Assets

- `SEEDS_OF_TRUTH_2026-07-29.md` ← `/Users/byron/projects/active/fractal-custody-objects/handoff/seeds_of_truth_2026-07-29/SEEDS_OF_TRUTH_2026-07-29.md` sha256 `2547d7d8355646ae7ede4e5e509d0253f2889d09fcfc365295e82ddd5ba9396d`
- `SEEDS_OF_TRUTH_SENTENCE_LOGIC_REPORT.json` ← `/Users/byron/projects/active/fractal-custody-objects/handoff/seeds_of_truth_2026-07-29/SENTENCE_LOGIC_REPORT.json` sha256 `129541de6a3d3aae75769d4d2d2aab153f4791df068d8d7bd9090dee73877a19`
- `MANUSCRIPT_v2v3_references.md` ← `/Users/byron/projects/active/fractal-custody-objects/MANUSCRIPT_v2v3_references.md` sha256 `cba36e37f4464bcda8cd5bb32fefdd779c000274ae783ea169dbf3a15ed8b740`

## Limitation Handling

- `N1-null`: ship as failure/abstain plus remediation, not as promoted capability claim
- `FMO-076-N1`: private evidence banked; N1 remains ABSTAIN and is not promoted
