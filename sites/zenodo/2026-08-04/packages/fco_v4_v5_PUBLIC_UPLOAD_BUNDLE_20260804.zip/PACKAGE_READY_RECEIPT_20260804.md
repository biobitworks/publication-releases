# Package Ready Receipt — FCO v4/v5 + Vithia

- Status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:bc35dda55069112f054204a2425325ac130af396c9c2bfd09c91c66460eb219a`
- Stats: `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/evidence/PACKAGE_CONTENT_SOURCE_STATS_20260804.json`
- Upload bucket: `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/upload_when_ready`
- Evidence bucket: `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/evidence`
- Metadata bucket: `/Users/byron/projects/active/fractal-custody-objects/outbox/260802-fco-v4-v5-vithia-hold/metadata`
- Boundary: private/staged only; operator controls public upload and visibility.

## Warnings

- None.
