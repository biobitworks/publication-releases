# FCO preprint — updated KEY POINTS for v2 / v3 (draft, 2026-07-07; status ledger refreshed 2026-07-09 post ladder-close)

**Scope:** these are the updated key points for the NEXT Zenodo version. **v1 stays frozen** (deposit
`10.5281/zenodo.21210575`, `paper_cid 291f3364…`) — this file does not touch it; it drafts what v2/v3 adds.
Claim ceiling from v1 carries over verbatim: **reproducible ≠ interpretable; proof-of-concept, not a
validated result; the tiny model is a determinism/provenance demonstration, never a capability claim;
perplexity is never a headline.** Concede prior art FIRST in every claim.

## Carried forward from v1 (unchanged core thesis)
- FCO = a bounded object whose typed leaves are files/steps/params/outputs/redacted pointers, whose root is
  a content-addressed identifier that is **also a knowledge-graph node**, with edges encoding provenance,
  custody, and an explicit claim ceiling.
- **Admit-iff-recomputes-from-named-bytes; reject-not-annotate; recursive** (knowledge accrues only over
  previously admitted knowledge — the replication crisis rejected at the boundary).
- Two runs are **route-comparable to their first divergent node**.
- Positioned as an **integration layer** over PROV/RO-Crate, Nextflow/Snakemake, SLSA/in-toto/C2PA,
  SWHID/IPLD — not a new hash/tree/engine/standard.

## NEW in v2 / v3 (what the training + accelerator work adds)

1. **Custody extended from data pipelines to model TRAINING (the multi-root spine).** A from-scratch
   Pythia-14M (GPT-NeoX) run over a fully-vaulted public-domain corpus, with the spine
   `dataset_root → recipe_root → trajectory_root → weights_root → result_leaf`, every node recomputable
   from named bytes. This makes an AI model's *interior* a custody object, not just its I/O.
   **Status: the CPU single-thread bit-identity leaf is the graded claim, PI-verified from bytes (gate
   closed).** Concede Proof-of-Learning (Jia 2021) FIRST — it is the nearest prior art (deterministic
   recompute-of-training). FCO's novelty is the **multi-root custody spine + reject-not-annotate**, not
   deterministic recompute per se.

2. **Merkle-root-as-vault: custody-by-hash.** `tokenize(corpus, pinned BPE)` is a deterministic,
   recomputable derivation edge → `dataset_root`. Any machine that reproduces the root has **proven it holds
   the vaulted corpus without shipping it**. **Ceiling (load-bearing): a root is a COMMITMENT, not
   encryption** — tokens decode to text, so confidentiality lives in *where the bytes live* (local-first),
   never in the hash. (Public-domain 1927 corpus: publish freely.)

3. **A determinism ladder over a single vaulted input — and custody as a hardware-provenance detector.**
   The SAME `dataset_root` (`7ccc4780…`) is trained on CPU / GPU / TPU / Apple-MPS. **Same input, different
   deterministic core → different committed output hash**, so:
   - CPU single-thread is bit-identical (unique `weights_sha` = 1/8) — the sole gating claim.
   - Accelerators are eps-DISCLOSED (unique = 8/8; measured drift, e.g. Apple-MPS fp32 ulp = **2⁻²³** on two
     independent machines; TPU bf16 diverges at MXU scale) — **never relabeled bit-identical.**
   - The custody hash itself **unmasks a mislabeled accelerator**: a run claiming "TPU" whose `weights_sha`
     equals the known CPU-fallback hash is caught as a CPU run — a demonstrated counterfeit-component catch.
   **Status: 9-rung ladder CLOSED (2026-07-08/09; `comparison_root 292b7a19`). CPU single-thread gating leaf PI-verified; GPU-T4, real TPU-v5e, TPU cross-session, and 4 Apple-MPS rungs all PI-audited clean; CPU-unify removed the code_sha confound (code change inert on the CPU path). The GPU cross-session reproduction later closed CLEAN on a real Tesla T4 (leaf `075fb4fa`, PI-audited clean 2026-07-09, tracked in the ledger outside the 9-rung comparison object); the earlier "P100 deferral" was root-caused as an unset Kaggle `machine_shape` tag (defaults to P100), not a lottery — the P100 fail-fasts stand only as a documented device-gate negative.**

4. **Head-to-head custody-vs-detector benchmark (the narrowed novelty claim).** A shared detection task
   (clean / poisoned-shard / altered-checkpoint / silent-retune) scored MCC/ROC-AUC/FPR over R≥50 seeded
   runs/type, comparing the **deterministic FCO custody detector** vs a **stochastic (Markov) detector** vs
   their FPR-controlled combination, over a shared knowledge-atom substrate. Disclosed ceiling: FCO catches
   root-changing tampers (MCC~1, FPR=0 by construction) and **MISSES byte-valid poison** — predicted, not
   hidden. **Status: harness built + Arm A validated at hash-level fidelity against the real leaves;
   full R≥50 benchmark pending.** This head-to-head is the novelty, not custody or detection alone.

5. **Motivating application — federated computational biology with AI agents as scientists (Discussion,
   NOT a result).** A worked, illustrative scenario: several labs, each running an AI agent-scientist that
   fine-tunes an aggregation-propensity predictor on its own *private* patient-derived cohort and asserts
   findings autonomously. The gap current tools leave (grounded in v1 §2): **federated learning aggregates
   trusted contributions; it does not admit-or-reject one by recompute against an oracle** (ProCanFDL),
   provenance records the wrapper not the training interior, and agent output is trusted by reputation not
   bytes. FCO closes it by making each agent's **training interior a recomputable custody object** — the
   federation **admits rather than aggregates** (reject-not-annotate at the federation boundary), compares
   over **commitments** (raw cohorts stay local — Merkle-root-as-vault), attributes disagreement to a typed
   rung (the CAID multi-model matrix, now with a training interior), and **catches a mislabeled
   compute node** (the fake-TPU custody catch). One-line: *as models act as scientists at machine scale, the
   binding constraint shifts from generating findings to trusting them; FCO makes an agent-scientist
   accountable to bytes.* Every capability tagged DEMONSTRATED (toy scale) vs FUTURE (consortium not run);
   no biological claim attached. Full draft:
   `MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md`. Concede prior art FIRST: ProCanFDL/Cho-SMPC/
   CAID are already in v1's refs; PoL [Jia 2021 + Zhang 2022] are NEW v2/v3 cites (CrossRef-resolved in
   `FCO_REFERENCES.jsonl`, not in v1's 66-ref list).

6. **Distributed / supply-chain framing (Discussion / future work — NOT a result).** The FCG enables
   federated comparison over **commitments** (labs exchange roots, raw bytes stay local); a training run is
   an assembled artifact whose accelerator is a supply-chain component with a numerical fingerprint. The
   hardware-signature layer is an **INFERRED** lane (confidence-bounded, class-level, spec-derivable — NOT
   physical attestation; complements TPM/TEE). Correctness-under-privacy needs ZK/MPC on top of the graph —
   an open edge. Hardware-ID is an **FIP (inference-layer) posterior**, class-not-chip, prereg-if-rate —
   never in the custody spine. Decentralization removes the trusted verifier, **not** the trust-on-first-write
   seal (a federation can agree on a poisoned root). Concede SLSA/in-toto/sigstore/SBOM/PoL/hardware-attestation
   **+ numerical-reproducibility (ReproBLAS-lineage) + hardware-fingerprinting**. Detail:
   `.planning/goals/fco-v4-continuous-merkle/DESIGN_distributed_FCG_provenance.md`.

## Updated one-line significance (for the v2/v3 abstract)
> Beyond route-comparing data pipelines (v1), v2/v3 makes an AI model's **training interior** a recomputable
> custody object (multi-root spine, from-scratch on a vaulted corpus), runs it as a **determinism ladder**
> over one vaulted input across CPU/GPU/TPU/MPS — where the custody hash itself detects a mislabeled
> accelerator — and benchmarks the deterministic custody detector head-to-head against a stochastic one.
> Still a proof-of-concept over established standards; still reproducible ≠ interpretable.

## Honest status ledger (so no key point overclaims at deposit time)
| Claim | Status @ 2026-07-07 |
|---|---|
| CPU single-thread bit-identity (G1, `7ccc4780`, leaf `f66ce21a`) | **PI-VERIFIED, gate closed** |
| Apple-MPS eps-disclosed peer rungs (2 machines + 2 cross-session, 2⁻²³ stable) | **PI-audited clean (4 rungs)** |
| Custody catches mislabeled-accelerator (fake-TPU) | **demonstrated** |
| GPU-T4 (`9e7b3979`) + real TPU-v5e (`c808f6ff`) + TPU cross-session (`06299c47`) eps-disclosed rungs | **PI-AUDITED CLEAN, landed** |
| CPU-unify (`1142cb47`): code-confound removed (e13ed0f1→053686f4 inert on CPU, `5beb9c17` reproduces) | **PI-AUDITED CLEAN** |
| 9-rung determinism ladder, all anchoring `7ccc4780` | **CLOSED (9 rungs PI-audited clean per `PI_AUDIT_STATUS_LEDGER.json`, `comparison_root 292b7a19`; the GPU cross-session reproduction later closed clean on a real T4, leaf `075fb4fa` — the "P100" draws were an unset `machine_shape` tag, not a lottery)** |
| Three-arm detector benchmark (G2–G5) | **prereg frozen (`0c0f9105`); harness built; Arm A hash-fidelity shown; full run pending** |
| Distributed FCG / hardware-signature inference | **Discussion / future work only** |
