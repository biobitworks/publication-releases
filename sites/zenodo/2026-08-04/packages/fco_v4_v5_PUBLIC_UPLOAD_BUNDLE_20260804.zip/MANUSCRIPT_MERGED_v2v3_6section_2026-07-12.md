# Fractal Custody Objects — merged manuscript (v1→v6 arc), DRAFT ASSEMBLY 2026-07-12

> **Status: DRAFT deterministic assembly.** This document is a byte-faithful concatenation of the individually
> signed/finalized section sources listed in the provenance manifest (appendix). It is NOT itself signed; it is
> assembled here so the eventual single publication is one file. Two items remain before it is deposit-final,
> both GATED: (1) the §4 CA figure-reference form (this draft embeds the **canonical claude-science-signed** CA
> body `0aa9c73d`, whose figure token does not resolve outside claude.ai — if the deposit-portable relative-path
> form `431a8c71` is chosen instead, ONLY that one figure-reference line changes); (2) human-PI cryptographic
> re-sign of every section leaf (see `PI_RESIGN_PAYLOAD_v2v3_2026-07-12.json`). **v1 stays frozen**
> (Zenodo `10.5281/zenodo.21210575`, `paper_cid 291f3364`) and is referenced, not rewritten. Nothing here is a
> new claim; each section carries its own already-established claim ceiling.



---

# §1. v1 — self-verifying publication object model (FROZEN)

*v1 is the immutable published base (Zenodo `10.5281/zenodo.21210575`, `paper_cid 291f3364`, zip sha256 `916bf4c4`). It is referenced here, never embedded or rewritten. See the v1 deposit for the object model, `scripts/`, `figures/`, custody manifests, and `VERIFY.md`.*


---

# §2. v2 — custody of the training interior

# FRACTAL CUSTODY OBJECTS — v2: Custody of the Model Training Interior
**Preprint v2 (assembled 2026-07-10).** Extends the frozen v1 deposit (Zenodo 10.5281/zenodo.21210575,
paper_cid 291f3364). v1 is the frozen anchor; v2 ADDS and never contradicts or re-deposits it. Every numeric
claim below is quoted from a banked result-leaf that recomputes from bytes under the pinned
`fco_train.custody` (sha256 e116f9ff); none is restated from memory. v2 reads v1 through the v1 retirement
erratum (`RETIREMENT_ERRATA_v1_2026-07-10.jsonl`, content_leaf `2e347058`) — v1 is the frozen anchor **as
corrected**, never presented as an intact foundation; each v1 claim v2 relies on is taken in its corrected form.

## Abstract
v1 established the Fractal Custody Object: a content-addressed root that doubles as a knowledge-graph node,
with typed custody leaves, admit-iff-recomputes-from-named-bytes / reject-not-annotate / recursive admission,
and an explicit claim ceiling. v2 extends custody from data pipelines to the **interior of model training**.
A from-scratch Pythia-14M (GPT-NeoX architecture) trained over a fully-vaulted public-domain corpus is
committed as a multi-root spine — `dataset_root → recipe_root → trajectory_root → weights_root → result_leaf`
— every node recomputable from named bytes. Nine training runs of the identical configuration across CPU,
GPU-T4, TPU-v5e, and Apple-MPS form a determinism ladder read as a Measurement-System-Analysis of the
training run as an instrument. The CPU single-thread rung is bit-identical and is the sole gating claim; every
accelerator rung is an eps-disclosed peer. The load-bearing ceiling: reproducible ≠ interpretable — a 14M
model at epochs=1 is a determinism/provenance demonstration substrate, never a capability claim.

## 1. What v1 froze (carried verbatim, never re-opened)
The FCO object model; admit-iff-recomputes / reject-not-annotate / recursive admission; route-comparable
divergence localization; positioning as an INTEGRATION LAYER over PROV/RO-Crate, SLSA/in-toto/C2PA,
SWHID/IPLD — not a new hash or tree. v1's binding ceiling carries over: proof-of-concept; proves custody +
recomputation, NOT truth/authorship/efficacy; a recomputing root can bind a false fact.

## 2. What v2 adds — custody of the training interior

**2.1 The multi-root spine.** A from-scratch Pythia-14M run over a vaulted corpus commits the spine
`dataset_root → recipe_root → trajectory_root → weights_root → result_leaf`, each node recomputable from named
bytes. This makes a model's *interior* a custody object, not just its I/O. **Prior art conceded first:**
Proof-of-Learning (Jia et al. 2021) is the nearest neighbour (deterministic recompute-of-training). FCO's
novelty is the multi-root custody spine + reject-not-annotate over that interior, not deterministic recompute
per se. Status: the CPU single-thread bit-identity leaf `f66ce21a` is the graded claim, PI-verified from bytes
(gate closed; leaf recomputes MATCH, `dataset_root 7ccc4780`, `weights_sha 5beb9c17`).

**2.2 Merkle-root-as-vault: custody by hash.** `tokenize(corpus, pinned GPT-NeoX BPE)` is a deterministic,
recomputable derivation edge producing `dataset_root`. Any machine that reproduces the root has proven it
holds the vaulted corpus **without shipping the corpus as bytes**. Load-bearing ceiling: a root is a
**COMMITMENT, not encryption** — tokens decode to text, so confidentiality lives in where the corpus is
stored, not in the root. Fine for public-domain corpora; a hard line at PHI (a custody hash of PHI is still
PHI).

## The 9-rung ladder — what it is
Nine training runs of the identical G1 Pythia-14M configuration, each anchoring the vaulted corpus
(`dataset_root 7ccc4780`), were executed across CPU, GPU-T4, TPU-v5e, and Apple-MPS. Every landed leaf
recomputes from bytes; all three negative controls fire on every rung; the CPU single-thread rung is
bit-identical and is the **sole gating determinism claim**. (Canonical: 9 rungs, `all_anchor_vault=true`,
`all_recompute=true`, `unaudited=[]`; `comparison_root 292b7a19…`.)

## Per-rung claims — each with its binding ceiling
- **CPU 1-thread** (`f66ce21a`): bit-identical, GATING. *Ceiling: the sole graded bit-identity claim; all
  accelerator rungs are eps-disclosed peers, never gating.*
- **GPU-T4** (`9e7b3979`) / **TPU-v5e** (`c808f6ff`): reproduce bit-identically **within their own silicon**
  (`used_warn_only` lane). *Ceiling: eps-disclosed; the three deterministic cores (CPU/T4/TPU) produce THREE
  DISTINCT `weights_sha` (`5beb9c17` / `4724b237` / `a6b3eb9e`) over the identical input — cross-device
  bit-identity does NOT hold and is not claimed.*
- **Apple-MPS ×2 + cross-session ×2** (`ba001731` / `5363f314` / `5ea8fc98` / `62fe9e57`): drift by exactly
  one fp32 ULP (`2⁻²³ = 1.1920928955078125e-07`), stably across sessions (`unique_weights_sha = 8`).
  *Ceiling: this is OBSERVED bounded drift; its MECHANISM is recorded `unknown_hardware_contingent` — no
  ablation isolated a cause, and none is asserted.*
- **TPU cross-session** (`06299c47`): `weights_sha a6b3eb9e` reproduces across a fresh session. *Ceiling: the
  env string is byte-identical to the XLA-on-CPU-fallback signature; `weights ≠ fallback` is
  NECESSARY-not-sufficient, and real-device operation is proven SEPARATELY by the `tpu_diag` report
  (v5litepod-8) — the env string alone never proves TPU-real.*
- **CPU-unify** (`1142cb47`): under the unified accelerator code (`053686f4`), CPU `weights_sha` reproduces
  `5beb9c17` with the env byte-identical to the graded leaf. *Ceiling: this removes the `code_sha` confound
  FOR THE CPU RUNG ONLY, with nil `lib_versions` residual; it does NOT license a pure-silicon claim for the
  accelerator rungs, whose lib stacks still vary.*
- **GPU cross-session — NOT a rung.** Three consecutive P100 draws; deferred as a documented negative. The T4
  leaf `9e7b3979` stands. This is a quota/pragmatic deferral, NOT a claim that a T4 is unattainable.

## Metrological framing: the ladder as a Measurement-System-Analysis (Gauge R&R)

Read as a measurement problem rather than a training problem, the ladder above is a
Measurement-System-Analysis (Gauge R&R, AIAG MSA 4th ed. — the designation is the citation; no DOI) of the
training run itself as the measurement instrument, with the vaulted corpus (`dataset_root 7ccc4780`) as the
fixed part being measured repeatedly. Naming this standard is a concession, not a novelty claim: FCO does not
invent repeatability/reproducibility analysis — every published MSA study runs the same decomposition. FCO's
addition is narrower and stays within the ceilings already stated above: each individual measurement in the
study — each rung — is itself a recomputable custody object (leaf + `weights_sha` +
`PI_AUDIT_STATUS_LEDGER.json` `status=clean`), not a logged number taken on faith.

In MSA vocabulary: **REPEATABILITY** is within-core variation — reruns of the identical vaulted input on the
same execution core. On CPU single-thread, GPU-T4, and TPU-v5e, repeatability within each core's own silicon
is exactly zero (`used_warn_only` lane; CPU alone remains gating, per the ceiling above). On Apple-MPS,
repeatability is bounded rather than zero: four independent draws (`ba001731` / `5363f314` / `5ea8fc98` /
`62fe9e57`, `unique_weights_sha = 8`) show drift of exactly one fp32 ULP (`2⁻²³`), stable across sessions. This
is observed bounded drift — not determinism under a relabeled name — and its mechanism is recorded
`unknown_hardware_contingent`: no ablation isolated a cause, and none is asserted here.

**REPRODUCIBILITY** is across-core variation over that same identical input: CPU, GPU-T4, and TPU-v5e each
reproduce bit-identically within themselves yet land on three distinct `weights_sha`
(`5beb9c17` / `4724b237` / `a6b3eb9e`) for the one vaulted corpus. In MSA terms this is a disclosed
reproducibility gap between measurement systems, not a repeatability failure — each core is individually a
stable gauge; the gauges simply disagree with one another, exactly as the per-rung ceilings above already
state.

This framing changes no ceiling already stated. Custody here proves the OBSERVED repeatability and
reproducibility statistics of the training-run-as-instrument, never their cause, and never that any one core's
`weights_sha` is the "correct" measurement. CPU single-thread remains the sole gating bit-identity claim;
GPU-T4, TPU-v5e, and Apple-MPS remain eps-disclosed peers under MSA vocabulary exactly as under ladder
vocabulary — MSA supplies a name a reviewer already trusts for what is being measured, not a stronger claim
about what the measurement means. A 14M-parameter, epochs=1 run is, in MSA terms, a demonstration substrate
for studying the instrument's measurement properties; reproducible ≠ interpretable, and this MSA framing
asserts nothing about the quality, correctness, or interpretability of what the instrument produces.

## The four binding ceilings (verbatim)
1. Custody proves identity, provenance, and OBSERVED behavior — never the CAUSE of a difference, and never
   semantic correctness.
2. CPU single-thread is the sole gating bit-identity claim; every accelerator rung is an eps-disclosed peer.
3. Code-match is NECESSARY but NOT SUFFICIENT for a silicon signature — `lib_versions` must also match or be
   argued non-causal; only the CPU-unify rung is lib-clean.
4. The ladder demonstrates same-vaulted-input REPRODUCIBILITY across execution environments; reproducible ≠
   interpretable, and a 14M model at epochs=1 is a DEMONSTRATION substrate, not a capability claim.

## Evidence binding
Every rung line above cites (a) its `result_leaf`, (b) `PI_AUDIT_STATUS_LEDGER.json` `status=clean`, and (c)
the canonical `FCG_LADDER_COMPARISON_FULL.json` (`comparison_root 292b7a19…`) as the single source. The
manuscript quotes that object; it does not restate numbers from memory.

<!-- Drift-trap self-check (PI will reject on sight — confirmed avoided):
 - no unscoped "deterministic training" (always scoped to CPU single-thread / fixed reduction order);
 - no "hardware fingerprint" for CPU-vs-accelerator (code/lib confounded);
 - no MPS row phrased "deterministic under X" (said "observed bounded drift");
 - the 2⁻²³ mechanism is NOT asserted (unknown_hardware_contingent);
 - no "reduces errors / catches poison" (that is G2+ detector territory, not the ladder). -->


## 4. v2 Limitations & claim ceiling (reconciled)
*(This section reconciles two earlier addendum drafts into one canonical statement.)*

**4.1 Limitations.**
- The determinism claim is CPU-single-thread only; accelerator bit-identity holds within a device's own
  silicon (eps-disclosed lane), never across devices — the three deterministic cores land three distinct
  `weights_sha` for the one vaulted corpus.
- The Apple-MPS drift (one fp32 ULP, 2⁻²³, stable across sessions) is OBSERVED; its mechanism is recorded
  `unknown_hardware_contingent` — no ablation isolated a cause, and none is asserted.
- Code-match is necessary but not sufficient for a silicon signature; only the CPU-unify rung is lib-clean.
- The model is 14M parameters at epochs=1 — a demonstration substrate for studying custody of the training
  instrument, not a trained-capability artifact.

**4.2 Claim ceiling (verbatim, four bindings).**
1. Custody proves identity, provenance, and OBSERVED behaviour — never the CAUSE of a difference, and never
   semantic correctness.
2. CPU single-thread is the sole gating bit-identity claim; every accelerator rung is an eps-disclosed peer.
3. Code-match is necessary but not sufficient for a silicon signature.
4. The ladder demonstrates same-vaulted-input reproducibility across environments; reproducible ≠
   interpretable; a 14M model at epochs=1 is a demonstration substrate, not a capability claim.

## 5. Evidence binding
Every rung cites its `result_leaf`, `PI_AUDIT_STATUS_LEDGER.json status=clean`, and the canonical
`FCG_LADDER_COMPARISON_FULL.json` (`comparison_root 292b7a19f5730fe667670925425b7dddbc50d1d05e78212d7883ee7f00312efa`,
9 rungs, all recompute, unaudited=[]) — independently PI-verified from source bytes this session. v2 quotes
that object; it does not restate numbers from memory.

## 6. Future work (stated as future, not claimed)
The 256-rule elementary-cellular-automaton custody benchmark (supplementary) tests whether any CA rule could
serve as a custody-spine primitive; the negative result — no CA rule matches SHA-256's cryptanalytic maturity;
linear rules such as Rule 90 are disqualified despite perfect detector separation — is reported to justify the
SHA-256 choice, not to propose a replacement.



---

# §3. v3 — custody-as-detector benchmark (complementarity)

# FRACTAL CUSTODY OBJECTS — v3: Custody as a Detector — the Benchmark
**Preprint v3 (assembled 2026-07-10).** Extends v1 (Zenodo 10.5281/zenodo.21210575) and v2 (custody of the
training interior). v1/v2 are anchors; v3 ADDS. Every number is quoted from a banked, PI-verified leaf under
pinned `fco_train.custody` (e116f9ff); a `TBD` is never a zero. v1 is an anchor **as corrected** — v3 reads v1
through the v1 retirement erratum (`RETIREMENT_ERRATA_v1_2026-07-10.jsonl`, content_leaf `2e347058`), not as an
intact foundation; each v1 claim v3 relies on is taken in its corrected form.

## Abstract
v3 asks whether deterministic custody (Arm A) and a probabilistic loss-trajectory detector (Arm B), each
committed as a continuous Merkle object, are **complementary** on a shared tamper-detection task — and whether
a combined arm could weakly dominate either alone without losing tamper-evidence. On a shared vaulted
substrate (real G1 CPU leaf `f66ce21a`, `dataset_root 7ccc4780`, R=50/condition), Arm A is perfect on tamper
it can see (`alter_ckpt`/`retune`: MCC 1.0) and blind to byte-valid poison (MCC 0.0); Arm B (Markov binned
loss-trajectory) catches exactly that poison (MCC 0.9417, ROC-AUC 1.0). We do **not** claim Arm B beats a
*polarity-fair* prior-art floor: under an orientation-fair re-scoring (FMO-EXP-041c, result leaf `2934a629`;
independently reproduced from checked-in code `score_g3_polarity_fair.py` and robust across 9 calibration/graded
carves, leaves `678c242c`/`5d39fbb4`), a **two-sided chart on loss first-differences** — orientation fixed from
calibration only — **matches** Arm B on the first fresh generation seed tested (R4.2, leaf `ca439117`;
graded **N=119/119**, Arm B ROC-AUC 0.989 [0.966, 0.997], correlated **DeLong p=0.674**, difference CI
[−0.016, 0.027] includes 0). **A K=5 fresh-generation-seed hardening (FMO-EXP-MULTISEED; corrected aggregate
leaf `aca3d29c`, superseding `d257761c`; external adversarial review `aa47c5ca`) shows this relationship is
SEED-SENSITIVE**, not settled: the paired-bootstrap CI of the difference **excludes 0 on 3/5 fresh seeds**
(Arm B exceeds the floor — EXPLORATORY, with the observed differences at/near the DeLong-detectable difference
at N=119/class and achieved power < 0.80) and **includes 0 on 2/5** (**superiority not established —
inconclusive**, which is *not* a statistical tie/equivalence: no equivalence margin is pre-registered). Under
the frozen rule (≥2 seeds excluding 0) this **re-opens** the "beats the floor" question rather than settling it;
the single-seed reading was a generation-seed artifact. We therefore make **no** superiority claim **and no**
tie/equivalence claim over sequential/change-point detection. The earlier upper-tail-only "beats the floor"
figures (−0.0586 Shewhart / 0.0 CUSUM) remain retracted — they came from an orientation that structurally
misses the *calmer* byte-valid poison. The banked
result is the **complementarity** of Arm A (deterministic custody, tamper-evident) and Arm B (distributional,
poison-catching) — **not** superiority over sequential/change-point detection. Dominance (Arm C',
G5) is **not** claimed: it is gated on a unified both-channel, real-byte-tamper substrate (GAP1) that does not
yet exist, and — per the frozen ruling — dominance may never bank on symbolic tamper.

## 1. The category resolution (from v1/v2)
An FCO custody spine is a **Fractal Custody Process** — deterministic, append-only, acyclic-through-versioning
— NOT a Markov chain. The semantic layer may cycle; the custody layer never does. The detector arms below are
formulated as detector-arm complements to the spine, prereg'd and benchmarked, **never as substitutes** for
recompute-identity in the custody spine.

## 2. The custody-vs-detector benchmark

## What the benchmark scores

One shared substrate: the real G1 CPU graded leaf `f66ce21a` (vault `dataset_root 7ccc4780`, `weights_sha
5beb9c17`, `n_shards 385`); R=50 per condition, matched clean negatives.

- **Arm A — deterministic FCO custody detector** (pure recompute-from-named-bytes; reject-iff-mismatch).
- **Arm B — Markov stochastic loss-trajectory detector** (binned per-step loss levels, transition-surprisal >
  `tau_clean`=p97.5), the complement to Arm A. Scored against a **prior-art floor**: Shewhart (SPC) + Page CUSUM.
- **Arm C' — FPR-controlled combination** (Arm A OR Arm B(P_calib) > `tau_frozen`; H3 weak-dominance).

## Per-condition results (MCC / ROC-AUC / FPR; bootstrap 95% CI on MCC) — NEVER pooled across conditions

| Condition | Arm A (custody) — **BANKED** | Arm B (Markov traj) — **gate-2 cleared** | Arm C' (combo) |
|---|---|---|---|
| **poison** (byte-valid token substitution) | MCC **0.0** [0.0,0.0] · AUC 0.5 · FPR 0.0 — *real H1 ceiling: byte-valid poison is invisible to pure recompute* | MCC **0.9417** [0.87,1.0] · AUC **1.0** · FPR 0.06 (50/50 caught) | `TBD` — blocked (§below) |
| **alter_ckpt** (post-training ckpt tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | *not scored* — post-training tamper leaves the training trajectory = clean, so Arm B ≈ 0 by construction; requires a unified substrate to score, not yet built | `TBD` — blocked |
| **retune** (post-training re-tune tamper) | MCC **1.0** [1.0,1.0] · AUC 1.0 · FPR 0.0 | *not scored* — same reason | `TBD` — blocked |

**The complementarity is the point:** Arm A is perfect on tamper it can see (`alter_ckpt`/`retune`) and blind to
byte-valid poison; Arm B catches exactly the poison Arm A misses. Each arm's blind spot is the other's strength —
which is *why* a combined Arm C' is the natural closure (and why it needs both channels on the same instances).
*(Power caveat: the AUC cells above are point estimates at N=50/type; every ROC-AUC=1.0/0.5 here is UNDERPOWERED vs
the Hanley-McNeil N≥114/class floor and, at perfect separation, carries a degenerate DeLong CI — see the statistical-
power footnote below and `POWER_MATRIX_G3.json`. These are reproducible point findings, not powered claims.)*

## Arm B vs the prior-art floor (poison condition) — the novelty check (RETRACTED → complementarity)

The frozen prereg (`17cce077`) requires Arm B to **exceed**, not tie, a prior-art floor. Reported at both a fixed
operating point (MCC) and threshold-free (ROC-AUC):

| detector | MCC | FPR | ROC-AUC (DeLong 95% CI) | note |
|---|---|---|---|---|
| **Arm B (Markov, binned levels)** | **0.9417** | 0.06 | **1.0** [1.0, 1.0] † | catches the poison; CI degenerate (perfect separation) |
| SPC — plain Shewhart 3σ (prereg-literal) | 0.0 | **1.0** | 0.0512 [0.0178, 0.1388] | degenerate flag-everything operating point on 351-step trajectories |
| **SPC — calibrated Shewhart (FPR-matched)** | **−0.0586** | 0.04 | 0.0512 [0.0178, 0.1388] | fair floor: threshold = p97.5 of clean max‑\|z\|, same 2.5% FPR budget as Arm B |
| CUSUM — Page (calibrated p97.5) | 0.0 | 0.0 | 0.0076 [0.0021, 0.0271] | fairly calibrated, no power on this poison |

> **† Statistical-power footnote (binding; `POWER_MATRIX_G3.json`, `publication_stats.py`).** DeLong CIs shown are
> per `publication_stats.py`. At **N=50/50** this comparison is **UNDERPOWERED** against the Hanley-McNeil floor of
> **N≥114/class** — no row here is a deposit-ready powered claim. Arm B's ROC-AUC=1.0 gives a **degenerate CI
> [1.0, 1.0]** (perfect separation). In *this* (framing-A, upper-tail) table the correlated DeLong test of Arm B vs
> each floor is significant (p≈2.8e-268 vs Shewhart, ≈0 vs CUSUM) — but that is **orientation-unfair** (the floors
> anti-detect at AUC<0.5). Under the polarity-fair re-scoring (041c) the floor is **not distinguished from** Arm B (inconclusive, not a tie/equivalence; DeLong **p=0.335**, not
> significant), also underpowered at N=25/25. **The framing-A metrics in *this* table remain reproducible point
> findings, not powered claims** (N=50 < 114). Whether Arm B **exceeds** the polarity-fair floor was then tested on
> **K=5 fresh generation seeds** (FMO-EXP-MULTISEED; corrected aggregate `aca3d29c` superseding `d257761c`; external
> review `aa47c5ca`): the result is **SEED-SENSITIVE** — the paired-difference CI excludes 0 on **3/5** seeds and
> includes 0 on **2/5** (**superiority not established — inconclusive**, *not* a statistical tie/equivalence). Powered
> on the PAIRED near-ceiling difference (not AUC-vs-0.5), the observed differences sit at/near the DeLong-detectable
> difference at N=119/class (achieved power < 0.80 on all 5 seeds). So neither a superiority nor a tie claim is
> supported; the framing-A "beats the floor" figures above remain retracted.

**RETRACTED (FMO-EXP-041c): Arm B does not beat a *polarity-fair* floor.** The table's calibrated Shewhart/CUSUM
figures use a **fixed upper-tail** orientation, so their ROC-AUC ≈ 0.05/0.008 is strong signal *in the reversed
orientation* (1 − 0.0512 = 0.9488): byte-valid substitution makes the loss trajectory *calmer*, so upper-tail charts
structurally miss it. That is an **orientation** deficiency, not a power deficiency — and a fair comparator must get
the same omnibus/orientation freedom Arm B's binned Markov already has. Under a polarity-fair re-scoring
(FMO-EXP-041c, leaf `2934a629`; orientation fixed from a disjoint calibration split only, no test-label peek), a
**two-sided Shewhart on loss first-differences MATCHES Arm B** (ROC-AUC 1.0 = 1.0; paired-bootstrap 95% CI of the
difference [0, 0]). This is **independently reproduced from checked-in code** (`score_g3_polarity_fair.py`, leaf
`678c242c`) and **robust across 9 calibration/graded carves** (Arm B 1.0 vs best polarity-fair baseline 0.9904–1.0;
CI of the difference includes 0 in **9/9**; leaf `5d39fbb4`). On this single-generation-seed corpus Arm B does
**not** establish that it exceeds a polarity-fair floor (**superiority not established — inconclusive**; not a claim
of equivalence), so it does **not** clear the prereg's "exceed, not tie" novelty bar over sequential/change-point
detection. What survives is **complementarity**: Arm A is tamper-evident and blind to byte-valid poison, Arm B is
distributional and catches it — a genuine division of labor, not a superiority result. *(Fresh-generation-seed
robustness — R4.2, K=5 — has since RUN: corrected aggregate `aca3d29c`; the exceed/floor relationship is
**seed-sensitive** (3/5 exclude 0, 2/5 include 0), red-team Issue 2 RE-OPENED, EXPLORATORY — not settled in either
direction. Complementarity is unaffected.)*

**Statistical support and the one soft spot (disclosed).** N=50/type, **single generation seed** (test base
`20260805`); the bootstrap (B=2000) resamples those same 50+50 trajectories, so it quantifies metric sampling
variability, not variability across *fresh* training runs. AUC=1.0 reflects **complete class separation** on this
substrate (every poison trajectory scored above every clean one) — but at N=50/type this is **UNDERPOWERED** against a
Hanley-McNeil floor of **N≥114/class** (`publication_stats.py`; audit in `POWER_MATRIX_G3.json`), and perfect
separation yields a **degenerate DeLong CI [1.0, 1.0]**. The MCC bootstrap lower bound (0.869) excludes chance but does
**not** power the AUROC, and the polarity-fair floor comparison (041c) is a **non-significant DeLong difference
(p=0.335)** — **superiority not established (inconclusive)**, not a tie/equivalence and not a superiority. We
therefore report every detector metric here as a reproducible **point finding, not a deposit-ready powered claim**.
The R4.2 rerun at test R=144 → graded ≥114/class has since RUN across K=5 fresh seeds and returned a **seed-sensitive**
result (corrected aggregate `aca3d29c`; Issue 2 RE-OPENED, EXPLORATORY). The natural robustness check is a **second
independent generation seed** scored against the *frozen* Arm B fit (P and `tau_clean` unchanged, prereg-before-data
intact) — run as a held-out generalization test, so a reviewer sees the AUC=1.0 is not a lucky partition. *(The FP=3
→ Arm B's own FPR is 6%, above the 2.5% budget the floors were pinned to; the threshold-free AUC is the fairer
headline than the MCC on the FPR axis.)*

## What is NOT yet scored (honest blockers, not omissions)

- **Arm C' / G4r (H3 weak dominance).** H3 requires `MCC(C') ≥ max(MCC(A),MCC(B))` on *every* type in {poison,
  alter_ckpt, retune}. A real Arm C' needs each test instance to carry **both** a real custody status (Arm A) and a
  real loss trajectory (Arm B) across all three tamper types. The G2 substrate (custody, symbolic tamper) and the
  G3 substrate ({clean,poison} real trajectories, no custody channel) are **disjoint** — a unified both-channel
  substrate does not exist yet. It has NOT been fabricated by stitching the two.
- **G5 dominance.** BLOCKED on **GAP1**: Arm A's tamper is SYMBOLIC (`weights_fidelity:
  hash_level_real_with_symbolic_tamper`), admissible for the Arm-A mechanism demo ONLY. Per the prereg ruling,
  **dominance may never bank on symbolic tamper** — real raw-shard / real-checkpoint byte tamper must be wired and
  its taxonomy pre-registered first; no such harness exists (`no *.shard files / no raw checkpoints committed`).
- Consequence: **G4r-real and G5 are the same GAP1-gated frontier.** A mechanism-illustration Arm C' could be built
  on the symbolic substrate, but it would carry the G2 claim tier (mechanism-illustration), never the H3 dominance
  claim — so it is deferred rather than dressed up as a result.

## Binding ceilings on this table (carried into the caption at assembly)

1. **Symbolic tamper is mechanism-illustration ONLY; dominance needs real-byte tamper (GAP1).**
2. Custody proves identity/provenance/OBSERVED behavior — never CAUSE, never semantic correctness. A detector cell
   is not a custody proof of correctness.
3. "Best" is best on THIS shared task/corpus at epochs=1, never universal; reproducible ≠ interpretable; the 14M
   model is a demonstration substrate.
4. Dominance rides on the benchmark (G5), never on the N=1 anecdote.

## Evidence binding
Arm A quoted from `92711545…` (`GATE_G2_pass: true`, audited clean). Arm B + the floor sub-table quoted from
`7e88b6cb…` (gate-2 cleared, human-PI-pending; fit substrate `25ca2389`, test set `3f5d65ba`/`49a7f666`, poison
mechanism `7d138a56`, binning [8,11]). Every `TBD`/blocked cell will be filled ONLY from a landed, PI-audited
G4r/G5 leaf built on a real both-channel (and, for dominance, real-byte-tamper) substrate — never from memory,
never from the synthetic-trajectory Arm B/C numbers the G2 run also computed.


## 3. Motivating application — federated computational biology
*(Full scenario in the companion section MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md.)*
The benchmark's target setting: distributed AI-scientist agents contributing to a shared knowledge graph,
where custody localizes which contributed atom diverged and the detector arm flags trajectory-level poison a
recompute check cannot see. The claim ceiling holds — auditable provenance and error localization support
faster science; they do not validate a therapeutic, replace trials, or make a treatment safe.

## 4. v3 Limitations & claim ceiling
Carries the four binding ceilings of the benchmark table verbatim:
1. Symbolic tamper is mechanism-illustration ONLY; dominance needs real-byte tamper (GAP1).
2. Custody proves identity/provenance/OBSERVED behaviour — never CAUSE, never semantic correctness.
3. "Best" is best on THIS shared task/corpus at epochs=1, never universal; reproducible ≠ interpretable.
4. Dominance rides on the benchmark (G5), never on an N=1 anecdote.
One disclosed soft spot: Arm B is a **single generation seed** (N=50/type); the bootstrap quantifies metric
sampling variability, not fresh-run variability. The natural robustness check — a second independent
generation seed scored against the *frozen* Arm B fit — is stated as a held-out generalization test, not yet
run.

## 5. Evidence binding
Arm A: leaf `927115456c` (`GATE_G2_pass:true`, PI-audited clean). Arm B + floor sub-table: leaf `7e88b6cb`
(gate-2 cleared, PI-verified recompute MATCH this session; fit substrate `25ca2389`, clean test `3f5d65ba`,
poison test `49a7f666`, poison mechanism `7d138a56`, binning [8,11]). Every blocked cell fills ONLY from a
landed PI-audited G4r/G5 leaf on a real both-channel substrate — never from memory, never from the synthetic
Arm B/C numbers the G2 run also computed.



---

# §4. CA — transparent real-world example + 256-rule primitive benchmark

# Manuscript v2/v3 — SECTION: Elementary cellular automata as a transparent custody example
**Assembled 2026-07-10.** Companion demonstration + a preregisterable design benchmark. Deterministic
(master seed 20260708); every figure and dataset recomputes. Supplementary datasets:
SUPP_DATA_eca_256rule_custody_matrix.csv, SUPP_DATA_eca_hyperfcg_record.json.

## Why a cellular automaton
The 14M training interior (v2) is opaque: you cannot *see* a poison propagate through weights. An elementary
cellular automaton (ECA) is the transparent analogue — a fully deterministic system where each committed row
is visible, so poison propagation, custody-root divergence, and detector separation can be shown directly on
the page. The ECA is a **demonstration substrate**, not a claim that CA dynamics model training.

## Each rule as an FCO and an FCG
Every ECA rule is committed two ways over the same seed evolution (grid of T=96 rows × S=96 cells):
- **FCO** — the whole grid as one content-addressed root, `fco = leaf(grid)`.
- **FCG** — a two-axis graph: a **horizontal** root over rows (spatial state at each time step) and a
  **vertical** root over columns (one cell's history over time), combined `fcg = node(hz_root, vt_root)`.
- **Hyper-FCG** — all 256 rule-FCG roots merkled into one super-object (`hyper_fcg_root 270a0556…`), the
  object that lets every rule be compared under one custody root. All 256 FCO roots and all 256 FCG roots are
  distinct: the custody layer separates every rule deterministically (FPR=0), independent of any detector.

## The worked question: is any CA rule a better custody primitive than SHA-256?
A natural design question — could Rule 30 (or Rule 90, 110, 184) replace the SHA-256 Merkle construction as
the custody spine? We benchmarked **all 256 rules** on the properties that actually matter for a
tamper-evidence primitive, per-rule, deterministically, with N=200/group.

**The finding inverts the naive reading (Figure, panel a).** Scored on *detector separation* — can a
statistical screen tell a poison seed from a legitimate-edit seed — Rule 90 is perfect (Cliff's δ = 1.0). But
Rule 90 is **linear** (XOR of neighbours): trivially invertible, zero preimage resistance, and a poor
avalanche of 0.097 — far below the ideal 0.5 and worse than every other rule we highlight (Rules 30/110/184),
though not the global minimum (32 linear/trivial rules sit lower at 0.0001). Its perfect separation is a symptom of structure, and structure is what an
adversary exploits. Scored on *custody-primitive suitability* (nonlinear × strict-avalanche→0.5), the ranking
inverts: all 16 linear rules are disqualified; the strongest nonlinear candidates are Rule 184 (0.848), Rule
122 (0.741), Rule 161 (0.733); Rule 30 is a legitimate but middling candidate (0.617), and Rule 90 scores
0.000.

**Horizontal vs vertical (panel b).** Which FCG axis catches poison is rule-dependent: vertical separation
wins for 183 of 256 rules, horizontal for 66. Rule 184 is the clean case (vertical δ=1.00 vs horizontal 0.68)
— its traffic-like dynamics propagate down columns, so the per-cell-history axis is the sensitive one.

## The answer, with its ceiling
**No ECA rule should replace SHA-256 as the custody spine.** The benchmark's value is the rigorous negative,
not a replacement:
- **Linear rules (90, 150, …) are disqualified outright** — invertibility defeats tamper-evidence regardless
  of how well they separate poison.
- **Rule 30**, the best-known nonlinear candidate (proposed by Wolfram as a CSPRNG), has published
  cryptanalysis against it as a stream cipher (Meier–Staffelbach correlation attack) — a documented weakness,
  no security proof.
- **SHA-256** carries decades of cryptanalysis, a 256-bit security level, and the ≥128-bit tamper-evidence
  floor established in v1/v2.

The honest ceiling: avalanche and nonlinearity are **necessary, not sufficient** — this benchmark ranks *toy
suitability* on two properties; it does not run full cryptanalysis and does not certify any rule as secure. It
justifies why FCO uses SHA-256 and records the negative result so a reviewer does not have to re-derive it.
Where the ECAs *do* earn a place is (i) as this transparent demonstration substrate and (ii) as a possible
distributional detector-arm feature (the Markov/Bayesian arm of v3), never as the spine.

## How we test (method, for supplement)
Per rule: (1) linearity by affine-over-GF(2) check on the 8-neighbourhood truth table (deterministic, no data);
(2) strict-avalanche as mean differing-cell fraction after a single central-bit flip; (3) poison-vs-safe
distributional separation as Cliff's δ over |Δ row-density| (horizontal) and |Δ column-activity| (vertical),
N=200/group, safe = one-bit legitimate edit, poison = random reseed; (4) literature cryptanalysis as a
disqualifier that a benchmark cites rather than rediscovers. **Disclosed soft spot:** single master seed
(20260708); a multi-seed robustness sweep is stated as supplementary future work.

## Figure
![256 ECA rules as custody objects: detector separation vs cryptographic-spine suitability]({{artifact:art_008e042c-fb7d-44a1-89bc-6cfd0d95832c}})

**Figure.** All 256 ECA rules benchmarked as candidate custody objects (deterministic, seed 20260708,
N=200/group). **(a)** Detector separation (best axis, Cliff's δ) vs custody-primitive suitability: linear rules
(red ×) collapse to zero suitability despite high separation — Rule 90 sits at bottom-right (δ=1.0,
suitability 0). **(b)** Horizontal vs vertical FCG separation per rule; the diagonal marks axis parity. **(c)**
Top nonlinear candidates by custody suitability. The single-sentence message: **the rule that separates poison
best is not the rule that makes the best custody spine** — cryptographic hardness, not distributional
separability, is what a tamper-evidence primitive requires.



---

# §5. Motivating application — federated comp-bio with AI agents as scientists

# Manuscript v2/v3 — SECTION DRAFT: Motivating application — federated computational biology with AI agents as scientists

**Scope / status.** Draft of a new **Discussion / motivating-application** section for the NEXT Zenodo version
(v2/v3). **v1 stays frozen** (deposit `10.5281/zenodo.21210575`). This is an *illustrative worked scenario*
that motivates the v2/v3 mechanisms; **it is not a validated result and not a run we performed in a bio
consortium.** Every load-bearing capability it invokes is tagged **[DEMONSTRATED]** (shown at
proof-of-concept toy scale this program) or **[FUTURE]** (motivated, not run). Claim ceiling travels
verbatim: reproducible ≠ interpretable; proof-of-concept, not a validated result; the tiny model is a
determinism/provenance demonstration, never a capability claim; perplexity is never a headline; **no
biological claim is attached** to the aggregation-propensity task used as an illustrative substrate.
Concede prior art FIRST.

---

## X.0 One-line significance (for the v2/v3 abstract / intro hook)

> As AI models increasingly act as *scientists* — proposing hypotheses, training their own models, and
> running analyses autonomously and at machine scale — the binding constraint shifts from **generating**
> findings to **trusting** them. Federated biology compounds this: the cohorts that would adjudicate a
> finding are private and cannot be pooled. FCO makes each agent-scientist's **training/analysis interior**
> a recomputable custody object, so a federation admits a contribution **only when it recomputes from named
> bytes** — rejecting fabrication and drift at the boundary rather than aggregating them, and comparing
> results across labs over **commitments** while the raw bytes stay local.

## X.1 The setting

Computational biology is moving from *pipelines that people run* to *analyses that agents run*. The
biomedical field is already framing this explicitly as **"AI scientists"** — collaborative agents that
integrate models and tools with experimental platforms to plan discovery workflows and self-assess their
own knowledge gaps [Gao 2024, *Cell* 187(22):6125–6151, doi:10.1016/j.cell.2024.09.022] — and autonomous
agents already design, plan, and execute real experiments end-to-end [Boiko 2023, *Nature* 624:570–578,
doi:10.1038/s41586-023-06792-0]. AI models now read the literature, propose mechanistic hypotheses,
fine-tune their own predictors on local data, and emit candidate findings faster than any lab can
adjudicate them by hand. Two structural facts make this a custody problem rather than a compute problem:

1. **The trust bottleneck.** When generation is cheap, the scarce step is deciding which machine-produced
   findings may enter the shared record. This is the replication crisis at machine speed: an
   un-recomputed, oracle-uncleared assertion that is cited and built upon (§Significance, v1).

2. **The data cannot move.** The cohorts that would adjudicate a finding — patient-derived proteomes,
   aging tissue panels, disorder/aggregation measurements — are private (PHI/IP) and legally un-poolable.
   Federated deep learning over private cohorts is already deployed for exactly this reason
   [ProCanFDL / Cai 2025, *v1 ref 64*], and secure multi-party computation over genomes lets parties
   compute over data they cannot see [Cho 2018, *v1 ref 60*].

A concrete, already-cited instance of the disagreement this produces: in **CAID**, 43 intrinsic-disorder
predictors scored on the same 646 DisProt proteins give markedly different per-residue calls, and the
model-dependence persists into CAID round 2 [Necci 2021; Del Conte 2023, *v1 refs 56–57*]. That is,
in effect, a **multi-model route-comparison matrix** with no single ground truth — the exact object v1's
route-comparison was built to attribute. Now let each of those predictors also be an *agent that trains on
its own private cohort and asserts findings autonomously,* and the matrix acquires a training interior and
a trust boundary.

## X.2 The gap current tools leave (grounded in v1 §2)

The paper's own survey already names why the established stack does not close this — restated here for the
agents-as-scientists, federated case:

- **Federated learning aggregates; it does not admit-or-reject.** ProCanFDL trains a shared model by
  *aggregating trusted contributions* without pooling raw data, but it "neither admits-or-rejects an
  individual contribution by recompute against an oracle, nor localizes a divergence to its rung, nor
  attributes it to source — so a fabricated or drifted contribution is absorbed, not rejected" (v1 §2,
  verbatim frame). This is not a hypothetical failure mode: optimized model-poisoning attacks defeat
  Byzantine-robust FL aggregation rules precisely because aggregation weighs contributions rather than
  admitting-or-rejecting each by recompute against an oracle [Shejwalkar & Houmansadr 2021,
  doi:10.14722/ndss.2021.24498]. **Admission, not aggregation, is the missing primitive.**

- **Provenance records the wrapper, not the interior.** PROV/RO-Crate, SLSA/in-toto, and even
  Proof-of-Learning record *that* a training step ran and (PoL) that it recomputes; none binds an AI
  agent's *multi-root training interior* (`dataset_root → recipe_root → trajectory_root → weights_root →
  result_leaf`) as one content-addressed custody object with reject-not-annotate semantics against a
  domain oracle. (PoL is conceded FIRST as the nearest prior art — deterministic recompute-of-training;
  see `[[fco-claim-shape-concession-conjunction]]`.)

- **No privacy-preserving comparison of the interior.** SMPC and federated analysis let parties compute
  over hidden data, but they do not give a *cross-lab, tamper-evident, route-comparable custody graph* over
  the agents' training interiors — where two labs can prove they trained on the identical vaulted corpus
  without shipping it, compare drift across accelerators, and localize a disagreement to its rung.

- **Agent output is trusted by reputation, not bytes.** As models act as scientists, the record has no
  mechanism that makes an agent-asserted finding accountable to a recomputing preimage; v1's admission rule
  and the signed-tool-receipt line [Basu 2026; Wang 2026, *v1 refs 2, 52*] are the seed, but they gate the
  *I/O assertion*, not the *training interior* that produced it.

## X.3 A worked scenario (illustrative — NOT run)

**Question (illustrative substrate, no biological claim):** across several labs, which disordered protein
regions are aggregation-prone? Each lab holds a private patient-derived proteomics cohort it cannot share.

Each lab runs an **AI agent-scientist** that, locally: (i) tokenizes/curates its private cohort, (ii)
fine-tunes an aggregation-propensity predictor, and (iii) asserts candidate findings ("region X in protein
P is aggregation-prone, MCC 0.9 on my cohort"). The federation wants a meta-analysis it can trust, without
any lab shipping raw data. Walk the FCG through it:

1. **Commit, don't ship.** Each agent emits `dataset_root` over its vaulted cohort. Two labs whose roots
   match have *proven identical input without shipping PHI* — **[DEMONSTRATED]** at toy scale: our G1 runs
   reproduce `dataset_root 7ccc4780…` from a pinned tokenizer over a vaulted corpus on independent
   machines, proving corpus-identity by hash. Ceiling (load-bearing): a root is a **commitment, not
   encryption** — confidentiality lives in *where the bytes live*, and content-addressing is **not** HIPAA
   de-identification (v1 §5/§6). The root proves *sameness*, not privacy.

2. **The agent's interior is a custody object.** Each agent emits the full spine `dataset_root →
   recipe_root → trajectory_root → weights_root → result_leaf`. Another lab admits the agent's model **iff
   it recomputes from the named bytes** — the interior is accountable, not just the final call.
   **[DEMONSTRATED]** at toy scale (G1 Pythia-14M, CPU single-thread bit-identity leaf, PI-verified). PoL
   conceded FIRST; novelty is the multi-root spine + reject-not-annotate, not deterministic recompute
   per se.

3. **Reject at the boundary, not aggregate.** A contribution enters the meta-analysis only if it recomputes
   *and* clears the shared oracle. A hallucinated finding, a silently retuned predictor, or a drifted
   contribution **is rejected and localized to its rung** — not absorbed. This is the ProCanFDL gap closed:
   admission over aggregation. **[DEMONSTRATED]** at mechanism scale (v1's 0-false-admission multi-model
   runs; the fabricated-value and empty-tool-list catches; the 12-of-12 fail-closed truth table).

4. **Compare across hardware; catch a bad node.** Labs run on different accelerators. The custody hash
   proves same-input/same-recipe route-equivalence across cores **and** unmasks a compute node that
   silently ran on the wrong core — a "TPU" node whose committed output equals the known CPU-fallback hash
   is caught. **[DEMONSTRATED]** this program: same `7ccc4780…` on CPU/GPU-T4/TPU-v5e/Apple-MPS, and the
   custody hash caught a mislabeled accelerator (`weights_sha == 6e5b6aa9` betrayed a CPU run labeled TPU).
   The compute is a **supply-chain component whose numerical signature is its fingerprint** — an
   **INFERRED / FIP** lane, class-not-chip, prereg-if-rate, complementing (not replacing) hardware
   attestation. `weights_sha ≠ 6e5b6aa9` is *necessary, not sufficient*.

5. **Attribute every disagreement.** When two agents disagree on region X (the CAID situation), route
   comparison localizes the divergence to the first differing sub-object and *types* it — different cohort
   (`dataset_root`), different recipe, different model core, or an AI intervention. **[DEMONSTRATED]** as
   v1's typed divergence localization; **[FUTURE]** at consortium scale on real cohorts.

**What the federation gets:** a meta-analysis whose every admitted contribution recomputes from named
bytes, whose disagreements are attributed to a typed cause, and whose raw cohorts never left their labs —
with a demonstrated mechanism for catching a **mislabeled** compute node in the loop (catching a
*maliciously compromised* node is a FUTURE/adversarial lane — a motivated adversary can mimic a signature;
what is demonstrated is the mislabel/counterfeit catch, not attestation against a faker).

## X.4 Why this is the value (the narrowed novelty, in the domain)

The contribution is **not** federated learning, **not** provenance, **not** PoL, and **not** SMPC — each
conceded first. It is the **narrowed conjunction**, specialized to agents-as-scientists: a **multi-root
custody spine over the AI-agent's training interior** *plus* **head-to-head custody-vs-detector dominance
over a shared substrate**, run as a **determinism ladder** that doubles as a compute-provenance detector,
over **commitments** so the comparison is privacy-preserving by construction. It fills the specific gap that
opens when models do science autonomously and at scale: it makes each agent-scientist **accountable to
bytes rather than reputation**, and lets a federation **admit rather than aggregate** — the replication
crisis rejected at the federation boundary.

## X.5 Ceilings and honest ledger (so the section cannot overclaim at deposit)

| Element of the scenario | Status |
|---|---|
| Merkle-root-as-vault proves corpus-identity without shipping bytes | **[DEMONSTRATED]** toy scale (`7ccc4780`, independent machines) |
| Multi-root custody spine over a training interior | **[DEMONSTRATED]** toy scale (G1 CPU bit-identity leaf, PI-verified) |
| Reject-not-annotate admission gate (0 false admissions) | **[DEMONSTRATED]** mechanism scale (v1 §4) |
| Determinism ladder + custody catches mislabeled compute node | **[DEMONSTRATED]** this program (CPU/GPU/TPU/MPS; fake-TPU catch) |
| Typed divergence attribution across agents | **[DEMONSTRATED]** v1; **[FUTURE]** at consortium scale |
| **Federated bio consortium on real private cohorts, real aggregation claim** | **[FUTURE]** — motivating scenario, NOT run; no biological claim |
| Correctness-under-privacy (prove a hidden-data result is *correct*, not just consistent) | **[OPEN EDGE]** — needs ZK/MPC on top; Merkle roots are not zero-knowledge |
| Seal-time integrity (a federation can agree on a poisoned root) | **[OPEN EDGE]** — trust-on-first-write; graph proves sameness + tamper-evidence, not seal-time integrity |

**Prior art conceded FIRST.** *Already in v1's frozen reference set* (verified there): federated learning
over private cohorts [ProCanFDL / Cai 2025]; SMPC over genomes [Cho 2018]; PROV/RO-Crate,
SLSA/in-toto/sigstore; CAID as the multi-model route-comparison matrix [Necci 2021; Del Conte 2023];
data-use ontologies [Lawson 2021]; ZK property proofs [Yadav 2024] and KERI receipts [Smith 2019]. *New
v2/v3 citations* (independently CrossRef-resolved in `FCO_REFERENCES.jsonl`, **not** present in v1's 66-ref
list — a reviewer checking v1 will not find them there): Proof-of-Learning [Jia 2021] + PoL-spoofing
[Zhang 2022], the nearest deterministic-recompute prior art, conceded first.

**Citation discipline.** This section reuses only citations already resolved and verified in v1. Any *new*
citation for the "AI agents as autonomous scientists" framing (autonomous-discovery-agent / AI-scientist
literature) is **NOT yet inserted** — it must round-trip through SeedGraph/CrossRef/PubMed before entering
the manuscript, the same discipline that caught the PoL contradiction. See the CITATION-NEEDED list below.

### CITATION-NEEDED
- [x] **RESOLVED (PubMed-verified 2026-07-08, resolvable DOIs):** agents-as-scientists framing (X.1) now
      cites **Gao et al. 2024, *Cell* 187(22):6125–6151, doi:10.1016/j.cell.2024.09.022** (PMID 39486399 —
      "AI scientists" in *biomedical* discovery, Zitnik lab) and **Boiko et al. 2023, *Nature*
      624:570–578, doi:10.1038/s41586-023-06792-0** (PMID 38123806 — Coscientist, autonomous experiments).
      Both are new v2/v3 refs (not in frozen v1's set); stage into the v2/v3 `FCO_REFERENCES.jsonl` at
      manuscript-assembly time under the bibliography-closure rule.
- [x] **RESOLVED (PI-verified CrossRef 2026-07-09, resolvable DOI, not retracted):** the FL model-poisoning
      reference sharpening the "absorbed, not rejected" gap in X.2 is now inserted —
      **Shejwalkar & Houmansadr 2021, NDSS, doi:10.14722/ndss.2021.24498** ("Manipulating the Byzantine:
      Optimizing Model Poisoning Attacks and Defenses for Federated Learning"). New v2/v3 ref (not in frozen
      v1's set); SeedGraph owns independent re-verification before bibliography closure.

**Related v2/v3 material:** `MANUSCRIPT_v2v3_KEY_POINTS_2026-07-07.md` (key points),
`.planning/goals/fco-v4-continuous-merkle/DESIGN_distributed_FCG_provenance.md` (the single consolidated
distributed-FCG note — FCG/FIP split, trust-on-first-write ceiling, hardware-signature FIP).



---

# §6. Unified limitations & claim ceiling

# §6 (MERGED PAPER) — Unified limitations & claim ceiling

*Supersets v2's §4 (`handoff/MANUSCRIPT_v2_ASSEMBLED_2026-07-10.md`, leaf `d813825a`) and v3's §4
(`handoff/MANUSCRIPT_v3_ASSEMBLED_2026-07-10.md`, leaf `55a83a36`) into one section for the eventual single
6-section publication. For the two-preprint deposit path each body keeps its own §4; this merged §6 is used only
when v1→v2→v3→CA→compbio→limitations are assembled as one document. Faithful reconciliation of the two §4 sources
plus the 2026-07-12 correction state — no new claim is introduced here. v1 (Zenodo `10.5281/zenodo.21210575`)
stays frozen.*

## 6.1 Limitations

**Determinism (from v2 §4).**
- The bit-identity claim is **CPU single-thread only**. Accelerator bit-identity holds within a device's own
  silicon (an eps-disclosed lane), never across devices — the deterministic cores land distinct `weights_sha`
  for the one vaulted corpus.
- The Apple-MPS drift (one fp32 ULP, 2⁻²³, stable across sessions) is **OBSERVED**; its mechanism is recorded
  `unknown_hardware_contingent` — no ablation isolated a cause and none is asserted.
- **Code-match is necessary but not sufficient** for a silicon signature; only the CPU-unify rung is lib-clean.
- The model is **14M parameters at epochs=1** — a demonstration substrate for studying custody of the training
  instrument, not a trained-capability artifact.

**Detector arm (from v3 §4, updated to the K=5 outcome).**
- **Symbolic tamper is mechanism-illustration ONLY**; head-to-head *dominance* needs a real-byte both-channel
  tamper substrate (GAP1) and stays **gated/future** (see 6.3).
- The v3 §4 disclosed soft spot — Arm B was a **single generation seed** (N=50/type), so the bootstrap quantified
  metric-sampling variability, not fresh-run variability. That held-out robustness check has since been **run**
  (K=5 fresh generation seeds, `FMO-EXP-MULTISEED`): the outcome is **SEED-SENSITIVE — superiority not
  established (inconclusive)**, re-opening red-team Issue 2 (3/5 fresh seeds exceed the polarity-fair floor;
  neither a robust superiority nor a robust tie). It is EXPLORATORY and underpowered on the paired near-ceiling
  difference. A K=15 expansion is running; no equivalence claim is made absent a pre-registered margin (a TOST
  prereg, δ=0.019916, is frozen for that purpose).

## 6.2 Claim ceiling (unified binding set — verbatim, deduplicated across v2 §4 and v3 §4)
1. **Custody proves identity, provenance, and OBSERVED behaviour — never the CAUSE of a difference, and never
   semantic correctness.** (v2 binding 1 ≡ v3 binding 2.)
2. **CPU single-thread is the sole gating bit-identity claim**; every accelerator rung is an eps-disclosed peer.
3. **Code-match is necessary but not sufficient** for a silicon signature.
4. **Reproducible ≠ interpretable**; a 14M model at epochs=1 is a demonstration substrate, not a capability
   claim; perplexity/accuracy are sanity numbers, never headlines.
5. **"Best" is best on THIS shared task/corpus at epochs=1, never universal.**
6. **Head-to-head dominance rides on the benchmark (G5), never on an N=1 anecdote — and remains GATED/FUTURE**
   (real-byte both-channel substrate, GAP1). What v3 establishes is **complementarity** (Arm A custody + Arm B
   behavioural detect distinct failure modes; MCC 0.9417), which is **unaffected by, and NOT tested by**, the K=5
   multiseed robustness evidence.

## 6.3 Status of the dominance question (honest, current)
The G5 real-byte dominance one-shot is bound to a frozen prereg and CPU bit-reproducible-gated. Smoke-scale
evidence shows the combined detector C′ does **not** weakly dominate `retune` — diagnosed (see the next-run
design plan) as the naive `A OR B` combination penalised by MCC-at-a-fixed-threshold on the OR's added false
positives, the same failure an FPR-controlled combine already fixed at the three-arm-detector level. Dominance
therefore stays **future work, not a result**; the merged paper claims complementarity + determinism, not
dominance.

## 6.4 Future work (stated as future, not claimed)
- **Dominance:** an FPR-controlled *joint* C′ decision + dual AUC/MCC metric + powered paired difference on a
  real-byte both-channel substrate (redesign pre-registered before any confirmatory re-run).
- **Seed robustness:** the K=15 expansion (fresh generation seeds) to place an exact-binomial reliability interval
  on the exceed-the-floor proportion; K=5's interval (~[0.15, 0.95]) is too wide to settle.
- **CA custody-spine primitive (v2 supplementary, negative result):** across all 256 elementary CA rules, none
  matches SHA-256's cryptanalytic maturity — linear rules such as Rule 90 are disqualified despite perfect
  detector separation. Reported to **justify the SHA-256 choice, not to propose a replacement.**

## 6.5 Evidence binding (from bytes, never from memory)
- **v2 (training-interior custody):** `FCG_LADDER_COMPARISON_FULL.json` (`comparison_root 292b7a19…`, 9 rungs,
  all recompute, unaudited=[]), CPU gating leaf `f66ce21a`.
- **v3 (custody-as-detector):** Arm A `92711545` (`GATE_G2_pass:true`, PI-clean); Arm B `7e88b6cb` (gate-2
  cleared, MCC 0.9417); K=5 corrected aggregate `aca3d29c` (superseding sealed `d257761c`, byte-identical),
  external review `aa47c5ca`. Every blocked/dominance cell fills ONLY from a landed PI-audited G5 leaf on a real
  both-channel substrate.

*Ceiling: reconciliation/merge record only — no new claim, no PI signature forged, nothing pushed, v1 untouched.*



---

# Appendix — provenance manifest (each section recomputes from its named source bytes)

| § | Section | Source | content_leaf |
|---|---|---|---|
| 1 | v1 — self-verifying publication object model (FROZEN) | `(v1 frozen Zenodo deposit)` | `291f3364 (paper_cid)` |
| 2 | v2 — custody of the training interior | `handoff/MANUSCRIPT_v2_ASSEMBLED_2026-07-10.md` | `d813825a0365` |
| 3 | v3 — custody-as-detector benchmark (complementarity) | `handoff/MANUSCRIPT_v3_ASSEMBLED_2026-07-10.md` | `364dbefeb7ea` |
| 4 | CA — transparent real-world example + 256-rule primitive benchmark | `OUTGOING_chatgpt_review_2026-07-10/03_CA_section.md` | `0aa9c73da2ad` |
| 5 | Motivating application — federated comp-bio with AI agents as scientists | `handoff/MANUSCRIPT_v2v3_SECTION_distributed_compbio_AI_scientists.md` | `2d0cb92d3c1a` |
| 6 | Unified limitations & claim ceiling | `handoff/MANUSCRIPT_v2v3_SECTION_UNIFIED_limitations_ceiling_MERGED_2026-07-12.md` | `199b05dbd9b8` |

*Assembly recipe: `merged = front-matter ‖ concat(§1 pointer, §2..§6 source bytes) ‖ this manifest`. The merged leaf is a pure function of these named sources; re-running the assembly over the same source bytes reproduces it.*
