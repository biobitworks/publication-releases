# Package Content Source Stats — FCO v4/v5 + Vithia

- Generated: `2026-08-04T02:53:09+00:00`
- Package status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:bc35dda55069112f054204a2425325ac130af396c9c2bfd09c91c66460eb219a`
- Files analyzed: `8180`
- Nonblank lines: `2808114`
- Knowledge-atom lines: `18362` (0.65%)
- Seed-of-truth lines: `11983` (0.43%)
- Frontier/inference prose lines: `2777769` (98.92%)

## Deterministic Classification

- `knowledge_atom`: lexical evidence anchors such as hashes, receipts, EXP IDs, manifests, seals, PASS/FAIL/ABSTAIN rows, DOI/PMID/Zenodo/accession references.
- `seed_of_truth`: source/citation/provenance/SeedGraph/operator-decision lines that identify origin material but are not themselves the terminal atom.
- `frontier_inference`: unanchored explanatory prose, interpretation, recommendations, limitations, and Codex/assistant-authored synthesis.

## Deposit Boundary

- Local package is ready for operator review as a private/staged package.
- No public upload, live KG writeback, claim promotion, or visibility switch was performed by this script.

## Highest-Inference Files

| File | Nonblank | Atom | Seed | Inference |
|---|---:|---:|---:|---:|
| `/Users/byron/projects/active/gtm-cellico/.planning/goals/2026-07-05-fco-v2-v3-experiment-program/v2_028_B1_ollama.json` | 681 | 0 | 0 | 681 |
| `.planning/vitaology_substrate/materialized/heldout_splits/N1_ADMIT_ELIGIBLE_44.json` | 269 | 0 | 0 | 269 |
| `.planning/vitaology_substrate/materialized/cycle1_c_msm_batch/extracted.txt` | 264 | 0 | 0 | 264 |
| `handoff/SUPP_DATA_eca_256rule_custody_matrix.csv` | 257 | 0 | 0 | 257 |
| `/Users/byron/projects/active/gtm-cellico/.planning/goals/2026-07-05-fco-v2-v3-experiment-program/028_b1_promptset.json` | 152 | 0 | 0 | 152 |
| `.planning/vitaology_substrate/materialized/broad_replay_batch_064/extracted.txt` | 106 | 0 | 0 | 106 |
| `/Users/byron/projects/active/gtm-cellico/.planning/goals/2026-07-05-fco-v2-v3-experiment-program/v3_g1b_mps_ladder.json` | 48 | 0 | 0 | 48 |
| `.planning/vitaology_substrate/CONNECT_CODEX_STATUS.json` | 45 | 0 | 0 | 45 |
| `outbox/260802-fco-v4-v5-vithia-hold/evidence/daisy_train_driver_state.json` | 29 | 0 | 0 | 29 |
| `.planning/vitaology_substrate/materialized/corpus_batch_20260726T111925Z/division_counts.json` | 26 | 0 | 0 | 26 |
| `.planning/vitaology_substrate/materialized/daisy_scorer_eval_072/eval_specs.json` | 26 | 0 | 0 | 26 |
| `.planning/vitaology_substrate/fcg_edit_20260726_proceed.json` | 24 | 0 | 0 | 24 |
