# Zenodo Metadata Draft — FCO v4/v5 HOLD

Source: copied/adapted from `release/zenodo-2026-07-05/DEPOSIT_README.md` and `_UPLOAD_THESE_3_FILES.md`.

- Title: Fractal Custody Objects: route-comparable chain-of-custody for deterministic computational biology and AI-agent provenance
- Author: Byron Lee — ORCID 0000-0002-4925-4795
- License: Manuscript CC-BY 4.0; code Apache-2.0; corpus gate: Vitalogy 1927 US public domain, no share-alike.
- Resource type: Preprint / software-object package.
- Related identifier: Is new version of Zenodo concept DOI `10.5281/zenodo.21210575`.
- Description must include final `paper_cid`, final `fcg_root`, strict claim ceiling, and abstain/null limitations.
- Status: HOLD until signed/sealed package exists.
