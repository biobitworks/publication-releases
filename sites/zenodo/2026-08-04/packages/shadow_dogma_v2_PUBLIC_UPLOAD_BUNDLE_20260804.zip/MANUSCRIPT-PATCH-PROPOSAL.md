# Manuscript v1.0.2 Patch Proposal

No sibling package files were edited.

## Patch 1: Version / Status

Existing anchor: `Version: v1.0.1 ... v2 to follow with SeedGraph atomic proofs...`

Replacement: `Version: v1.0.2 proposal (2026-05-13 corpus reconciliation staging). This revision incorporates a local v2 corpus inventory across active, legacy, mounted external, SeedGraph/Overwatch/ProTHub-related, EXP/PROMPT/lab-note/result, and dataset surfaces. No claim class is promoted; all new references are metadata-only until canonical JSON, publication.atomic.json, and claim audit are complete.`

Justification: v2 corpus matrices. Risk: low.

## Patch 2: §4.3 Primary Driver

Keep the current primary-driver paragraph and add: `The v2 corpus pass found this lane distributed across local project-history, experiment, prompt, notebook, and result surfaces; these artifacts support lineage and procedural framing only. They do not establish public validation without canonical source packaging, SeedGraph proof, and a fresh claim audit.`

Justification: `PRIMARY-DRIVER-TRACE.md`. Risk: medium if merged without the qualification.

## Patch 3: §4.3 24D Disclosure

Keep the 24D text unchanged and append: `This is not a falsification test of Shadow Dogma's fragmentation/disorder-ratio lane; it is a constraint on one non-primary comparator layer.`

Justification: `NEGATIVE-RESULTS-LEDGER.md`. Risk: low.

## Patch 4: References

Do not bulk-add all selected rows. Add only operator-approved include_main/include_methods rows from `CENTRAL-REFERENCE-SELECTION-v2.md` after identifier review.
