# Package Ready Receipt — Shadow Dogma v2

- Status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:90d6c40929a240a861857af20044d52163604a723d1e98593f3a825ddfeb2086`
- Stats: `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/evidence/PACKAGE_CONTENT_SOURCE_STATS_20260804.json`
- Upload bucket: `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready`
- Evidence bucket: `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/evidence`
- Metadata bucket: `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/metadata`
- Boundary: private/staged only; operator controls public upload and visibility.

## Warnings

- None.
