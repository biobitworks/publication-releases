# Upload Index

- Package: `shadow_dogma_v2`
- Generated: `2026-08-04T03:13:51+00:00`
- Claim scope: v2 publication staging approved; claim ceiling remains software/governance/public-data only
- Do not upload any `do_not_upload/` content.
- Claim promotion is limited to publication-version framing; forbidden scientific/capability claims remain blocked.

## Files

- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/CLAIM-TO-EVIDENCE-MAP.v2.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/MANUSCRIPT-PATCH-PROPOSAL.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/SUMMARY-v2.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/paper1_DRAFT.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/paper2_DRAFT.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/paper3_DRAFT.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/SD-A5-ZENODO-DEPOSIT-PREP_2026-07-12.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/PACKAGE_CONTENT_SOURCE_STATS_20260804.md`
- `/Users/byron/projects/active/shadow-seeds/outbox/260804-shadow-dogma-v2-package-ready/upload_when_ready/PACKAGE_READY_RECEIPT_20260804.md`
