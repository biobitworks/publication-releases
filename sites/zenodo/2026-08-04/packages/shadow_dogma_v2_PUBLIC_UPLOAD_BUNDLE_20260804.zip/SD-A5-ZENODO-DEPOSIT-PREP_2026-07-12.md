# SD-A5 — Zenodo Deposit Package (PREP ONLY — deposit HELD)

**Prepared:** 2026-07-12 · **Owner of the DEPOSIT ACTION:** operator (Byron) · **Status:** `PREP_STAGED / DEPOSIT_HELD`
**Authorization:** operator "go SD-A3, A4, A5". **What "go SD-A5" authorizes an agent to do = prepare the package.**
**What it does NOT authorize (and what I did NOT do):** the Zenodo upload itself. That is (a) a manual browser
action only the operator can perform, (b) a **public release / public disclosure** — a hard governance gate, and
(c) **IP-consequential**: Paper 1 is **patent-first**, so public disclosure timing has patent implications and is
the operator's decision, not an agent's.

## ⛔ DEPOSIT IS BLOCKED until ALL of these clear (do not upload before):
1. **SD-A3 camera-ready conditions closed:** reconcile the **35 `[NEEDS-VERIFICATION]`/`[VERIFY-*]`/`[ESTIMATE]`
   inline citation tags** against the accepted SD-A1 283-paper corpus, and fix the **version label** (header says
   "Draft v0.1 — 2026-06-12"; tracking says v1.0.2). *The current manuscript is NOT camera-ready content.*
2. **Final audit pass** on the reconciled manuscript (re-run SD-A3 → clean, no conditions).
3. **`verify_licenses.py`** run so the SD-A4 appendix carries custody-proven licenses (esp. WaltzDB).
4. **Operator + patent-first disclosure decision** — explicit operator approval that public Zenodo disclosure is
   cleared under patent-first timing.
5. **Authorship/affiliations filled** (manuscript §Authors is a `[HUMAN: fill in]` placeholder).

## Zenodo metadata (DRAFT — operator to confirm at upload)
- **Title:** *The Shadow Dogma: A Hypothesis of Fragment-Inheritance Aging Mediated by Immune Distribution*
- **Authors:** Byron Lee (Independent researcher), **ORCID 0000-0002-4925-4795** — obtained. [+ any co-authors: HUMAN]
- **Resource type:** Preprint (or Dataset, if depositing supporting data rather than the manuscript — operator choose)
- **License (portfolio convention):** manuscript **CC-BY-4.0**; any code/appendix **Apache-2.0**. Confirm at upload.
- **Description:** hypothesis paper (theory + governance/method); base channel established (prion/yeast templating),
  reach = open hypothesis; **cross-protein disorder-state transfer reported as a terminal NEGATIVE** (NR_020
  discipline). No clinical/diagnostic/therapeutic/aging-reversal claim.
- **Keywords:** aging; proteostasis; prion-like; intrinsic disorder; inflammaging; microchimerism; hypothesis;
  negative result.
- **Related identifiers:** companion FCO/FMO methods deposit Zenodo `10.5281/zenodo.21210575`; Paper 2 XenoDisorder
  (forthcoming); bioRxiv DOI (SD-A6, after deposit).
- **Version:** set to the reconciled manuscript version (NOT "v0.1"); record the Zenodo DOI back into
  `V2_DEPOSIT_MANIFEST` / routing matrix on completion.

## Files that WOULD be deposited (manifest — assemble after camera-ready)
- Reconciled `paper1_DRAFT.md` → camera-ready manuscript (PDF/DOCX).
- `SD-A4-SOFTWARE-DATA-APPENDIX` (availability statement) — after `verify_licenses.py`.
- `publication.atomic.json` (SD-A2 Merkle custody proof, root `e76478164eb3…`) as the custody sidecar.
- Optionally `SD-A2-COMPLETENESS-AUDIT.json` + `SD-A3-CLAIM-AUDIT` as governance provenance.
- **NOT deposited:** sequences, scorer weights, property-space, TPE matrices, comparator math, SUDC/SIDS
  row-level data, `restricted_internal` rows.

## Operator upload steps (when unblocked — YOU do this in a browser)
1. zenodo.org → New upload → set metadata above → upload the camera-ready file set.
2. Reserve DOI → publish (this is the public-release action).
3. Record the DOI in `V2_DEPOSIT_MANIFEST_*.json` + the routing matrix; then SD-A6 (bioRxiv) uses it.

**Boundaries:** package prep only; NO upload; NO public release; NO DOI reserved; NO commit. The deposit remains
the operator's gated action.
