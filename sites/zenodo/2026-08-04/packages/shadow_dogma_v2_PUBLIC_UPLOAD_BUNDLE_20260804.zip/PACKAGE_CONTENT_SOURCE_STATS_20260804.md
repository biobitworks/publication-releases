# Package Content Source Stats — Shadow Dogma v2

- Generated: `2026-08-04T02:53:21+00:00`
- Package status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:90d6c40929a240a861857af20044d52163604a723d1e98593f3a825ddfeb2086`
- Files analyzed: `529`
- Nonblank lines: `85961`
- Knowledge-atom lines: `8250` (9.60%)
- Seed-of-truth lines: `10629` (12.36%)
- Frontier/inference prose lines: `67082` (78.04%)

## Deterministic Classification

- `knowledge_atom`: lexical evidence anchors such as hashes, receipts, EXP IDs, manifests, seals, PASS/FAIL/ABSTAIN rows, DOI/PMID/Zenodo/accession references.
- `seed_of_truth`: source/citation/provenance/SeedGraph/operator-decision lines that identify origin material but are not themselves the terminal atom.
- `frontier_inference`: unanchored explanatory prose, interpretation, recommendations, limitations, and Codex/assistant-authored synthesis.

## Deposit Boundary

- Local package is ready for operator review as a private/staged package.
- No public upload, live KG writeback, claim promotion, or visibility switch was performed by this script.

## Highest-Inference Files

| File | Nonblank | Atom | Seed | Inference |
|---|---:|---:|---:|---:|
| `results/TASK-005-RUN-20260316T202800Z/task_summary.json` | 10 | 0 | 0 | 10 |
| `results/EXP-002-RUN-20260316T182909Z/conductor_protocol_relevance.json` | 9 | 0 | 0 | 9 |
| `results/TASK-008-RUN-20260316T213000Z/task_summary.json` | 5 | 0 | 0 | 5 |
| `results/TASK-014-RUN-20260316T202327Z/summary.md` | 4 | 0 | 0 | 4 |
| `results/TASK-015-RUN-20260316T203200Z/summary.md` | 4 | 0 | 0 | 4 |
| `.planning/publication/260610-shadow-dogma-fast-track-goal/regen_out/REGEN_ACTB_x_PRNP_HOTSPOT_SUMMARY.tsv` | 2 | 0 | 0 | 2 |
| `.planning/publication/260610-shadow-dogma-fast-track-goal/.sd_distinct_accessions.json` | 1 | 0 | 0 | 1 |
| `results/EXP-002-RUN-20260316T182909Z/ingestion_needed_register.json` | 1 | 0 | 0 | 1 |
| `results/EXP-002-RUN-20260316T182909Z/unsupported_claim_kill_list.json` | 1 | 0 | 0 | 1 |
| `results/EXP-002-RUN-20260316T183236Z/ingestion_needed_register.json` | 1 | 0 | 0 | 1 |
| `results/EXP-002-RUN-20260316T183236Z/unsupported_claim_kill_list.json` | 1 | 0 | 0 | 1 |
| `results/EXP-002-RUN-20260316T184500Z/ingestion_needed_register.json` | 1 | 0 | 0 | 1 |
