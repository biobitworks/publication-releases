# SEEDS-OF-TRUTH — Shadow Dogma Papers
**Build order:** atoms_of_knowledge → seeds_of_truth → skeleton → draft  
**No-fabrication rule:** No PMID or DOI was invented or guessed. Any identifier that could not be confirmed from a public source is marked ESTIMATE with evidence required.  
**Claim ceiling rule:** Nothing in any draft may exceed what these seeds trace. HYPOTHESIS stays HYPOTHESIS. MEASURED stays bounded to the dataset/publication that measured it. ESTIMATE may not be cited as established fact without operator-approved upgrade.  
**Generated:** 2026-06-12  
**Source files:** paper2_seeds.jsonl (24 atoms), graphical_abstract_seeds.jsonl (13 elements)

---

## Paper 2 Atoms

| atom_id | statement (abbreviated) | claim_class | source_ref | validation_status | confidence | what_would_validate |
|---|---|---|---|---|---|---|
| NCAA-PRED-LOO | ncAA disorder predictor LOO r²=0.76 (train 0.9988, RMSE 0.00518, n=20, 36 ncAAs) | MEASURED | exp137 metadata JSON in active/results/ | CORRECT-AS-IS | high | Dataset present; spot-check: recompute LOO from exp137 metadata to confirm r² |
| NCAA-PRED-FEATURES | 8 public features: hydrophobicity, charge, flexibility, h_bond_capacity, volume, polarity, backbone_phi_pref, beta_sheet_propensity | MEASURED | exp137 metadata | CORRECT-AS-IS | high | Dataset present; features enumerated in exp137 metadata |
| NCAA-PRED-LABELS | Training labels = metapredict v3 + IUPred2A calibrated | MEASURED | exp137 metadata | CORRECT-AS-IS (flag: IUPred2A academic-license) | high | Dataset + license confirmation present |
| METAL-PRED-P1-7 | EXP-144: 7 falsifiable predictions (P1–P7), 11 metals, metal-modified ncAA disorder | PREDICTION | exp144 metadata JSON in active/results/ | CORRECT-AS-IS | high | Dataset present; confirm P1–P7 enumeration in exp144 metadata |
| PREDICTOR-BLINDNESS | Canonical predictors are modification-invariant vs ncAA predictor differs | TO_COMPUTE | predictor-blindness demonstration (analysis, IP-clean) | CORRECT-AS-IS (pending computation) | med | Compute demonstrated; confirm matched nulls and IP-clean protocol complete |
| TOOL-METAPREDICT | metapredict disorder predictor (MIT); v3 used for label generation | MEASURED | **PMID 34480923** (Emenecker, Biophys J 2021, DOI 10.1016/j.bpj.2021.08.039); v3 DOI **10.1002/pro.4466** | **VALIDATED (v1)** / **ESTIMATE (v3)** | v1=high; v3=med | v1 PMID 34480923 confirmed: "Metapredict: a fast, accurate, and easy-to-use predictor of consensus disorder and structure", Emenecker et al., Biophys J 2021. v3 DOI 10.1002/pro.4466 resolves at Wiley (HTTP 402 paywall) — title not confirmable from public access; ESTIMATE until PMID retrieved |
| TOOL-IUPRED3 | IUPred-3 disorder predictor (academic license) | MEASURED | **PMID 34048569** | **VALIDATED** | high | Confirmed: "IUPred3: prediction of protein disorder enhanced with unambiguous experimental annotation…", Erdős et al., Nucleic Acids Research 2021, DOI 10.1093/nar/gkab408 |
| DB-DISPROT | DisProt curated disorder database (CC-BY) | MEASURED | **PMID 41249866** | **VALIDATED** | high | Confirmed: "DisProt in 2026: enhancing intrinsically disordered proteins accessibility, deposition, and annotation", Nugnes et al., Nucleic Acids Research 2026, DOI 10.1093/nar/gkaf1175 |
| DB-DARKPROTEOME | Dark proteome = structurally-uncharacterized, disorder-enriched fraction | MEASURED | **PMID 26578815** | **VALIDATED** | high | Confirmed: "Unexpected features of the dark proteome", Perdigão et al., PNAS 2015, DOI 10.1073/pnas.1508380112 |
| FF-NCAA | ncAA force-field params (feature source); CHARMM36-ncAA Croitoru et al. 2021 | MEASURED | **PMID 34009984** | **VALIDATED** | high | Confirmed: "Additive CHARMM36 Force Field for Nonstandard Amino Acids", Croitoru, Park, Kumar et al., J Chem Theory Comput 2021. NOT Kulhanek — correction stands. |
| PRIOR-ART | Prior art does NOT cover ncAA disorder: CamSol-PTM (solubility), AAindexNC (properties), Brown 2026 (secondary structure) | MEASURED | CamSol-PTM **PMID 37978172**; AAindexNC PMID unknown; Brown bioRxiv 2026 DOI pending | **CamSol-PTM: VALIDATED**; **AAindexNC: CONFLICT→ESTIMATE**; **Brown 2026: ESTIMATE** | CamSol high; AAindexNC low; Brown med | CamSol confirmed: "Sequence-based prediction of the intrinsic solubility of peptides containing non-natural amino acids", Oeller et al., Nature Communications 2023. AAindexNC: cited PMID 39684773 is WRONG (= bamboo FD gene family paper, IJMS 2024) — confirmed conflict. Actual AAindexNC paper appears to be Milchevskiy et al. 2024, IJMS (confirmed by Google Scholar); DOI not publicly resolvable from this session. Brown 2026: DOI 10.64898/2026.01.28.701962, biorxiv preprint "Xeno amino acid alphabets form peptides with familiar secondary structure", Brown SM et al.; confirmed via Google Scholar — PMID not yet assigned. |
| PTM-ISOASP | isoAsp accumulates in long-lived proteins; PCMT1/PIMT repair declines in aging | LITERATURE_GROUNDED | aging-PTM primary lit (ref unspecified in seed) | **ESTIMATE** | med | Best candidate: Desrosiers & Fanélus 2011, Curr Aging Sci, PMID 21204776 ("Damaged proteins bearing L-isoaspartyl residues and aging…") and Warmack et al. 2019, PMID 31239355 (lens isoAsp aggregation). Neither PMID was in the seed. Drafts must cite these explicitly or identify primary source (e.g., Clarke lab papers on PCMT1 knockout). |
| PTM-SET | Deamidation, glycation/CML/AGE, carbamylation, oxidation (MetO) accumulate in aging | LITERATURE_GROUNDED | aging-PTM primary lit (ref unspecified in seed) | **ESTIMATE** | med | Statement is biologically sound and consensus, but no specific PMID provided in seed. Validate against: Ding 2025 (PMID 40713952, Cell) for proteome-wide PTM aging data; Warmack 2019 for lens. Seed must be upgraded with explicit citations before draft uses it as MEASURED. |
| PRION-CHANNEL | Prion templating = protein→protein conformational transfer, heritable, NA-independent (PrP^Sc, [PSI+]/[URE3], CPEB/Orb2, MAVS/ASC) | MEASURED | "verified prion refs" (unspecified in seed) | **ESTIMATE** | med | PrP^Sc canonical; [PSI+]/[URE3] canonical (Wickner 1994 Science, PMID not confirmed this session — PubMed CAPTCHA blocked; likely ~PMID 8079494 but unverified here). CPEB/Orb2 Prion-like: Si et al. Cell 2003 (PMID 14675643 — not verified this session). Exact PMIDs must be confirmed before draft marks this MEASURED. |
| PRION-LIKE-LCD | Prion-like LCD/LLPS proteins template via low-complexity domains (panel: PRNP/FUS/TARDBP/…) | MEASURED | Daskalov 2014, Eufemio 2026, Schwidetzky 2023 + SPV V7 atlas | **CORRECT-AS-IS** (verified_pool+dataset per seed) | high | Verified_pool status from seed; spot-check one: Daskalov 2014 prion-like LCD in fungi is well-established in literature. |
| ANALOG-DIGITAL-BOUNDARY | Peptides = boundary between analog-like and digital-like computing; disorder = analog measure | HYPOTHESIS | ANALOG-DIGITAL-COMPUTING-FRAMING.md (internal) | **CORRECT-AS-IS** (internal theory seed) | n/a — hypothesis | Internal framing; not a falsifiable claim until operationalized as PREDICTOR-BLINDNESS computation. |
| TWO-DOGMAS | Central Dogma (DNA→RNA→protein, digital-like) vs Shadow Dogma (peptide→peptide, analog-like) | HYPOTHESIS | SHADOW-DOGMA-DEEP-TIME-FRAMING.md (internal) | **CORRECT-AS-IS** (internal theory seed) | n/a — hypothesis | Framing document; claim ceiling = HYPOTHESIS. |
| SCORING-GAP | Canonical sequence-only digital-like tools are blind to analog-like modulators → Principle 2 need | HYPOTHESIS | follows from PREDICTOR-BLINDNESS (internal+to_compute) | **CORRECT-AS-IS** (internal, depends on PREDICTOR-BLINDNESS) | med | Requires PREDICTOR-BLINDNESS computation to be completed. |
| CODON-YIN-YANG | Synonymous codons → different translation rate → different co-translational folding/mRNA stability; identical-sequence fragments can have different conformational fates | MEASURED | **PMID 27354349** | **VALIDATED** | high | Confirmed: "The Yin and Yang of codon usage", Komar AA, Hum Mol Genet 2016, DOI 10.1093/hmg/ddw207. Correct match. |
| YEAST-ASYM-AGGREGATE | Yeast mother cells asymmetrically retain damaged/aggregated proteins (Hsp104-dependent); daughters rejuvenate | MEASURED | Aguilaniu 2003 / Erjavec / Liu 2010 / Hsp104 | **VALIDATED (Aguilaniu)**; Erjavec/Liu ESTIMATE | high (Aguilaniu); med (others) | Aguilaniu 2003 confirmed: **PMID 12610228**, "Asymmetric inheritance of oxidatively damaged proteins during cytokinesis", Science 2003, DOI 10.1126/science.1080418. Erjavec and Liu 2010 exact PMIDs not confirmed this session — mark ESTIMATE until verified. |
| YEAST-PRION-INHERITANCE | [PSI+]/[URE3] yeast prions = genuine non-genetic conformational inheritance | MEASURED | seedKG prion_idr_sids_corpus + exact refs needed | **ESTIMATE** | med | Canonical literature exists (Wickner 1994 Science; Chernoff 1995); PubMed CAPTCHA blocked direct PMID confirmation this session. Drafts must not list a PMID here until confirmed. Seed's own `needs_verification_exact` flag applies. |
| MHC-BROADCAST-CANONICAL | MHC I/II as conformational-information broadcast; prion cores (VQIVYK, KLVFF, SYSGQQYN) fit MHC-I/II peptide-binding ranges | HYPOTHESIS | cellico CELLICO_AGING_FRAGMENTATION_HYPOTHESIS_2026-02-01.md | **CORRECT-AS-IS** (internal canonical doc; claim_class=HYPOTHESIS) | n/a — hypothesis | Prion core sequences are citable (e.g. VQIVYK = tau repeat; KLVFF = Aβ core). Internal framing must stay hypothesis-labeled. |
| ORDER-DISORDER-EDGE | Life = dynamic order↔disorder balance; full order = crystallization = death; node proteins at the edge | HYPOTHESIS | cellico Feb-1 hypothesis doc | **CORRECT-AS-IS** (internal canonical doc; claim_class=HYPOTHESIS) | n/a — hypothesis | Framing hypothesis only. Retain label. |

---

## Graphical Abstract Elements

| element_id | portion | claim_class | seed_atom | citation / ref | validation_status | confidence | what_would_validate |
|---|---|---|---|---|---|---|---|
| GA-01 | Title: Shadow Dogma — a hypothesis of aging | HYPOTHESIS | SD-CORE-THESIS | this paper (internal) | **CORRECT-AS-IS** | n/a | Title framing; no external ref needed. |
| GA-02 | Selfish-prion framing (operator theory/analogy) | HYPOTHESIS | SPT-CORE | Daskalov 2014, Eufemio 2026, Schwidetzky 2023 (verified_corpus) | **CORRECT-AS-IS** | high | verified_corpus from seed; no re-verify needed. |
| GA-03 | Fragment inheritance | HYPOTHESIS | FRAG-INHERIT | Savas 2012, Toyama 2018, Fornasiero 2018 (verified_corpus) | **CORRECT-AS-IS** | high | verified_corpus from seed; inheritance-as-aging = HYPOTHESIS label preserved. |
| GA-04 | Immune inheritance / hybrid immune system | LITERATURE_GROUNDED_HYPOTHESIS | IMM-INHERIT | null (needs_verification) | **ESTIMATE** | low | Candidate refs: trained immunity (Netea et al. 2016 Science), maternal-fetal immune priming literature. PMIDs needed before draft. |
| GA-05 | Mitochondria (maternal inheritance axis) | MEASURED | MITO-MATERNAL | null (needs_verification) | **ESTIMATE** | med | Textbook biology well-established (maternal mtDNA inheritance); cite e.g., Anderson et al. 1981 (original human mtDNA sequence) or a modern review. No controversy in the claim, but seed has no ref — must add before citing as MEASURED. |
| GA-06 | Germline cascade: oocytes form in utero (maternal→grandmother→fetal ovaries→oocytes→mother born→puberty) | MEASURED | FETAL-OOGENESIS | null (needs_verification) | **ESTIMATE** | med | Classic developmental biology (oogonia form during fetal life, oocytes arrested in prophase I). Standard embryology textbook or review (e.g., Pepling 2012 Biol Reprod). PMID needed before draft marks MEASURED. |
| GA-07 | Father→sperm→egg→zygote | MEASURED | FERTILIZATION | textbook | **CORRECT-AS-IS** | high | Textbook; citation optional. Retain as-is. |
| GA-08 | Aging waves timeline (embryo→birth→puberty→adult→40→44→60→death) | MEASURED | AGING-WAVES | Lehallier 2019 **PMID 31806903**; Oh 2023 **PMID 38057571** | **VALIDATED (refs)** / **CONFLICT on ages** | high (refs); high (conflict) | Lehallier 2019 confirmed: "Undulating changes in human plasma proteome profiles across the lifespan", Nature Medicine 2019 — reports waves at **ages 34, 60, 78** (NOT 40/44/60 as shown in figure). Oh 2023 confirmed: "Organ aging signatures in the plasma proteome track health and disease", Nature 2023 — reports continuous organ-specific aging, no discrete 40/44/60 waves. **CONFLICT: the figure ages 40/44/60 do not match Lehallier 2019 (34/60/78) and are not supported by Oh 2023.** Draft must either: (a) correct the figure to 34/60/78 citing Lehallier, OR (b) find a source that specifically supports 40/44/60 waves, OR (c) label these ages as schematic/illustrative and not cite Lehallier/Oh as direct support. |
| GA-09 | Stem cells / microchimerism / maternal-fetal immune context | LITERATURE_GROUNDED_HYPOTHESIS | MICROCHIMERISM | null (needs_verification) | **ESTIMATE** | low | Foundational microchimerism papers exist (Lo et al. 1996/1997, Nelson et al. 1998/2002, Bianchi lab). PubMed CAPTCHA blocked confirmation this session. Seed's null ref must be replaced before draft. |
| GA-10 | Fragment star chart (constellation network) | SOFTWARE_EVIDENCE | FRAGMENTUM-V1 | substrata:fragmentum v1; substrata:proteinome v1 (internal_gate_safe) | **CORRECT-AS-IS** | high | Internal gate; abstracted from v1. NOT v2 TPE cloud. No external PMID needed. |
| GA-11 | Disclaimer: "Working theory… not a proven biological mechanism" | claim_ceiling_statement | CLAIM-CEILING | governance (preserve verbatim) | **CORRECT-AS-IS** | n/a | Must appear verbatim in final figure. |
| GA-12 | Peptide-first / peptide-RNA precedent (optional caption context) | LITERATURE_GROUNDED_HYPOTHESIS_ANALOGY | PEPTIDE-FIRST-WORLD-PRECEDENT | Wills & Carter bioRxiv 10.1101/140657; Guseva/Zuckermann/Dill DOI 10.1073/pnas.1620179114 | **ESTIMATE** | med | Wills & Carter: bioRxiv preprint; not independently confirmed this session. Guseva et al.: DOI resolves at PNAS — title likely "Reconstituting folding of a stalled ribosomal peptide or similar". PMIDs needed. Note: seed marks these as conceptual precedent only, not aging evidence — framing preserved. |
| GA-13 | Peptides as analog-like/digital-like boundary; disorder scores as controlled readout | INTERNAL_THEORY_METHOD_INTERPRETATION | PEPTIDE-ANALOG-DIGITAL-BOUNDARY | SHADOW-DOGMA-DEEP-TIME-FRAMING.md, CORE-PRINCIPLES.md (internal) | **CORRECT-AS-IS** | n/a | Internal framing; null-test requirement for score/readout layer is noted and must be honored in Methods. |

---

## Session-Verified Seeds (Pre-built; Not Re-verified Unless Flagged)

The following items were confirmed as VERIFIED during this session or an immediately prior session, and are included here for completeness:

| ref | details | status |
|---|---|---|
| Ding 2025 aging proteome | **PMID 40713952**, Cell 2025, "Comprehensive human proteome profiles across a 50-year lifespan…", Ding Y et al.; 516 samples, 13 tissues, 5 decades; ProteomeXchange **PXD058638** (not confirmed in article abstract this session — record from seed). | **VALIDATED** |
| Ding 2025 source-family preflight | Cellico-bio EXP089 reports source-family custody and redacted deterministic replay pass; Shadow Seeds EXP-011 Stage-0 preflight blocks numeric aging-wave execution pending a processed age/tissue metric contract and matched-null bundle. | **VALIDATED_SOURCE_SEED / EXECUTION_BLOCKED** |
| CIRBP bowhead Nature 2025 | **PMID 41162698**, Nature 2025, "Evidence for improved DNA repair in the long-lived bowhead whale", Firsanov et al., DOI 10.1038/s41586-025-09694-5. CIRBP promotes DNA repair and extends lifespan. | **VALIDATED** |
| eCIRP M3 peptide | PMC7483826 = redirect to **PMID 32439208**, Surgery 2020, "Inhibition of TREM-1 with an eCIRP-derived Peptide Protects Mice from Intestinal Ischemia-reperfusion Injury", Denning et al., DOI 10.1016/j.surg.2020.04.010. | **VALIDATED** |
| metapredict v1 | **PMID 34480923**, Biophys J 2021, "Metapredict: a fast, accurate, and easy-to-use predictor of consensus disorder and structure", Emenecker, Griffith, Holehouse. Prior PMID 34529975 = Neisseria PBP2 — **CONFLICT confirmed corrected**. | **VALIDATED** |
| TOOL-PEPFUNN | **PMID 39777768**, PMCID **PMC11706630**, DOI **10.1002/psc.3666**, Journal of Peptide Science 2025, "PepFuNN: Novo Nordisk Open-Source Toolkit to Enable Peptide in Silico Analysis", Ochoa & Deibler. Local XML SHA-256 `ec4799ccaad3b224b7edae95e85a1e1ed013b40a22b7f91c7aad96965e2ace80`. Role: cite-and-use prior art for peptide property/similarity/clustering/library/matched-pair/ncAA monomer-dictionary workflows; not a disorder predictor in this reviewed source; not Shadow Dogma biology validation. | **VALIDATED_SOURCE_SEED** |

---

## Draft-Only Alias Seeds Added By Trace Audit

These ids appear in the rough drafts as `[ATOM: ...]` tags or method-gate references but were not already normalized in `paper2_seeds.jsonl`, `graphical_abstract_seeds.jsonl`, or the main seed table. They are added here to prevent orphan tags. They are not publication atoms and do not imply SeedGraph custody.

| atom_id | statement (abbreviated) | claim_class | source_ref | validation_status | confidence | what_would_validate |
|---|---|---|---|---|---|---|
| AGING-HALLMARKS-IMMUNE-AGING | Hallmarks of aging, inflammaging, and immune-aging background used as framework context | LITERATURE_GROUNDED | Paper 1 draft cites Lopez-Otin 2013/2023, Franceschi 2000, Fulop 2017 | ESTIMATE | med | Verify exact PMID/title/claim sentence before marking measured |
| SENESCENCE-SASP | Senescence and SASP background used as established aging biology context | LITERATURE_GROUNDED | Paper 1 draft cites Hayflick, Coppe 2008, Gorgoulis 2019 | ESTIMATE | med | Verify exact source sentences and attribution |
| SD-JOINT-MEASUREMENT-GAP | No existing dataset jointly measures longitudinal low-abundance modified fragment burden with immune processing across the full proposed axis | HYPOTHESIS / GAP_CLAIM | Paper 1 measurement-gap section | ESTIMATE | med | Literature/data-resource audit proving no such public dataset or downgrading to "not identified in this audit" |
| DISORDER-CLOUD-FRAMING | Disorder-cloud representation as mean, uncertainty width, predictor disagreement, and local flank delta | INTERNAL_METHOD | Paper 1 section 4.3; Paper 3 boundary method | ESTIMATE | med | CAID/DisProt reliability curves and figure-level method contract |
| DISORDER-CLOUD-CLAIM | Disorder cloud as computational interpretability layer below IDP ensemble methods | INTERNAL_METHOD / CLAIM_CEILING | Paper 2 section 2.5; `DISORDER-CLOUD-CLAIM.md` reference | ESTIMATE | med | Clean calibration rerun and source-cited positioning against bAIes/Metainference/AFflecto |
| IDR-IDP-GAP-AND-HONEST-NEGATIVE | IDR/IDP tools have ensemble/context/PTM/ncAA limits; current surrogate does not close that gap | METHOD_LIMITATION | `IDR-IDP-GAP-AND-HONEST-NEGATIVE.md`; Paper 2/Paper 3 limitations | VALIDATED_SOURCE_SEED | med | Claim-specific citation audit before manuscript use |
| CELLICO-BIO-KEY-POINTS-INTEGRATION | Internal Cellico-bio integration note used only to contextualize the terminal-negative cross-protein result | INTERNAL_CONTEXT | Paper 1 section 4.4 | BLOCKED | low | Owner-lane source freeze and claim audit; do not use as external evidence |
| XENODISORDER-FOLLOWUP | XenoDisorder owns the follow-up calibration path for modified-residue disorder readout | INTERNAL_METHOD_PLAN | Paper 1 section 4.5; Paper 2 draft | ESTIMATE | med | Clean CAID/DisProt calibration and EXP_019 null closure |
| SUBSTRATA-FRAGMENTUM-PLAN | Substrata/Fragmentum planned as multi-scale fragment/cloud substrate layer | INTERNAL_METHOD_PLAN | Paper 1 section 4.5; Paper 3 scaffold | ESTIMATE | med | Frozen substrate contract, hashes, query receipts, and no-payload export review |
| BIOCIRCUIT-SHAPE-PLAN | Biocircuit planned as downstream signal-shape layer | INTERNAL_METHOD_PLAN | Paper 1 section 4.5 | ESTIMATE | low | Owner-lane design contract and benchmark receipt |
| MATERNAL-GRANDMOTHER-MICROCHIMERISM | Three-generation microchimerism/immune-overlap framing | LITERATURE_GROUNDED_HYPOTHESIS | Paper 1 section 2.9 | ESTIMATE | low | Exact source sentence audit for grandmother/mother/fetus simultaneity |
| TRAINED-IMMUNITY | Trained immunity as non-chromatin immune-context carrier | LITERATURE_GROUNDED | Paper 1 section 2.9 cites Netea 2016 PMID 27102489 | ESTIMATE | med | Exact PMID/title/source-sentence audit |

---

## Confirmed CONFLICT Records

These are wrong identifiers that have been caught and documented. Drafts must not use the wrong PMIDs under any circumstances.

| atom | wrong_id | what_it_actually_is | correct_id | status |
|---|---|---|---|---|
| TOOL-METAPREDICT | PMID 34529975 | Neisseria gonorrhoeae PBP2 paper (completely unrelated) | PMID 34480923 (Emenecker Biophys J 2021) | **CONFLICT — corrected** |
| PRIOR-ART (AAindexNC) | PMID 39684773 | "Genome-Wide Identification and Expression Analysis of FD Gene Family in Bamboos", IJMS 2024 (completely unrelated) | Unknown — likely Milchevskiy et al. 2024 IJMS (Google Scholar match, DOI not confirmed publicly this session) | **CONFLICT — awaiting correction** |

---

## Counts

These counts are scope-aware. The original Paper 2 + graphical-abstract seed pool remains separate from later session-verified rows and draft-only alias rows.

| scope | count | notes |
|---|---|
| Paper 2 atoms | 24 | From `paper2_seeds.jsonl`; mixed validated/correct/estimate/conflict statuses. |
| Graphical abstract elements | 13 | From `graphical_abstract_seeds.jsonl`; mixed validated/correct/estimate/conflict statuses. |
| Session-verified / session-bound seeds | 6 | Ding source family, CIRBP, eCIRP M3, metapredict v1, PepFuNN; Ding preflight is source-bound/execution-blocked. |
| Draft-only alias rows added by trace audit | 12 | Added to prevent orphan draft atom tags; not publication atoms. |
| Non-reserved orphan draft atom ids after trace audit | 0 | Reserved workflow markers remain: `NEEDS-VERIFICATION`, `TO-COMPUTE`, `SD-A1`. |
| **Total tracked seed rows/elements in this document** | **55** | 24 + 13 + 6 + 12. |

---

## ESTIMATE List — Drafts Must Flag These

The following items have no confirmed public identifier or have a mismatch. No draft may present these as established/measured/cited facts without upgrade:

The draft-only alias table above adds additional `ESTIMATE` rows for local method/gate aliases. Those rows are intentionally not repeated here; use their `what_would_validate` cells as the validation checklist.

1. **TOOL-METAPREDICT v3** — DOI 10.1002/pro.4466 resolves at Wiley but is paywalled; PMID not confirmed. Flag as "(v3 preprint/tool release; PMID pending)" in draft until PMID confirmed.

2. **PRIOR-ART: AAindexNC** — PMID 39684773 is WRONG (bamboo paper). Best candidate: Milchevskiy et al. 2024, IJMS — confirmed by Google Scholar but DOI/PMID not publicly resolvable this session. Do not cite the bamboo PMID. Use "(Milchevskiy et al. 2024, IJMS — PMID pending confirmation)" in draft until operator confirms.

3. **PRIOR-ART: Brown 2026 bioRxiv** — DOI 10.64898/2026.01.28.701962 identified via Google Scholar ("Xeno amino acid alphabets form peptides with familiar secondary structure", Brown SM et al.); biorxiv confirmed as host; PMID not yet assigned. Use DOI in draft, note "bioRxiv preprint".

4. **PTM-ISOASP** — No PMID in seed. Best candidates: Desrosiers & Fanélus 2011 PMID 21204776; Warmack et al. 2019 PMID 31239355. Draft must name a specific citation or mark claim as review-level.

5. **PTM-SET** — No PMID in seed. Broad aging-PTM claim; assign explicit references (e.g., Ding 2025 PMID 40713952 for proteome-scale evidence) before draft marks MEASURED.

6. **PRION-CHANNEL** — "verified prion refs" unspecified. Wickner 1994 canonical; PMID not confirmed this session (PubMed CAPTCHA). Si et al. 2003 CPEB PMID unconfirmed. Add explicit PMIDs.

7. **YEAST-PRION-INHERITANCE** — Same issue as above; seed already flags `needs_verification_exact`. Wickner 1994 Science PMID unconfirmed this session.

8. **YEAST-ASYM-AGGREGATE (Erjavec/Liu)** — Aguilaniu PMID 12610228 VALIDATED; Erjavec and Liu 2010 PMIDs not confirmed. Flag partial.

9. **GA-04 (immune inheritance)** — Null ref in seed. Candidate: Netea et al. trained immunity. Must be populated.

10. **GA-05 (maternal mitochondria)** — Null ref in seed. Textbook biology but must cite a primary source.

11. **GA-06 (fetal oogenesis)** — Null ref in seed. Candidate: Pepling 2012 Biol Reprod. Must be populated.

12. **GA-08 (aging waves 40/44/60)** — **CONFLICT**: Lehallier 2019 reports waves at 34/60/78, not 40/44/60. Figure ages must be corrected or a source supporting 40/44/60 must be identified.

13. **GA-09 (microchimerism)** — Null ref in seed. Lo, Nelson, Bianchi lab papers exist but PMIDs not confirmed this session.

14. **GA-12 (peptide-first world)** — Wills & Carter bioRxiv and Guseva et al. PNAS cited but PMIDs not confirmed.

---

## SeedGraph Recommendation

The SeedGraph sibling repo currently has no Shadow-Dogma seed (only SEED-001 QEC kernel). **Recommended action (operator-gated, do NOT write to seedgraph repo):** Create `SEED-NNN-shadow-dogma-conformational-information.md` in seedgraph for v2, capturing the TWO-DOGMAS / PRION-CHANNEL / ANALOG-DIGITAL-BOUNDARY atoms as an atomized knowledge node with traceable citations once all ESTIMATE items above are resolved. This would give the Shadow Dogma hypothesis a clean provenance anchor in the KG for future writeback through Overwatch Phase 126.

---

*This document was built on 2026-06-12 by automated verification (Claude Code / shadow-seeds session). No PMIDs or DOIs were fabricated. Unconfirmed identifiers are explicitly marked ESTIMATE or CONFLICT above.*
