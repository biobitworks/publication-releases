# The Shadow Dogma: A Hypothesis of Fragment-Inheritance Aging Mediated by Immune Distribution

**Draft v0.1 — 2026-06-12 — HUMAN EDITING REQUIRED**

> **GOVERNANCE NOTICE — READ BEFORE EDITING.** This is a rough draft for human editorial revision. It is governed by the Shadow Seeds claim ceiling: SOFTWARE / REPRODUCIBILITY / GOVERNANCE evidence only. No biological, clinical, diagnostic, therapeutic, or aging-reversal claim may be promoted beyond HYPOTHESIS without a governed EXP explicitly authorizing it. Every non-trivial biological claim carries an inline `[ATOM: <id>]` tag; resolve each tag against the seed registry before citation. Sentences tagged **[ESTIMATE — seed needs verification]** require literature verification before manuscript promotion. The inline failures/successes ledger in Section 5 is first-class and must not be removed. Patent-first clearance required before any public posting.

---

## Authors

[HUMAN: fill in authorship and affiliations]

---

## Abstract (~200 words)

Aging biology has organized its major processes — loss of proteostasis, cellular senescence, inflammaging, and the accumulation of aggregated proteins — largely as parallel phenomena. We propose, and label throughout as a hypothesis, that these may be partial readouts of one under-measured currency: low-abundance, post-translationally modified peptides and conformational **fragment burden**. We term the proposed channel the **Shadow Dogma**: a peptide-to-peptide conformational information channel that runs alongside the Central Dogma of molecular biology. The channel's existence is *established* at its base — prion and prion-like templated conformational conversion, and protein-only inheritance in fungal and yeast model organisms [ATOM: PRION-CHANNEL] — but its *reach* as an aging-relevant, immune-distributed, transgenerational network is the open hypothesis. We integrate this with immune aging: MHC peptide presentation as a candidate distribution mechanism, immunosenescent clearance failure as a candidate accumulation mechanism, and inflammaging as the systemic readout [ATOM: MHC-BROADCAST-CANONICAL]. A non-chromatin germline cascade — microchimerism, fetal oogenesis, and the oocyte as a long-lived proteostatic substrate — provides a proposed transgenerational substrate. Because the channel is material and non-chromatin, it sidesteps the germline-reprogramming barrier that constrains epigenetic transgenerational inheritance. We also report the critical experiment that failed: cross-protein disorder-state transfer is null-consistent under composition-matched shuffle. The decisive unmet test is a longitudinal, proteome-wide measurement of fragment burden jointly with immune processing across the lifespan.

---

## 1. Introduction: The Central Dogma and Its Shadow

The central dogma of molecular biology — DNA → RNA → protein — is the dominant channel of biological heredity, and modern sequence bioinformatics is built almost entirely to read its output. That output is *digital-like*: four nucleotides, twenty canonical amino acids, discrete symbols that can be indexed, aligned, and compared with great precision. But the genetic code is not strictly twenty: selenocysteine (the 21st amino acid) and pyrrolysine (the 22nd) are genetically encoded through stop-codon recoding, and synonymous codons specifying the same amino acid translate at different rates and yield different co-translational folding outcomes [ATOM: CODON-YIN-YANG; Komar 2016, *Hum Mol Genet*, PMID 27354349]. The amino-acid sequence is therefore a lossy projection: identical-sequence peptides need not share a single conformational fate.

There is, in parallel, a second and far older information channel that the central-dogma framing does not capture. Proteins can transmit a conformational state directly from one protein molecule to another — copied by templating, heritable in model organisms, and independent of any change in nucleic-acid sequence. This is established biology: the mammalian prion PrP^Sc seeds its misfolded conformation onto normal PrP; the yeast prions [PSI+] and [URE3] are genuine examples of non-genetic conformational inheritance; functional prion-like systems such as CPEB/Orb2 operate in protein-based memory storage [ATOM: PRION-CHANNEL; exact PMIDs pending SD-A1 verification — [NEEDS-VERIFICATION]]. In budding yeast this channel is tied concretely to aging: mother cells asymmetrically retain damaged and aggregated proteins in an Hsp104-dependent manner so that daughter cells are rejuvenated [ATOM: YEAST-ASYM-AGGREGATE; Aguilaniu/Erjavec lineage — [NEEDS-VERIFICATION exact refs]]. The templating step is driven by short peptide cores — for example the tau VQIVYK hexamer and the amyloid-beta KLVFF pentamer — not by whole folded globular proteins [ATOM: PRION-LIKE-LCD; Daskalov 2014; Eufemio 2026; Schwidetzky 2023].

We refer to this peptide→peptide conformational channel as the **Shadow Dogma**: not a replacement for the Central Dogma, but a surviving sibling of it — an ancestral, analog-like conformational channel that operates in the shadow of the dominant sequence channel [ATOM: TWO-DOGMAS]. We then advance a hypothesis, labeled as such throughout: that this channel may carry conformational context across biological space and time in ways relevant to aging. The channel's existence is established at its base; its reach as a connected, immune-distributed, transgenerational information network is the open, untested hypothesis.

Aging biology contains all the components that such a channel would need. The hallmarks of aging [ATOM: AGING-HALLMARKS-IMMUNE-AGING; López-Otín et al. 2013, PMID 23746838; López-Otín et al. 2023, PMID 36599349], senescence and its secretory phenotype [ATOM: SENESCENCE-SASP; Coppé et al. 2008, PMID 19053174; Gorgoulis et al. 2019, PMID 31675495], and inflammaging and garb-aging [Franceschi et al. 2000, PMID 10911963; Fulop, Larbi, Dupuis et al. 2017, PMID 29375577 — **attribution note: this is the Fulop et al. review, not a Franceschi-authored piece**] are established fields that this paper cites rather than rediscovers. Our narrower proposal is that peptide/conformational fragment burden could act as a cross-hallmark currency, with the aging immune system as both the proposed distribution mechanism and the main measurement confounder.

The paper proceeds as follows. Section 2 establishes the biological foundations as separately-published findings that we integrate but do not claim as novel. Section 3 describes the Shadow Dogma synthesis: the specific threading of those foundations into a fragment-inheritance channel. Section 4 describes the readout gap — the measurement that would convert the hypothesis to a result — together with the disorder-cloud representation and the currently-null cross-protein result. Section 5 gives the failures/successes ledger. Section 6 is Discussion. Section 7 states limitations and the claim ceiling.

A brief note on deep time, offered strictly as conceptual precedent and not as aging evidence: peptide-centered information has been argued to predate or co-emerge with templated nucleic-acid coding [ATOM: PEPTIDE-FIRST-WORLD-PRECEDENT; Wills & Carter 2017, PMID 28903058; Guseva, Zuckermann & Dill 2017, DOI 10.1073/pnas.1620179114]. If correct, the peptide→peptide channel is not a late curiosity but the oldest of the information channels — which would make the Central Dogma the relative newcomer. We use this framing only to motivate why the channel deserves study; no origin-of-life claim is made.

---

## 2. Foundations: Established Biology This Hypothesis Integrates

This section establishes each pillar on its own published authority. Nothing in this section is claimed as novel; the novelty is in the threading (Section 3). A reviewer who refutes the synthesis by decomposing it back into its individually known parts is committing what might be called the mosaic fallacy: the novelty of a synthesis can survive the parts being known, as long as the specific coupling is new and testable.

### 2.1 Hallmarks of aging

The hallmarks framework [PMID 23746838; PMID 36599349] organizes the major aging processes: loss of proteostasis, cellular senescence, inflammaging, altered intercellular communication, and the accumulation of aggregates and crosslinks. The Shadow Dogma hypothesis is not a new hallmark. It is a proposal about what flows along the existing "altered intercellular communication" hallmark, what is sensed as "chronic inflammation," and what feeds "loss of proteostasis" over time. The relationship among these three established hallmarks, mediated by fragment burden, is the integrative claim.

### 2.2 Senescence and the SASP

Replicative senescence is established since Hayflick & Moorhead (1961, PMID 13905658). Senescent cells secrete the senescence-associated secretory phenotype (SASP) — a collection of inflammatory cytokines, proteases, and other factors that alter the surrounding tissue [Coppé et al. 2008, PMID 19053174]. The community consensus definition is provided by Gorgoulis et al. 2019 (PMID 31675495). In the Shadow Dogma framing, SASP is the systemic inflammatory output downstream of local fragment-burden accumulation, not merely a stochastic cellular event.

### 2.3 Inflammaging and immunosenescence

Inflammaging — the chronic, sterile, low-grade inflammation of aging — is Franceschi's observation that the aged organism's innate immune system is perpetually stimulated by accumulated damaged self-material, including aggregates and modified proteins (Franceschi et al. 2000, PMID 10911963). Immunosenescence is the age-associated decline of immune surveillance and clearance. The relationship between the two is reviewed as two sides of one coin (Fulop, Larbi, Dupuis et al. 2017, PMID 29375577). In our framing, immunosenescence is the failure-to-clear mechanism that allows fragment burden to accumulate, and inflammaging is the readout of that accumulation.

### 2.4 Protein-only inheritance in model organisms

Protein-only inheritance is real and established in non-mammalian systems. The yeast [PSI+] and [URE3] prions demonstrate genuine non-genetic conformational inheritance [ATOM: YEAST-PRION-INHERITANCE — [NEEDS-VERIFICATION exact refs]]. Mother cells in budding yeast asymmetrically retain Hsp104-dependent aggregates, renewing daughter cells at each division [ATOM: YEAST-ASYM-AGGREGATE — [NEEDS-VERIFICATION exact refs]]. The HET-s/Podospora infectious prion demonstrates that conformational information can propagate as an infectious amyloid fiber [Maddelein et al. 2002, PMID 12032295; Dos Reis et al. 2002, PMID 11733532 — [NEEDS-VERIFICATION]]. Prion strain diversity is conformationally encoded (Telling et al. 1996, PMID 8953038; Legname et al. 2004, PMID 15029196). These facts establish the channel's existence and templating mechanism in model organisms; the human aging reach is the separate, untested hypothesis.

### 2.5 Conformational information capacity: dark proteome and LLPS

Conformational information is not limited to compact, well-folded domains. The dark proteome — regions of the proteome with no resolvable single fold and no structural template — is large and pervasive [ATOM: DB-DARKPROTEOME; Perdigão et al. 2015, PMID 26578815]. Intrinsically disordered regions occupy continuous conformational ensembles that can mature through liquid-liquid phase separation (LLPS) toward aggregation: LLPS is driven by large-scale conformational fluctuation of disordered molecules [Majumdar et al. 2019, PMID 31260322], and hydrophobic-interaction-driven phase separation can facilitate fibrillization [PMID 33279579 — first author `[VERIFY-AUTHOR]`]. Seeded misfolded aggregation can occur subclinically for decades before symptom onset, as demonstrated by alpha-synuclein seed-amplification assays [Kuang et al. 2024, PMID 39574205]. This space — disordered, dark, ensemble-valued, LLPS-capable — constitutes an enormous conformational capacity. We label this explicitly as a bandwidth argument, not evidence of use. Capacity is not utilization.

### 2.6 Evolutionary rationale

Aging may have evolved in part as a mechanism for limiting the transmission of chronic disease to kin — "programmed aging as pathogen control" [Lidsky & Andino 2022, PMID 36096982]. In the Shadow Dogma framing, prion-like fragments are the quasi-pathogen and immune aging is the quasi-control mechanism — a proposed evolutionary coupling, not a demonstrated mechanism.

### 2.7 Aging waves

Plasma-proteome proteomic studies reveal non-linear transitions in the aging process at particular life stages [ATOM: AGING-WAVES]. Lehallier et al. (2019, PMID 31806903) identified three non-linear transition waves in the human plasma proteome at approximately the **fourth, seventh, and eighth decades** of life. **EDITORIAL NOTE: The graphical abstract timeline must cite these transitions by decade as reported (fourth/seventh/eighth decades, Lehallier 2019), not as ages 40/44/60 unless a separate, verified source supports those exact ages [ATOM: GA-08 accuracy flag].** Shen/Snyder (2024, PMID 39143318) **[ESTIMATE — seed needs verification]** may support transitions near ages 44 and 60.

### 2.8 Long-lived proteins and oocyte proteostasis

Many proteins in long-lived cells are themselves long-lived, maintained for years to decades without replacement [see Savas 2012; Toyama 2018; Fornasiero 2018 — [ATOM: FRAG-INHERIT, [NEEDS-VERIFICATION exact refs]]]. The oocyte is a particularly striking example: mammalian oocyte proteins must survive extended arrest and maintain proteostatic integrity across a reproductive lifespan [Sala & Morimoto 2022, PMID 34654604; Harasimov et al. 2024, PMID 38902423; Duncan et al. 2017, PMID 28994181]. Human oocyte proteostasis declines with advanced maternal age [Galatidou et al. 2024, PMID 38870523]. This makes the oocyte a real and biologically credible long-lived substrate — not proof of inherited pathological burden, but a plausible vessel for it.

### 2.9 Microchimerism and transgenerational immune overlap

Feto-maternal microchimerism — the bidirectional trafficking of cells during pregnancy, with fetal cells persisting in the mother for decades — is established [Cómitre-Mariano et al. 2021, PMID 35072002; Gammill et al. 2011, PMID 21912617]. During pregnancy a woman can simultaneously harbor microchimeric cells from her own mother and from her current child, in an HLA-mediated constellation [Hahn et al. 2019, PMID 31001268 — **[VERIFY-ATTRIBUTION]: exact "grandmother's cells" three-generation simultaneity claim needs text confirmation**] **[ESTIMATE — seed needs verification]**. This establishes a concrete biological substrate for the three-generation immune overlap depicted in the graphical abstract's germline cascade [ATOM: MICROCHIMERISM, MATERNAL-GRANDMOTHER-MICROCHIMERISM, GA-09].

Trained immunity — the epigenetic reprogramming of innate immune cells to sustain a memory-like state without adaptive immunity — provides an additional non-chromatin carrier of immune context across cellular generations [Netea et al. 2016, PMID 27102489] [ATOM: TRAINED-IMMUNITY].

### 2.10 Non-chromatin inheritance and the reprogramming barrier

Mammalian epigenetic transgenerational inheritance is constrained: germline reprogramming largely erases methylation marks and most chromatin-borne information during meiosis and early development [Skvortsova et al. 2018, PMID 30425324; Xavier et al. 2019, PMID 31374565]. Any inheritance hypothesis that relies on chromatin marks faces this barrier directly. The Shadow Dogma channel is not a chromatin mark, and the reprogramming-barrier objection therefore does not apply in the same way. This is the differentiator: a non-chromatin inheritance channel [ATOM: TWO-DOGMAS, ORDER-DISORDER-EDGE].

---

## 3. Theory: The Shadow Dogma as a Fragment-Inheritance Channel

This section advances the paper's single integrative hypothesis. We do not claim to have discovered germline burden, immune aging, prions, or the dark proteome; each is a large, well-owned field cited above. The proposed novelty is the specific threading: that peptide and conformational fragment burden may act as a cross-hallmark information currency, distributed and misprocessed by the aging immune system, carried over a binding-independent disordered-proteome channel, across the lifecourse and potentially across generations.

### 3.1 The channel: peptide→peptide conformational templating (ESTABLISHED) and its proposed reach (HYPOTHESIS)

The base of the channel is established biology: prion and prion-like templated conversion copies a conformation rather than a sequence. The defining feature is that the transfer does not require a stable, high-affinity lock-and-key interaction event. The information that passes is *which conformation*, not *which partner bound*. This makes the prion channel a genuinely different information modality from the affinity-based protein interactome, and it is the published, established fact on which the synthesis rests [ATOM: PRION-CHANNEL].

What remains strictly hypothesis is the reach: that this channel operates at sufficient scale, specificity, and connectivity to constitute an aging-relevant network in mammals. Every proposed link in that network — immune distribution, germline transmission, somatic readout — is a distinct, labeled, untested sub-hypothesis.

The codon silent layer adds a second dimension to the argument [ATOM: CODON-YIN-YANG]: identical amino-acid sequences can have different conformational fates depending on translation rate, co-translational folding, and mRNA stability — analog-like information that the digital amino-acid sequence discards. This motivates the analog/digital-boundary framing without asserting a mechanism [ATOM: ANALOG-DIGITAL-BOUNDARY, ORDER-DISORDER-EDGE].

### 3.2 Immune aging as the integrating mechanism, not a confounder

The central reframing is that the aging immune system is not a nuisance variable downstream of damage but the proposed *integrating mechanism* of the channel — and simultaneously its main measurement confounder. Three established processes supply the three operations the channel would need.

**Distribution.** MHC class I and II presentation already displays peptide fragments of the intracellular and extracellular proteome to the immune system as a routine function [ATOM: MHC-BROADCAST-CANONICAL]. We hypothesize — and label as hypothesis — that this broadcast is a candidate route by which fragment/conformational context could be distributed across cells and tissues. Whether MHC display carries *conformational* context, rather than merely sequence identity, is an open sub-hypothesis.

**Accumulation.** Immunosenescence — the age-associated decline of immune surveillance and clearance — provides a mechanism by which damaged and aggregated self-material fails to be removed and instead accumulates as a burden integral over time. This is the proposed reason fragment burden increases with age rather than being cleared.

**Systemic readout.** Inflammaging — the innate sensing of accumulated damaged self-molecules [ATOM: AGING-HALLMARKS-IMMUNE-AGING] — supplies the body-wide signal linking local burden to systemic aging phenotype. In the hallmarks framing: fragment/conformational burden sits at the junction of loss of proteostasis (source), altered intercellular communication (distribution), chronic inflammation (readout), and cellular senescence (SASP amplifier). The hypothesis is that one currency flows through those four established hallmarks — not that a new hallmark is needed.

The honest tension we elevate rather than hide: immune presentation is *both* the proposed broadcast channel *and* a process that confounds attribution of any measured peptide to inheritance versus routine antigen processing. Resolving this is the purpose of the required measurement, not a solved problem [ATOM: MHC-BROADCAST-CANONICAL].

### 3.3 The germline cascade

The Shadow Dogma hypothesis proposes that fragment/conformational burden is not merely somatic but germline-transmitted, riding a cascade that overlaps three generations. The developmental scaffold is the overlap in the female germline: a woman's egg cells form in her own fetal ovaries while she is still a fetus inside her mother — meaning the oocytes that may become the next generation existed while their eventual mother was herself a gestating fetus [ATOM: FETAL-OOGENESIS, GA-06 — [NEEDS-VERIFICATION exact developmental reference]]. **[ESTIMATE — seed needs verification]**

Threading through that scaffold, the proposal identifies several carriers at different evidence levels:

- **Mitochondrial inheritance** (maternal mtDNA) is established and uncontroversial as a non-chromatin maternal channel [ATOM: MITO-MATERNAL — [NEEDS-VERIFICATION exact PMID]]. **[ESTIMATE — seed needs verification]**
- **Fragment/conformational burden** — the oocyte as a long-lived, proteostasis-dependent vessel for inherited modified peptides — is the central hypothesis and is unproven in mammals. The oocyte proteostasis literature supports the plausibility of the vessel; it does not demonstrate inherited pathological burden [ATOM: FRAG-INHERIT, GA-03].
- **Microchimeric immune overlap** — whole cells trafficked during pregnancy that persist for decades — is established (Section 2.9). Their role in any Shadow Dogma transmission is hypothesized, not demonstrated.
- **Trained immunity** — the epigenetic cellular memory of innate immune state — provides a mechanism by which immune processing context could survive across cell generations [ATOM: IMM-INHERIT; Netea et al. 2016, PMID 27102489].

The result is a layered germline cascade: mitochondrial (established), microchimeric and trained-immune (established carriers, on-thesis), fragment/conformational (the central hypothesis). Only the fragment-inheritance link is novel; the carriers that would support it are real.

### 3.4 The non-chromatin positioning

The standard and serious objection to mammalian transgenerational inheritance is that epigenetic marks are largely erased by germline reprogramming (Skvortsova et al. 2018, PMID 30425324; Xavier et al. 2019, PMID 31374565). Mammalian epigenetic transgenerational inheritance is therefore rare and debated. If the Shadow Dogma were a chromatin mark, this objection would largely defeat it.

The positioning claim is stated plainly: the proposed channel is not a chromatin mark. Its carriers — material/conformational fragment burden, microchimeric cells, and trained innate immune state — do not depend on surviving meiotic demethylation or chromatin reprogramming. This makes the Shadow Dogma a *non-chromatin inheritance channel*, which is a genuine differentiator from the epigenetic-TEI debate. It is not a claim that the non-chromatin channel is demonstrated, nor a claim to have resolved the epigenetics field. It is a claim that the usual disqualifying objection does not apply in the same way.

The nearest neighbor in the damage-repair paradigm is de Grey's SENS framework, which treats intracellular and extracellular aggregates and crosslinks as removable damage categories [PMID 17105381 / 20630854 / 23037635 — [NEEDS-VERIFICATION which is canonical]]. Fragment burden is a cousin of those damage categories. The differentiator from SENS is the direction of the claim: SENS treats aggregates as damage *to clear*, whereas the Shadow Dogma synthesis treats fragment/conformational burden as an inherited *information channel* — something that can be copied, distributed, and read out across generations, not only something to be removed.

---

## 4. The Readout Gap and the Disorder-Cloud Representation

### 4.1 The measurement gap

The Shadow Dogma hypothesis has one sharp testable opening, and that opening is a *measurement gap* rather than a narrative gap. No existing dataset measures proteome-wide, low-abundance modified-peptide and fragment burden *longitudinally* and *jointly* with immune processing and presentation across the germline → soma → senescence axis [ATOM: SD-JOINT-MEASUREMENT-GAP].

Existing measurement approaches each cover part of the space but miss the joint channel by construction:

- **Plasma-proteome abundance clocks** measure protein levels, not low-abundance modified-fragment burden [Lehallier et al. 2019, PMID 31806903; Oh et al. 2023, PMID 38057571].
- **DNA-methylation epigenetic clocks** read a chromatin mark and are blind to a non-chromatin channel by design.
- **Single-target seed-amplification assays** detect one misfolded species before clinical symptoms — impressive for what they do — but are single-analyte and do not integrate immune processing across the lifecourse [Kuang et al. 2024, PMID 39574205].
- **Germline proteostasis-reset studies** measure the oocyte/embryo maintenance machinery but do not measure inherited modified-peptide burden longitudinally.

Building the joint longitudinal fragment-burden × immune-processing measurement is therefore the falsification path — and a candidate method contribution distinct from any existing clock or assay. The present paper establishes the measurement gap; it does not fill it.

### 4.2 Disorder as the readout axis

Disorder is the natural readout axis for a conformational channel. A residue-level disorder score projects continuous conformational ensemble state into a number: standard predictors include metapredict [PMID 34480923; ATOM: TOOL-METAPREDICT], IUPred-3 [PMID 34048569; ATOM: TOOL-IUPRED3], and the DisProt curated database [PMID 41249866; ATOM: DB-DISPROT]. These tools are useful baselines. They also expose the core gap: canonical predictors are single-pass, canonical-20, and produce point estimates. They collapse modified residues to their canonical parent, report a single number, and do not expose width, context-dependence, or predictor disagreement [ATOM: SCORING-GAP, PREDICTOR-BLINDNESS].

That limitation matters because the hypothesized channel would live exactly where those tools cannot read: post-translational modifications (PTMs), non-canonical amino acids (ncAAs), short fragments, metal-modified residues, local flanking effects, and higher-order assemblies. When a canonical predictor returns an identical score for a canonical residue and its glycated or deamidated counterpart, that delta = 0 should be interpreted narrowly: the canonical predictor input channel is *blind* to the modification, not evidence that the modification has no conformational effect [ATOM: PREDICTOR-BLINDNESS, SCORING-GAP].

### 4.3 The disorder cloud: a representational contribution

This paper proposes discussing disorder as a **cloud** rather than only a point. A disorder cloud for a given residue or fragment preserves the mean disorder estimate together with uncertainty width, predictor disagreement, local flank delta, and in-context transition behavior. Width is the useful extra signal: a narrow cloud marks robustly disordered behavior; a wide cloud marks context-dependence or predictor disagreement that a point estimate would hide.

> *Disorder cloud representation:* mean probability | uncertainty width | predictor disagreement | local flank delta

This is a representational and conceptual contribution, not a validated predictor. The disorder cloud is richer than a single score; it is not a ground-truth ensemble measurement. Accuracy is not claimed here; accuracy is gated on calibration against CAID/DisProt disorder truth, which remains the task of Paper 2 (XenoDisorder instrument).

[ATOM: DISORDER-CLOUD-FRAMING, SCORING-GAP]

### 4.4 The null result: cross-protein disorder-state transfer is terminal-negative

The implementation of the disorder-state-transfer proxy at the cross-protein level produced a decisive negative result that is reported here as first-class, not omitted. Under composition-matched shuffle and related geometry-aware nulls, the cross-protein disorder-ratio result is **rank-deficient and null-consistent**. In plain terms: when the proposed cross-protein signal is tested against appropriate controls, it does not hold.

This is recorded as terminal-negative (EXP-228, EXP_019). The conclusion is exact and bounded: the *schema* — a direction-aware, orientation-typed, scale-aware object taxonomy for representing disorder relationships between fragments — is defensible as a representational and governance contribution. The *positive cross-protein biology is not*, and it is reported here as a disclosed negative finding. The disorder-state-transfer proxy enters this paper strictly as a hypothesis-generation surface and representation tool, not as a validated interaction, predictor, or mechanism claim.

[ATOM: SCORING-GAP; internal: CELLICO-BIO-KEY-POINTS-INTEGRATION §2-3]

### 4.5 Future calibration path (Paper 2)

XenoDisorder (Paper 2) owns the follow-up: a short-fragment ncAA/PTM disorder instrument, calibrated against CAID/DisProt ground truth. Paper 1 establishes the measurement gap and the representation; Paper 2 addresses the calibration problem. Neither paper claims per-residue disorder accuracy without the CAID/DisProt gate. Substrata/Fragmentum is named as a planned multi-scale cloud layer; biocircuit is named as a planned signal-shape layer. Both remain downstream plans with the terminal-negative cross-lane result carried honestly forward.

[ATOM: XENODISORDER-FOLLOWUP, SUBSTRATA-FRAGMENTUM-PLAN, BIOCIRCUIT-SHAPE-PLAN]

---

## 5. What This Paper Claims vs What It Does Not Claim

> **HUMAN: This box is load-bearing. Do not edit without governance review.**

| This paper CLAIMS (as HYPOTHESIS) | This paper does NOT claim |
|---|---|
| A peptide→peptide conformational channel exists and is established in prion/yeast systems | That this channel operates as an aging mechanism in humans |
| Fragment/conformational burden is a *candidate* cross-hallmark currency | That fragment burden is causally proven to drive aging |
| Immune aging (MHC, immunosenescence, inflammaging) is a *candidate* distribution and accumulation mechanism | That immune aging *is* the channel in humans |
| A non-chromatin germline cascade (microchimerism, oocyte proteostasis, trained immunity) provides a *plausible* substrate | That germline fragment inheritance is demonstrated in any mammal |
| The joint fragment-burden × immune-processing measurement is absent from existing datasets | That this absence proves the Shadow Dogma |
| The disorder cloud is a richer *representation* than a point estimate | That the disorder cloud is an accurate or validated predictor |
| The cross-protein disorder-ratio result is null-consistent (failure, preserved) | Any positive cross-protein biology |
| The disorder-cloud schema is defensible as a representation and governance contribution | That the schema validates any biological interaction or mechanism |

**Additional hard limits:**
- No clinical, diagnostic, or therapeutic claim.
- No aging-reversal claim.
- No SUDC/SIDS biological promotion (any fragment data is SUDC/control, technical-candidate-only).
- No sequences, scorer weights, property-space, TPE matrices, or comparator math disclosed.
- Patent-first clearance before any public posting.

---

## 6. Discussion

### 6.1 What would move this hypothesis toward a result?

The sharpest falsifiable wedge is not a narrative argument but an experiment: a **longitudinal, proteome-wide, modified-peptide and fragment-burden dataset, measured jointly with immune processing and presentation, across germline, soma, and senescence**. No existing dataset does this. Building that dataset is the falsification path.

Two near-future benchmarks are relevant as *comparators for future tests*, not as current validations. The Ding 2025 aging-wave benchmark is source-family-bound only at the current Shadow Seeds gate: Cellico-bio EXP089 provides read-only custody and redacted replay evidence, but the processed age/tissue metric contract required for a numeric EXP-011 run is missing. It therefore provides a future aging-proteome reference that a fragment-burden dataset could be tested against, not a current Shadow Dogma result. The XenoDisorder disorder instrument (Paper 2), once calibrated against CAID/DisProt ground truth, would provide the ncAA/PTM-aware readout that current predictors lack. These are future tests, not current results.

The disorder-readout instrument becomes useful only after its calibration gates close: CAID/DisProt calibration, cloud reliability, applicability-domain confidence, and label-provenance verification. Opening experimental tests before those gates close would produce circular or artifact-prone results.

### 6.2 Relation to existing aging frameworks

The Shadow Dogma hypothesis is not a new hallmark of aging and does not require retiring any existing framework. Its relationship to the major existing paradigms is:

**Damage-repair (SENS):** SENS treats aggregates and crosslinks as removable damage. Shadow Dogma treats fragment/conformational burden as a transmissible information channel. The overlap is real — both concern aggregate burden — but the direction of claim differs: SENS removes; Shadow Dogma transmits and reads out.

**Epigenetic clocks:** DNA-methylation clocks are orthogonal to a non-chromatin channel. They would not detect fragment-burden inheritance by design. This does not mean clocks are wrong; it means they are measuring a different projection of aging.

**Abundance-proteome clocks:** Plasma proteome waves [Lehallier 2019, PMID 31806903; Oh 2023, PMID 38057571] measure protein levels. The Shadow Dogma channel, if real, would live in the low-abundance modified-fragment fraction that level-based measurements do not directly read. The "missing longevity quotient" — the variance in healthy aging not captured by abundance measurements — is a prediction of the framework and a testable gap, not yet evidence for it.

**Transgenerational epigenetic inheritance (TEI):** The non-chromatin-channel positioning distinguishes the Shadow Dogma from standard epigenetic TEI. The reprogramming barrier does not apply in the same way, because the proposed carriers are material and cellular, not DNA-methylation marks.

### 6.3 Why the negative result is first-class

Reporting the cross-protein null result as a first-class finding, rather than omitting it, is a deliberate methodological choice. A hypothesis paper that presents only the supporting foundations and hides the failed cross-protein test is not credible. The negative result bounds the hypothesis: the cross-protein disorder-ratio signal, as currently implemented, does not survive composition-matched shuffle. That is important information. It means the positive biology cannot be claimed, and it narrows the space of what a future test would need to address. Negative results preserved in the public record are what the field can build on.

### 6.4 Analog/digital boundary and the order–disorder edge

Life operates at a dynamic balance between order and disorder. Complete order — crystallization — is effectively death; complete disorder is structural disintegration. Functional proteins sit at an edge between these extremes, and the order↔disorder balance is both a structural fact and, we propose, an information frontier. Fragment/conformational burden is hypothesized to be one signal carried along that edge [ATOM: ORDER-DISORDER-EDGE]. The analog/digital-boundary framing places this edge in an information-theoretic context: canonical sequence bioinformatics reads the digital-like, 20-symbol, order-favoring projection, while the Shadow Dogma channel proposes that the analog-like, continuous, disorder-sensitive projection carries a complementary information layer [ATOM: ANALOG-DIGITAL-BOUNDARY, TWO-DOGMAS].

---

## 7. Limitations and Claim Ceiling

The following limitations are load-bearing. They must not be softened, removed, or moved to a supplement at manuscript promotion.

1. **This is a hypothesis, not a result.** The Shadow Dogma is a proposed mechanism integrating established findings. The human causal claim is unproven. No published experiment has measured the proposed joint channel.

2. **The cross-protein proxy is terminal-negative.** The cross-protein disorder-state-transfer implementation is rank-deficient and null-consistent under composition-matched shuffle (EXP-228, EXP_019). It is presented as a representation and hypothesis-generation surface, never as a validated predictor, interaction, or mechanism.

3. **Capacity is not utilization.** "Practically unbounded, binding-independent conformational capacity" is a bandwidth argument that motivates the hypothesis and bounds plausibility. It is not evidence that the channel is used for inheritance in mammals.

4. **Immune presentation is mechanism and artifact simultaneously.** MHC presentation is the proposed distribution channel and a confounder of attribution in the same experiment. Resolving the two is the experiment's purpose, not its result.

5. **Explanatory-reach items are predictions, not confirmations.** Somatic cell nuclear transfer (SCNT)/cloning efficiency decline with donor age [Wilmut et al. 1997, PMID 9039911; Cervera & García-Ximénez 2003, PMID 12828414; Yamada et al. 2014, DOI 10.1038/nature13287], oocyte/reproductive aging, and the abundance-clock "missing longevity quotient" are *testable predictions* of the framework. They define future experiments; they are not evidence for the framework now.

6. **Several seed atoms require verification before camera-ready.** Items tagged `[NEEDS-VERIFICATION]` or `[ESTIMATE — seed needs verification]` throughout this draft must be resolved in SD-A1 before manuscript submission.

7. **Cite the foundations; retire "zero prior art."** Every foundation in Section 2 is a large, well-owned field. The defensible contribution is a specific, named, measurable integration — not a claim of unoccupied territory.

8. **Firewall: SUDC ≠ SIDS.** Any fragment data referenced in this manuscript is SUDC/control, technical-candidate-only, IP-redacted. No sequences, scorer weights, property-space, TPE matrices, or comparator mathematics are disclosed. No biological, clinical, diagnostic, therapeutic, or aging-reversal promotion.

---

## Failures / Successes Ledger

*This ledger is first-class and must appear in the final manuscript. Removing or abbreviating it weakens the paper's credibility.*

| Tested | Outcome | Class |
|---|---|---|
| Exhaustive fragment enumeration (~1B fragments, deterministic, hashed) | **SUCCESS** | software / method |
| Aggregation scoring vs WaltzDB benchmark | **SUCCESS — concordant (~0.93)** | software / method |
| Predictor "blindness" / modification-invariance demonstration (canonical tools flatten ncAA/PTM) | **SUCCESS — demonstrated** | software / method |
| Disorder cloud = fragment-level, in-context, modification-aware uncertainty layer | **SUCCESS as a representation** (NOT a validated ensemble; accuracy deferred to clean CAID/DisProt calibration) | interpretability |
| Governed pipeline catching errors (mislabeled NANOG row; an AI-generated erroneous "fix") | **SUCCESS — caught before claim promotion** | governance |
| Cross-protein cross-seeding signal (order-dependent disorder-ratio) | **FAILURE — null-consistent / terminal-negative** (EXP-228 p ≈ 0.97; EXP_019 nulls) | negative result, preserved |
| Relational-disorder-field differentiation (INSIGHT-006 RT-1) | **FAILURE — falsified** | negative result, preserved |
| Scorer specificity (panel vs background, k ≥ 3) | **PARTIAL — software / simulation evidence only**, not cross-seeding causation | bounded |
| XenoDisorder canonical-residue accuracy (CAID) | **PROVISIONAL ~0.68** (competitive with IUPred3, below metapredict) — number pending clean rerun (NANOG + mask defects) | provisional |
| Fragment-inheritance network / immune broadcast / germline transmission as used in humans | **HYPOTHESIS — untested** | hypothesis |

---

## Acknowledgments

[HUMAN: fill in]

---

## References

*The reference list below is organized by PMID. Every PMID carries the corresponding DOI; per PubMed attribution policy, DOIs must accompany PMIDs at camera-ready. Items marked `[NEEDS-VERIFICATION]` require SD-A1 verification before submission. Items marked `[VERIFY-ATTRIBUTION]` require confirmation of cited claim against source text.*

| PMID | DOI | Short form | Status |
|---|---|---|---|
| 23746838 | 10.1016/j.cell.2013.05.039 | López-Otín et al. 2013, Hallmarks of aging, *Cell* | session-verified |
| 36599349 | 10.1016/j.cell.2022.11.001 | López-Otín et al. 2023, Hallmarks: expanding universe, *Cell* | session-verified |
| 13905658 | 10.1016/0014-4827(61)90192-6 | Hayflick & Moorhead 1961, *Exp Cell Res* | session-verified |
| 19053174 | 10.1371/journal.pbio.0060301 | Coppé et al. 2008, SASP, *PLoS Biol* | session-verified |
| 31675495 | 10.1016/j.cell.2019.10.005 | Gorgoulis et al. 2019, Senescence consensus, *Cell* | session-verified |
| 10911963 | 10.1111/j.1749-6632.2000.tb06651.x | Franceschi et al. 2000, Inflamm-aging, *Ann N Y Acad Sci* | session-verified |
| 29375577 | 10.3389/fimmu.2017.01960 | Fulop, Larbi, Dupuis et al. 2017, Immunosenescence & inflamm-aging, *Front Immunol* | session-verified; **attribution corrected from "Franceschi 2017"** |
| 36096982 | — | Lidsky & Andino 2022, Aging as pathogen control | session-verified |
| 26578815 | 10.1073/pnas.1508380112 | Perdigão et al. 2015, Dark proteome, *PNAS* | session-verified |
| 31260322 | 10.1021/acs.jpclett.9b01731 | Majumdar et al. 2019, LLPS conformational unwinding, *J Phys Chem Lett* | session-verified |
| 33279579 | 10.1016/j.jmb.2020.166731 | Tau LLPS→fibrillization 2020, *J Mol Biol* | session-verified; first author `[VERIFY-AUTHOR]` |
| 39574205 | 10.1186/s40035-024-00449-2 | α-syn SAA review 2024, *Transl Neurodegener* | session-verified |
| 31806903 | 10.1038/s41591-019-0673-2 | Lehallier et al. 2019, Plasma-proteome aging waves, *Nat Med* | session-verified |
| 38057571 | 10.1038/s41586-023-06802-1 | Oh et al. 2023, Organ-aging plasma signatures, *Nature* | session-verified |
| 39143318 | — | Shen/Snyder 2024, aging transitions ~44 & ~60 yr | `[NEEDS-VERIFICATION]` |
| 12032295 | — | Maddelein et al. 2002, HET-s infectious amyloid | `[NEEDS-VERIFICATION]` |
| 11733532 | — | Dos Reis et al. 2002, HET-s | `[NEEDS-VERIFICATION]` |
| 8953038 | — | Telling et al. 1996, Prion strain conformation | `[NEEDS-VERIFICATION]` |
| 15029196 | — | Legname et al. 2004, Prion strains | `[NEEDS-VERIFICATION]` |
| 24035542 | 10.1016/j.cub.2013.07.084 | Coelho/Tournier 2013, *S. pombe* stress aging, *Curr Biol* | session-verified; phrasing: cite as stress-induced aging, not generic aggregate-inheritance |
| 35072002 | 10.1016/j.isci.2021.103664 | Cómitre-Mariano et al. 2021, Microchimerism, *iScience* | session-verified |
| 21912617 | — | Gammill et al. 2011, Microchimerism | `[NEEDS-VERIFICATION]` |
| 31001268 | 10.3389/fimmu.2019.00659 | Hahn et al. 2019, Feto-maternal microchimerism, *Front Immunol* | session-verified; "grandmother's cells" exact-claim `[VERIFY-ATTRIBUTION]` |
| 27102489 | 10.1126/science.aaf1098 | Netea et al. 2016, Trained immunity, *Science* | session-verified |
| 30425324 | 10.1038/s41580-018-0074-2 | Skvortsova et al. 2018, Epigenetic inheritance, *Nat Rev Mol Cell Biol* | session-verified |
| 31374565 | 10.1093/humupd/dmz017 | Xavier et al. 2019, Transgenerational inheritance, *Hum Reprod Update* | session-verified |
| 34654604 | — | Sala & Morimoto 2022, Oocyte proteostasis review | session-verified |
| 38902423 | — | Harasimov et al. 2024, Mammalian oocyte protein longevity | session-verified |
| 28994181 | — | Duncan et al. 2017, Oocyte protein metabolism with age | session-verified |
| 38870523 | — | Galatidou et al. 2024, Human AMA oocyte proteostasis | session-verified |
| 34480923 | — | Emenecker et al. 2021, metapredict, *Biophys J* | session-verified |
| 34048569 | — | IUPred-3 | session-verified |
| 41249866 | — | DisProt 2024 | session-verified |
| 27354349 | 10.1093/hmg/ddw207 | Komar 2016, Codon yin-yang, *Hum Mol Genet* | session-verified |
| 28903058 | — | Wills & Carter 2017, Peptide-first | session-verified |
| 9039911 | — | Wilmut et al. 1997, Dolly / SCNT | session-verified |
| 12828414 | — | Cervera & García-Ximénez 2003, SCNT | session-verified |
| 17105381 | — | de Grey SENS canonical (verify which of 17105381 / 20630854 / 23037635) | `[NEEDS-VERIFICATION]` |
| — | 10.1073/pnas.1620179114 | Guseva, Zuckermann & Dill 2017, Peptide-first | session-verified |
| — | 10.1038/nature13287 | Yamada et al. 2014, SCNT/cloning efficiency | session-verified |

*Additional references needed for SD-A1 verification (no confirmed PMID yet assigned in seeds):*
- Aguilaniu et al. (yeast asymmetric aggregate retention) `[NEEDS-VERIFICATION exact ref]`
- Erjavec et al. (yeast rejuvenation/Hsp104) `[NEEDS-VERIFICATION exact ref]`
- Savas 2012 / Toyama 2018 / Fornasiero 2018 (long-lived proteins) `[NEEDS-VERIFICATION exact refs]`
- Daskalov 2014; Eufemio 2026; Schwidetzky 2023 (prion-like LCD cores) `[NEEDS-VERIFICATION exact PMIDs]`
- Fetal oogenesis developmental reference `[NEEDS-VERIFICATION]`
- Maternal mitochondrial inheritance primary ref `[NEEDS-VERIFICATION]`

---

*Draft ends. Word count target for submission: ~6,000–8,000 words (excluding references). This rough draft is approximately 4,500 words of manuscript text; human expansion of the Theory and Discussion sections is expected.*

*Seeds consumed in this draft:* SD-CORE-THESIS, TWO-DOGMAS, PRION-CHANNEL, PRION-LIKE-LCD, YEAST-ASYM-AGGREGATE, YEAST-PRION-INHERITANCE, FRAG-INHERIT, IMM-INHERIT, MITO-MATERNAL, FETAL-OOGENESIS, FERTILIZATION, AGING-WAVES, MICROCHIMERISM, MATERNAL-GRANDMOTHER-MICROCHIMERISM, FRAGMENTUM-V1, CLAIM-CEILING, PEPTIDE-FIRST-WORLD-PRECEDENT, ANALOG-DIGITAL-BOUNDARY, TWO-DOGMAS, CODON-YIN-YANG, SCORING-GAP, ORDER-DISORDER-EDGE, MHC-BROADCAST-CANONICAL, AGING-HALLMARKS-IMMUNE-AGING, SENESCENCE-SASP, OOCYTE-PROTEOSTASIS, TRAINED-IMMUNITY, SD-IMMUNE-INTEGRATED-SYNTHESIS, SD-JOINT-MEASUREMENT-GAP, DISORDER-READOUT, DISORDER-CLOUD-FRAMING, XENODISORDER-FOLLOWUP, SUBSTRATA-FRAGMENTUM-PLAN, BIOCIRCUIT-SHAPE-PLAN, PREDICTOR-BLINDNESS, TOOL-METAPREDICT, TOOL-IUPRED3, DB-DISPROT, DB-DARKPROTEOME, FRONTISPIECE-CLAIM-LABELS, GA-01 through GA-13.
