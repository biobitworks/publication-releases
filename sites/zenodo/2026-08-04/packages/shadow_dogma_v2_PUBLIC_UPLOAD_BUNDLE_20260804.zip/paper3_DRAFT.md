# Local-first governed computational biology under hardware, licensing, and expertise constraints

**ROUGH DRAFT — Paper 3 (Flagship Methods/Experience/Boundary Paper)**
**Status: human-readable rough draft for operator review. NOT final; NOT submitted; claim ceilings enforced throughout.**
**Date assembled: 2026-06-12. Source artifacts: session planning documents, 2026-06-12.**
**All arXiv/PMID citations marked [VERIFY] — spot-check before any submission.**

---

## Abstract

Large language models are increasingly used to assist computational biology, but their limitations are especially acute in this domain: hallucinated citations and facts, silent model drift that breaks reproducibility, disclosure risk for patent-sensitive or clinical payloads, and cost structures that concentrate capability where compute budgets are largest. We report an open-source-first, local-first, no-egress methodology for AI-assisted computational biology designed to run on a used commodity laptop without internet access and without metered API dependence, and we demonstrate it on a contested aging-hypothesis case study. The workflow separates human judgment from AI implementation: the human supplies hypotheses, claim ceilings, governance design, and scientific interpretation; AI agents propose and implement work inside bounded lanes and resource ceilings. Trust is established by governance rather than by model authority — through preregistration and claim-ceiling enforcement (gsigmad), anti-fabrication review and the rule that AI cannot mint substrate data, identifiers, hashes, or scores (Antigence), content-addressed custody (SeedGraph), local bounded execution and receipt production (Ollarma), dashboard projection for git state and blocked gates (Watchtower), and durable truth/promotion gates (Overwatch). A four-gate separation isolates execution, claim promotion, database writeback, and public release. Storage pressure from combinatorial fragment enumeration is managed through Parquet, partition-derived columns, hash manifests, and lazy scan patterns rather than materializing every row. The case study shows the method's intended behavior: it preserved negative results, reported modest benchmark performance without inflation, caught a propagated accession-labeling error, and blocked an AI-suggested fix that would have corrupted a correct record. The contribution is not a new governance primitive, a new scientific framework, or a validated biology claim. It is an auditable, minimal-resource operating model for using AI under known limitations — on hardware accessible to investigators without cloud budgets, engineering staff, or institutional compute — while keeping creative design and interpretation human-led. We report this as a methods-and-experience paper with honest negative results, positioned explicitly against prior art at every layer.

---

## 1. Introduction

### 1.1 The compute divide

AI-assisted science is concentrating where compute is affordable. The trajectory is documented: cutting-edge AI research is moving toward teams with cloud budgets, data-center access, and engineering staff, while academic and low-resource groups are being pushed out of the frontier [arXiv 2010.15581 VERIFY]. The geographic consequence is stark: approximately 32 countries host meaningful AI data-center infrastructure; Africa and Latin America together account for roughly 3 percent of global AI compute (Brookings, WEF; [VERIFY current estimates]). The critique of "AI colonialism" is not rhetorical — the Global South disproportionately supplies training data and annotation labor but cannot build or govern the tools that consume it.

The recognized strategic response from low-resource regions and institutions is to build applied AI on small, efficient, purpose-built models on lower compute. This paper is a worked instance of that strategy applied to computational biology: a governed, reproducible methodology that runs on a used consumer laptop, offline, operated by a domain expert who does not write software.

The hardware floor we describe is a used M1-era MacBook Pro, at an operator-estimated market price of approximately $800 in the United States used market [operator-supplied benchmark; global transfer depends on local device markets, import costs, power access, and data availability — not asserted as universally affordable]. The recurring AI-assistance ceiling is Free / approximately $20 / approximately $200 per month, with no metered API spend and no add-on credit purchases beyond that ceiling. We report what each tier makes possible. The main thing money buys at this scale is implementation convenience for a non-programmer — the AI-implements-for-the-domain-expert loop. The scientific substrate remains local code, local data, local hashes, and governed replay at every tier.

### 1.2 Documented limitations of AI in biology that this workflow answers

The six limitations this methodology responds to are documented in the literature; we cite them as motivation, not invention:

**Hallucination is persistent and innate.** LLMs confabulate citations, numerical values, gene names, and mechanistic claims. Xu et al. argue that hallucination is an inevitable consequence of LLM architecture, not a correctable bug [arXiv 2401.11817 VERIFY]. In biomedical settings the risk compounds: hallucinated clinical or biological claims can propagate into downstream decisions [adversarial hallucination in clinical decision support, PMC12318031 VERIFY].

**Cloud models drift silently.** Frontier models are updated without versioning guarantees. A result computed via a cloud API today may not reproduce tomorrow, because the model weights and prompt-handling have changed. Freezing local model weights, recording seeds and versions, and pairing execution with content-addressed output manifests is the only reliable defense against this class of non-reproducibility.

**Cloud disclosure creates IP and privacy exposure.** Sending patent-sensitive biological sequences, candidate molecules, or proprietary proteome data to a hosted API discloses them. For patent-first research programs — where prior disclosure can defeat a filing — and for medical research with privacy obligations, no-egress is not a preference; it is a hard requirement. This paper demonstrates a workflow where nothing leaves the device during execution.

**API spend is inaccessible or irreproducible for solo investigators.** Pay-per-token pricing means that a study's computational cost scales with model calls, not with scientific scope. A non-engineer who cannot optimize prompts for token efficiency can exhaust a budget quickly without producing proportional scientific value. Our ceiling is a fixed subscription cost (or zero); there is no token burn.

**Many investigators cannot assume cloud budgets, engineering staff, or always-on connectivity.** This is not a niche constraint. It describes the situation of most wet-lab scientists, domain experts in low-resource settings, and independent investigators globally.

**Agentic AI systems blur execution, interpretation, and promotion.** When an AI agent can propose a hypothesis, run code, interpret the output, and draft a conclusion in a single loop, the boundaries between implemented step and scientific claim dissolve. The Sakana AI Scientist [arXiv 2408.06292 VERIFY] and its successors demonstrate that end-to-end AI science is technically feasible; our point is the opposite: that a domain expert must retain those boundaries, and a governance architecture can enforce them.

### 1.3 What this paper is and is not

This paper is a methods and experience report. It is not a novel governance framework — the governance/provenance structure has direct prior art at every layer, as we document in Section 6. It is not a validated biology paper — the Shadow Dogma case study remains at hypothesis ceiling throughout. It is not a claim that we invented accessible science. The contribution is a concrete, reproducible demonstration that a full governed computational-biology stack — preregistration, claim ceilings, provenance and custody, anti-fabrication review, negative-result preservation, self-error-catching — runs on a commodity used laptop, offline, operated by a non-engineer, and that the guardrails are strong enough to catch both data errors and AI-suggested bad fixes before they become claims.

The paper's central finding is a negative: limited hardware drove novel-seeming solutions that did not work out, on methodology that is itself limited. The value is that we know this, because the governance told us.

---

## 2. Prior art and positioning

This section states the prior art explicitly, before any claim, because the methodology's whole point is not to overclaim.

### 2.1 Governed AI-assisted science

The Sakana AI Scientist (v1 and v2; [arXiv 2408.06292 VERIFY]; Nature-published peer-reviewed workshop proceedings) demonstrated an end-to-end AI scientist lifecycle — idea generation, code, experiment execution, analysis, manuscript writing, and review. SafeScientist ([arXiv 2505.23559 VERIFY]) introduced a risk-aware AI-science framework with prompt monitoring, agent-collaboration monitoring, tool-use monitoring, and an ethical reviewer component. AISAC ([arXiv 2511.14043 VERIFY]) is the closest integrated comparator: a role-governed multi-agent scientific-assistance runtime with explicit role semantics, budgeted orchestration, traceable execution, governed retrieval, schema validation, persistent memory, and scientific workflow deployments, submitted November 2025. Our posture is the opposite of autonomous AI science — not "AI does the science" but "AI implements, human governs" — and the differentiator is deployment: all prior integrated comparators are cloud-frontier-dependent, whereas this workflow runs entirely offline on a single consumer device. We did not find a published governed, provenance-tracked, claim-ceilinged, non-programmer computational-biology pipeline that runs entirely offline on a single consumer device; this is the least-covered claim in this audit, and we offer it as a contribution, not a novelty assertion.

### 2.2 Provenance and custody standards

W3C PROV (2013), RO-Crate (2019), Workflow Run RO-Crate (2024) [PLOS One 10.1371/journal.pone.0309210 VERIFY], and the Common Provenance Model are the standards for scientific computational workflow provenance. C2PA (Content Credentials, 2021) established the tamper-evident chain of custody as explicitly not DRM — provenance records who created something and how, rather than restricting use. All SeedGraph/Overwatch custody design follows these standards; no custody innovation is claimed.

### 2.3 Anti-fabrication guardrails and human-in-the-loop oversight

Guardrails AI provenance validators, grounding patterns, schema-lock tool use, and anti-fabrication directives are published guardrail patterns (2023–2024). The "AI cannot mint substrate data, identifiers, hashes, or scores" rule is an application of these patterns to a science pipeline, not an invention of them. Neurosymbolic guardrails that intercept tool calls before execution to enforce symbolic rules are direct prior art. The human-in-the-loop override literature, including override-rate metrics, tamper-evident review records, and multi-agent debate/code-critique loops, is established ([DEBATECODER VERIFY]; [arXiv 2606.05391 VERIFY]).

### 2.4 Local LLM inference

Ollama, MLX, and llama.cpp are mature frameworks for local LLM inference on Apple Silicon and commodity hardware. The reproducibility challenge for local inference — where even greedy decoding is not guaranteed bit-exact across hardware due to floating-point precision variation — is documented in the active determinism literature [Thinking Machines "Defeating Nondeterminism in LLM Inference" VERIFY; LLM-42 arXiv 2601.17768 VERIFY; "Numerical Sources of Nondeterminism in LLM Inference" arXiv 2506.09501 VERIFY]. Our "deterministic" claim means bounded, replayable, receipted local execution, not guaranteed bit-exact output across all hardware and runs.

### 2.5 Fragment-based disorder and aggregation prediction

The fragment-plus-disorder approach to aggregation triage is established science, not our invention. Aggregation and amyloid predictors including TANGO, WALTZ (and WALTZ-DB 2.0), PASTA 2.0, AGGRESCAN/AGGRESCAN3D, ZipperDB, FoldAmyloid, AmylPred2, and Cross-Beta RF have been active since approximately 2004–2014. PACT (Prediction of Amyloid Cross-interaction by Threading [bioRxiv 2022.07.07.499150 VERIFY]) is the closest specific comparator for cross-seeding prediction. Chia et al., Nature Communications 2022 [PMC8924238 VERIFY] showed that APR sequence homology enriches cross-interaction candidates but that the validated method required FoldX structural scoring — sequence alone is a filter, not a conclusion. We use fragment/disorder/visual-math features as a triage layer, which is less, not more, than these validated predictors. We cite them as the baseline we are working inside.

### 2.6 Storage engineering

Apache Parquet, content-addressable storage (Git object store, IPFS), Delta Lake, DVC, and bioinformatics k-mer compression (succinct de Bruijn graphs, BOSS, USTAR, Bloom Filter Trie, minimizers, MinHash/Mash, KMC, Jellyfish) are the prior art for the storage-reduction design. The substrate engineering result — approximately 18.7x reduction from a four-layer materialized design to a MINIMAL_NORMALIZED partition-derived schema — is a measured engineering outcome, not a novel data structure.

---

## 3. Method

### 3.1 The three-constraints-to-one-method chain

Three hard constraints defined the methodology:

**No advanced GPU cluster.** CUDA-first pipelines (AlphaFold 3, most SOTA protein ML workflows, large molecular dynamics) are inaccessible. Apple Metal/MPS acceleration is available for fragment scans and visual-math operations on the floor MacBook, but it is not AlphaFold-class structural inference.

**No raw-payload egress.** Patent-sensitive sequences, candidate rankings, and private proteome data cannot be sent to a hosted API or cloud service. Everything that touches private scientific content must run on local hardware.

**No commercial or IP exposure through hosted structure tools.** Certain structure-prediction services carry commercial-use restrictions or require institutional agreements. The workflow must use tools whose licenses permit the intended use without institutional overhead.

These three constraints together ruled out structure-first cross-seeding simulation. The alternative — the method of this paper — is a fragment / disorder / visual-math surrogate layer. The abstraction chain is:

```
sequence
  → all fragments (Fragmentum; positional enumeration)
  → per-residue disorder probability and fragment-level disorder statistics
    (metapredict local; IUPred license-gated)
  → fragment property vectors
    (charge, hydropathy, aromaticity, low-complexity, PTM/ncAA flags)
  → pairwise and cross-fragment geometry
  → visual-math objects: heatmaps, 2D disorder curves, 3D property clouds
  → candidate signal regions
  → governed follow-up (scored against nulls, claim-audited before promotion)
```

This is a **triage layer**, not a substitute for structural prediction, molecular dynamics, or experimental seeding assays. APR overlap is necessary but not sufficient for cross-seeding. Non-canonical amino acids (ncAA) are out-of-distribution for every existing predictor — their physical scales are defined for 20 canonical amino acids — and any ncAA result must be flagged as extrapolation with unknown error bounds.

Metal/MPS GPU acceleration enters as **signal scanning** (fragment property computation and visual-math operations at interactive speed) and not as AlphaFold replacement. The paper-safe claim is that Metal-capable Apple hardware supports local fragment/disorder visual-math signal discovery, but not AlphaFold-class structural inference.

### 3.2 The folding ladder

Rather than "fold everything," the workflow builds a pre-folding triage layer and escalates only when a local surrogate identifies a region as worth the additional cost:

1. **Known backbone (PDB/RCSB):** download experimental structures via programmatic file access; use as fixed reference geometry; map fragments onto residue positions. This is the most information-dense tier and costs only bandwidth and storage.

2. **Template or homolog:** if the exact protein is absent, use a close homolog or domain; all template-derived coordinates are marked `template-derived`, not solved.

3. **Open local prediction where feasible:** ColabFold, OpenFold, ESMFold — if license, hardware, and sequence type allow. On a MacBook this tier is constrained: these tools are GPU- and CUDA-oriented; the ESM repository is archived/read-only and is a useful reference rather than an active fresh dependency.

4. **Disorder cloud / fragment surrogate:** when folding is infeasible — per-residue disorder, fragment disorder mean, disorder spread, flank shifts, charge/hydropathy/aromaticity/low-complexity, cross-fragment similarity, heatmaps, 3D clouds. This tier estimates where interaction liability or cross-seeding plausibility concentrates without claiming folded structure. Paper-safe claim: *for proteins and fragments that cannot be practically folded under local, private, commercially-cautious constraints, disorder-cloud and fragment-property representations are a local surrogate for structural triage. They do not replace folding; they identify where higher-cost structural modeling or experimental follow-up is most justified.*

### 3.3 The scaffold: repo network as bounded stages

The methodology is not a single pipeline. It is a network of sibling repositories, each providing one capability layer for a specific missing expertise:

| Repository | Capability layer | Missing expertise it compensates for |
|---|---|---|
| gsigmad / Getting Science Done | Preregistration, claim-ceiling enforcement, EXP/PROMPT contracts, four-gate separation, negative-result preservation | No software-engineering process discipline |
| Antigence | Anti-fabrication review; the rule that AI cannot mint substrate data, identifiers, hashes, scores, citations, or conclusions | Model hallucination risk |
| Watchtower | Operator cockpit: git/repo state, blocked gates, next steps, bridge health — projection only, never a second source of truth | Not terminal-native; no visibility into pipeline state |
| Overwatch KG | Durable truth and promotion owner; prevents dashboards or runtime outputs from becoming canonical truth | No governance or provenance owner |
| SeedGraph KG | Content identity, source seeds, knowledge atoms, publication atoms after governed ingest | No data-custody discipline |
| Substrata / Fragmentum | Compact, score-free fragment substrate in Parquet; approximately 18.7x storage reduction; DuckDB 2 GB query RAM limit; approximately 305 GiB on external SSD | Large-data pressure; no DBA; no cloud storage |
| Fractal Waves | Biology-agnostic re-implementation as a representation-level bias-control axis; visual-math heatmaps, clouds, and audits | No GPU; no structural bioinformatics |
| XenoDisorder | Biological readout for modified-residue disorder; CAID/DisProt-benchmarked where applicable; ncAA out-of-distribution flagged | No bioinformatician; no statistician |

Importantly: the scaffold compensates for these missing expertise gaps only partially. gsigmad forces preregistration, which is a partial compensation for statistical discipline — it does not supply domain judgment. Antigence catches fabrication — it does not supply biological expertise. The framework lowers the floor and adds guardrails; it does not replace the expert.

### 3.4 The run-until-blocked harness and typed block receipts

The empirical core of the methodology is a modular "run-until-blocked" workflow design. Each module in the chain runs until it hits a governance, data, hardware, license, or claim block. **The block is a result, not a failure.** When the workflow hits a block, it emits a structured block receipt:

```json
{
  "stage": "fragmentum",
  "status": "BLOCKED",
  "block_type": "RESOURCE_LIMIT",
  "reason": "all-vs-all fragment comparison exceeds MacBook RAM",
  "input_hash": "[hash]",
  "last_valid_artifact": "[artifact id]",
  "next_options": [
    "partition by tissue",
    "approximate nearest neighbors",
    "reduce fragment length range",
    "move to Mac Studio tier"
  ],
  "claim_ceiling": "no biological claim; infrastructure limit only"
}
```

Block-type taxonomy: `GOVERNANCE_FIREWALL` · `DATA_CUSTODY` · `LICENSE` · `BENCHMARK` · `RESOURCE_LIMIT` · `NULL_FAIL` · `CLAIM_CEILING` · `HALLUCINATION` · `OVERCLAIM` · `GOVERNANCE` · `PRESENTATION_OVERCLAIM` · `TRANSLATION_GATE`.

The module chain runs through nine capability stages preceded by a hard lane firewall (Stage 0): SeedGraph/Overwatch source resolution → XenoDisorder disorder prediction → Substrata/Fragmentum fragment enumeration → Fractal Waves visual-math → Cellico/MATER hypothesis mapping → Antigence claim audit → gsigmad governance receipt → Watchtower state surface → Conductor/tf-cellico wet-lab translation.

Stage 0 is a governance firewall. This project's Shadow Dogma aging lane must never touch the sids-proteome-validation SIDS/SUDC cohort, its identities, or its data paths. The first thing the harness does is confirm it is operating in the Shadow Dogma lane on public non-SIDS data. If any SIDS/SUDC identity is detected, it emits a `GOVERNANCE_FIREWALL` block and stops. That the harness's first job is to refuse to conflate the two lanes is, appropriately, the most concrete demonstration of the governance design.

The block map produced by running this harness tells a constrained researcher exactly what is missing — compute, license, data, custody, or claim support — before spending money or disclosing payloads. A clean smoke run that ends in several honest blocks is a pass for the scaffold demonstration even if the surrogate-signal hypothesis is demoted.

### 3.5 Resource tiers and what each one buys

The methodology was designed to operate across three resource tiers, with no metered API spend at any tier:

**Free ($0):** Local compute on commodity hardware; open-source tools; cached open data from UniProt, DisProt, CAID portal, PDB, PubMed/Europe PMC/OpenAlex/arXiv/bioRxiv; local Ollama/MLX/llama.cpp models for offline inference; the full governance and provenance layer (gsigmad, SeedGraph, Antigence, Ollarma, Watchtower, Overwatch) as local code. The entire scientific substrate — scoring stack, fragment enumeration, disorder prediction, custody and hashing, replay — is local code running for free. This tier produces a complete reproducible study; it takes longer and requires more manual iteration.

**Approximately $20/month:** One premium subscription for AI-assisted coding, planning, debugging, code review, claim linting, and manuscript drafting from redacted excerpts. No private payload upload. No claim authority for the AI. This unlocks a fluid "AI-implements-for-the-non-SWE" loop and makes approximately 90 percent of what this project accomplished accessible at interactive speed.

**Approximately $200/month:** Higher AI-assistance caps for deep synthesis, longer adversarial review, parallel agentic sweeps. Same scientific substrate, same no-egress policy. This buys throughput and parallelism, not scientific capability.

**Above approximately $200/month:** Outside the operator ceiling by explicit policy. A new operator decision is required to exceed this.

The binding constraint at every tier is not AI spend. It is the fragment substrate — storage, IO, CPU time, and wall-clock — managed through the Parquet/partition/manifest/DuckDB design described above.

### 3.6 Hardware tiers

The methodology was tested against four hardware configurations. None is offered as "frontier equivalent"; the correct frame is frontier-demand reduction:

**Used M1-era MacBook Pro (~$800 operator estimate, US used market):** The accessibility floor. Runs governance scripts, small local models (7B at 4-bit quantization, slowly), Parquet fragment scans via DuckDB at 2 GB RAM limit, Watchtower dashboard, notebooks, and bounded review. Substrate lives on an external SSD (~305 GiB projected; magicDATAbox ~1.3 TiB or magicBLACKbox ~3.7 TiB). [MEASURE: exact model/chip/storage/OS/benchmark receipts before citation.]

**Used M1 Mac Studio / 32 GB unified memory / ~400 GB/s memory bandwidth (~$1,400 operator purchase):** Memory bandwidth is the key spec for Apple Silicon local inference. At this tier, interactive 7B–32B model operation becomes practical via MLX (Qwen2.5-Coder-32B or R1-Distill-32B at 4-bit quantization is the approximate sweet spot; 70B models do not fit 32 GB). [VERIFY: exact model/chip, receipt/date, storage, OS, measured bandwidth source, power draw, and benchmark receipts before citation.]

**Old-parts local rig + AMD Radeon AI PRO R9700 / 32 GB VRAM (~$1,300 GPU-cost target):** GPU-resident inference for models up to approximately 30B at Q5/Q6. ROCm and AMD maturity is a caveat — llama.cpp Vulkan/ROCm works, but is less plug-and-play than CUDA. [VERIFY: exact AIB model, purchase price/date, host build, power/RAM/storage, ROCm/Ollama compatibility, and benchmark receipts before citation.]

**96 GB RAM + dual-Xeon used workstation (~$2,500 operator market estimate):** Large-memory box suited for the fragment substrate (DuckDB on 305 GiB Parquet), concurrent services, and slow large-model inference (70B+ Q8 fits in RAM; throughput is single-digit tokens/second, appropriate for overnight batch rather than interactive work). [VERIFY: exact CPU models, RAM type, GPU/storage, price/date, power draw, and benchmark receipts before citation.]

The routing principle: deterministic, auditable, high-volume, payload-sensitive tasks stay local; rare, high-leverage, broad-synthesis tasks that stall the local loop escalate to frontier, metered as a scarce resource.

### 3.7 Human step-in model

The intended division of labor has three lanes:

**Human-led (irreducible):** creative design, hypothesis framing, biological interpretation, claim ceilings, novelty posture, release decisions, and repair decisions when gates flag.

**Pipeline-led (automated):** scripted execution, hashing, manifests, notebook generation, benchmarking, null runs, replay, and receipt production.

**AI-assisted (bounded):** drafting, implementation, code generation, code review, summarization, red-team review, surfacing contradictions, and claim linting.

Watchtower mediates the human step-in: it projects git state, repo status, blocked gates, bridge health, and next-step lists so the operator knows when to intervene without reading raw pipeline output. Jupyter notebook surfaces present experiments for design and interpretation, not for execution babysitting.

Antigence / immunOS supplied the original design premise: a USB-deployable, offline, private-first verification layer that could train on local "self" data and run without cloud telemetry. The intent was a system that could run from a USB drive on an air-gapped machine in a medical research or IP-sensitive context.

---

## 4. Live exhibits: the governance working

The strongest evidence for the methodology is not its design but four instances of the governance catching problems the biology alone would not have revealed.

### 4.1 Caught a real data error: the NANOG accession

A benchmark row labeled "NANOG" carried accession P21952, which is a bovine protein — not the human NANOG the label implied. The custody trace located the origin of the error upstream and showed it had propagated across three artifacts without being flagged. The governance layer identified the discrepancy because it tracks source accessions, not just protein names, and because it requires a verifiable provenance chain before a value enters a benchmark. No human reviewing only the output table would have noticed.

### 4.2 Caught the AI's own bad fix: the PRNP record

A subagent proposed a fix to what it characterized as an erroneous record. The look-at-the-target and custody audit showed that the record it wanted to fix — the PRNP entry — was correct. The AI had identified the wrong record as the problem, and its proposed fix would have corrupted the correct record while leaving the actual error (the NANOG row) intact. The governance-mediated review overrode the AI. This is the clearest exhibit in the paper: the workflow is designed so that the AI's proposed changes are audited, not automatically applied.

### 4.3 Preserved a null: cross-seeding signal null-consistent

The fragment cross-seeding analysis (EXP-019/EXP-228) returned null-consistent results — the positive panel did not separate from composition-matched scrambles and nulls. The scorer was found to be degenerate (EXP-225, effective rank approximately 3.7 out of 11), meaning the features were not contributing independently. These results were preserved as first-class negatives in the experiment registry. They were not omitted, reframed, or replaced with a new analysis after the fact.

### 4.3a Blocked before signal: EXP-011 Ding aging-wave source contract

EXP-011 ("Hardware-Constrained Visual-Math Surrogate for Fragment Cross-Seeding") adds a second, distinct outcome: the Ding aging-wave benchmark did not fail statistically, because it was not allowed to run. A Stage-0 source preflight found that Cellico-bio EXP089 provides read-only source-family custody and a redacted deterministic replay pass for Ding 2025, but Shadow Seeds does not yet have a processed age/tissue metric table, primary endpoint bundle, matched null bundle, or hardware ladder receipt. The correct status is therefore `BLOCKED_SOURCE_CONTRACT_REQUIRED`, not "surrogate signal failed." This distinction is central to the governance claim: source custody is not executable benchmark evidence, and a block before signal is a valid result.

### 4.4 Honest number reported: disorder accuracy approximately 0.68

The disorder predictor, benchmarked against CAID/DisProt ground truth, scored approximately 0.68. This is a competitive result relative to baselines for this predictor type. It was reported as approximately 0.68, not inflated. The disorder cloud representation was positioned explicitly as a low-resource interpretability and triage layer — below bAIes, AlphaFold-Metainference, AFflecto, and DISPROTBENCH [arXiv 2507.02883 VERIFY] in the hierarchy of IDP ensemble methods — not as a competitor to them.

### 4.5 Caught a fabricated parameter: the 11D-to-5D scorer

An earlier draft claimed the scorer reduced dimensionality from 11 to 5. This was fabricated — it did not correspond to any implementation artifact. The real scorer used 8 property axes with 4 certified in v2.0 (length, composition, hydropathy, rgg_qn_density; disorder, tissue, abundance, and PTM reserved but unpopulated). The fabricated claim was caught by the governance process — the framework catching its own writeup, exactly as designed.

### 4.6 Antigence honestly described as a stub

The Watchtower dashboard integrates Overwatch, Ollarma, and SeedGraph live. Antigence is a declared-but-stubbed review lane — `review_gated` is a static flag, not a running service. The paper claims what is wired, not what is declared. This distinction matters because a reader relying on "Antigence review" as a live gate would be misled by the stub.

---

## 5. The honest negative

The program's truest result, stated directly:

> **Limited hardware drove novel-seeming solutions that did not work out, on methodology that is itself limited. The value is that we know this, because the governance told us.**

The constraint produced a novel-feeling shortcut — the fragment/disorder/visual-math surrogate, the disorder cloud, the residue-to-aging-wave abstraction. These felt new. They are not (all have established neighbors, as Section 2 documents). They also did not yet succeed as positive evidence:

- The cross-seeding signal was null-consistent.
- The scorer was degenerate.
- The disorder number is provisional (~0.68, competitive but not leading).
- The Ding aging-wave slice is blocked before execution until a processed source contract and matched-null bundle exist.
- The peptide redesigns are exploratory and retroactive — invalid as forward evidence.

The reason they did not succeed is partly constraint (limited hardware, limited tools, limited compute) and partly that the methodology is itself limited: every tool in the chain has a known IDR/IDP blind spot.

**Per-tool IDR/IDP limitations (known field problems; we cite them, not claim them):**

- AlphaFold / AF3 predicts one static conformation; IDRs score low confidence; no ensemble; no dynamics; GPU-bound regardless.
- MD/molecular dynamics requires IDR-specific force fields (e.g. a99SB-disp) and long timescales for IDR ensembles; out of scope on floor hardware.
- Disorder predictors (metapredict, IUPred, flDPnn) produce per-residue point estimates; predictor disagreement is discarded; they are trained on incomplete annotation; ncAA/PTM-blind.
- Aggregation/cross-seeding predictors (TANGO/WALTZ/PASTA/AGGRESCAN/PACT) are canonical-amino-acid only; necessary-not-sufficient; weak on disorder context; trained on amyloid cores, not IDR dynamics.
- CAID/DisProt ground truth collapses the ensemble into binary/consensus labels; coverage and curation lag; condition-dependence is not captured.
- Property scales (hydropathy, charge, aromaticity) are defined for 20 canonical amino acids; ncAA/PTM extrapolation carries unknown error.
- Internal scorers (MATER/cellico): degenerate; cross-seeding null-consistent.

The shared blind spot across every tool: IDR/IDP behavior is dynamic, context-dependent, modified-residue-sensitive, and ensemble-like. Every tool we used treats it as either a structure to predict (wrong frame), a point estimate (collapses the ensemble), or an annotation lookup (incomplete). The surrogate works within this gap; it does not close it. The disorder cloud is positioned below bAIes/Metainference/AFflecto — not as a competitor.

What this is: a negative-result and boundary/experience contribution; a catalog of where low-resource IDR/IDP work blocks; a demonstration that governance converts "didn't work" into a recorded, honest result rather than a false positive.

What this is not: evidence the surrogate works, a solution to the IDR/IDP ensemble problem, a positive method claim, or evidence for Shadow Dogma biology.

---

## 6. Honest novelty position

This section states the novelty assessment explicitly. The same discipline we applied to the biology — requiring verifiable evidence before a claim lands — applies to the methodology.

**The governance/provenance structure is not novel.** Every layer has direct prior art predating the project (AISAC November 2025; SafeScientist May 2025; Sakana AI Scientist August 2024; W3C PROV 2013; Apache Parquet 2013; OSF preregistration ~2012; GRADE 2008; Merkle trees 1979/1987). The integration architecture is also not clean novelty: AISAC, SafeScientist, and the "Verifiable Science Architecture" pattern combine governance, provenance, bounded execution, and human oversight into integrated AI-science runtimes. Our configuration is project-specific, but "new configuration" is not the same as "novel."

Under KSR v. Teleflex [VERIFY citation], the combination of known elements by known methods yielding predictable results is obvious. The escape — no recognized reason to combine — is weak here because the field has a recognized reason and multiple parties have already combined these ideas independently.

**What survives (the honest contribution):**

1. A specific integrated instantiation of known layers, wired together as a named stack and stress-tested in a real computational-biology case study. The value is "it composes and was stress-tested," not general integration novelty.

2. A worked, reproducible, honest case study on contested biology — including two concrete self-caught-error exhibits (NANOG accession propagation; PRNP bad-fix override) and first-class preserved negatives. This is a good demonstration and experience report. It is publishable and useful. It is "useful," not "novel."

3. The specific deployment constraint: offline, single-consumer-device, non-programmer operator. We did not find this exact construction — governed, provenance-tracked, claim-ceilinged, non-programmer, computational-biology, entirely offline, single-device — published. This is the strongest publication wedge, and we offer it as a contribution to the accessibility literature, not a novelty claim over the components.

4. A synthesis of how these known techniques apply to the resource-tier problem: Free / $20 / $200 / ceiling — what each tier makes possible and where the ceiling is.

**What this paper explicitly does NOT claim:**
- First, novel, or inventive governance mechanism.
- Novel integration.
- Frontier-model equivalence on local hardware.
- Solution to the IDR/IDP biology problem.
- Clinical, therapeutic, or diagnostic evidence.
- Patent-protectable contribution (the paper covers methodology and experience; patent-first items remain private pending counsel and prior-art search).
- Globally affordable (depends on local markets, power, and infrastructure).

---

## 7. Boundary table

| Lane | Access model | What it enables | What it cannot do |
|---|---|---|---|
| **Constrained MacBook (floor, ~$800)** | Local CPU/Metal; open-source; cached open data; Free/$20/$200 subscription | Fragment/disorder surrogate; visual-math scans; local notebooks; small LLM/RAG; full governance layer; IP-safe no-egress triage | AlphaFold-class folding; docking; MD; CUDA-first throughput; large embedding batches; wet-lab validation |
| **Academic HPC** | Institutional licenses; non-commercial AlphaFold3; clusters; institutional bandwidth | AlphaFold-style workflows; broader literature; larger benchmarks; GPU-resident inference | May not transfer to commercial/IP lane; can require institutional affiliation |
| **Commercial / funded** | Paid databases; cloud GPUs; licensed software; legal review | Structure-first modeling; docking; MD; high-throughput screening | Costly; disclosure/licensing risk; patent-first workflows require additional steps |
| **NVIDIA/CUDA elite** | Modern CUDA GPUs; CUDA-first packages; engineering staff | Most SOTA protein-ML pipelines; frontier model inference | Inaccessible to most regions, solo labs, and patent-sensitive non-disclosure settings |

This table is the boundary paper's spine. The question it answers is: what can a constrained researcher do with a used MacBook, legally and privately, versus well-funded teams with licensed software, paywalled literature, cloud GPUs, CUDA stacks, and institutional compute?

---

## 8. Claim ceiling

This section states what the paper claims and what it does not claim, so a reader can evaluate it without having to infer.

**Methodology claims (what this paper asserts):**
- A specific operating model for AI-assisted computational biology on used commodity hardware, without internet egress, operated by a non-engineer, was designed, implemented, and run.
- The operating model separates execution, claim promotion, database writeback, and public release into four gates.
- The operating model caught real errors (two exhibits: NANOG accession, PRNP bad-fix).
- The operating model preserved negative results (cross-seeding null-consistent; scorer degenerate).
- The operating model reported honest benchmark numbers (~0.68 disorder accuracy) without inflation.
- The storage design achieved approximately 18.7x reduction from a four-layer materialized design to a MINIMAL_NORMALIZED schema.
- The substrate (~305 GiB projected) lives on an external SSD and is queryable via DuckDB at a 2 GB RAM limit on the floor MacBook.
- The methodology operates within the Free/$20/$200/ceiling resource framework with no metered API spend.

**Boundary of biology claims (hypothesis ceiling only):**
- Shadow Dogma remains a hypothesis throughout. No biology claim is promoted by this paper.
- The disorder cloud is a triage layer, not a validated IDP ensemble method.
- Cross-seeding signal was null-consistent; this negative is preserved.
- ncAA-containing sequences are out-of-distribution for all predictors used; any result involving them carries unknown error bounds.

**What this paper does not claim:**
- Novel governance mechanism or novel integration.
- Reproducibility in the bit-exact sense (local inference is receipted and replayable; bit-exact guarantees across hardware are not possible given floating-point nondeterminism).
- Frontier-model equivalence on local hardware.
- Affordable in every region (hardware cost, power access, data connectivity, and import costs vary).
- That the scaffold supplies the missing domain expertise it compensates for.

**Patent-first hold:** items in the narrow IP candidate bucket (specific fragment/disorder visual-math cross-seeding workflow; specific compressed-substrate-plus-custody implementation; specific ncAA/PTM disorder readout if benchmarked) remain private pending prior-art search and counsel. Publishing this paper does not itself disclose those items, which are described here only at the level of architecture and demonstrated result.

---

## 9. Discussion

### 9.1 The repair loop as the contribution

The architecture's most useful property is not that it succeeds. It is that when it fails — when the signal is null, when the scorer is degenerate, when a data error propagates, when the AI suggests a wrong fix — it records the failure, categorizes the block, and surfaces it for human review before the error becomes a claim. For a non-engineer operating alone, this is the safety net that prevents a series of plausible-looking steps from producing a published false positive. The claim is not that the governance makes the biology work; it is that the governance makes the non-result legible and recoverable.

### 9.2 The resource-tier ceiling is hardware and storage, not AI spend

The binding constraint at the floor tier was not API spend or model capability — it was the fragment substrate. Approximately 13.96 billion positional rows at approximately 305 GiB (projected, external SSD) is the data engineering challenge, not the LLM budget. The storage reduction design is what made this substrate tractable on floor hardware, and the k-mer bioinformatics literature (succinct de Bruijn, USTAR, Bloom filter trie, minimizers) is the correct prior-art field to position it against.

### 9.3 The non-engineer accessibility claim requires honest framing

A non-engineer using this workflow still needs the hardware, electricity, and one-time connectivity to provision open models and open datasets. "Minimal" is not "zero." The $800 floor is an operator-supplied benchmark for the US used market; global transfer is not asserted. The claim is a lower recurring cost, open-source-first design with explicit remaining constraints — not a solved global-access problem.

### 9.4 What we did not do that a reader might assume we did

We did not wet-lab validate any candidate. We did not benchmark the full hardware ladder (only the floor MacBook was consistently measured; other tiers are described but receipts are pending [MEASURE]). We did not implement a live Antigence review lane (stubbed). We did not complete a full SeedGraph publication-atom chain (provenance is fail-closed and ready for atomization, not finished custody). We did not claim KSR-nonobvious patentability for the integration.

### 9.5 The paper's relationship to the three-paper program

Paper 1 reports the Shadow Dogma hypothesis; Paper 2 reports the XenoDisorder instrument for modified-residue disorder readout; this paper (Paper 3) is the umbrella methods and experience report. Paper 4 / supplement covers wet-lab translation via Conductor / tf-cellico — the validation lane that compute cannot shortcut.

---

## 10. Conclusion

A domain expert with a used MacBook, no cloud budget, no engineering team, and no willingness to disclose patent-sensitive payloads can run a governed, reproducible computational-biology triage workflow using open-source tools and local AI assistance. The methodology is not novel — it synthesizes documented governance primitives, open-source local inference, content-addressed custody, and preregistration discipline in a specific offline deployment. What makes it useful is not the components but the operating model: that errors are caught before promotion, negatives are recorded rather than omitted, costs are capped at a predictable ceiling, and humans retain creative design and interpretation throughout.

The case study's central result is a negative. The fragment/disorder/visual-math surrogate, driven by hardware constraints into novel-seeming ground, did not produce a triage signal that survived governance. The value is that we know this. Governance that bites is the paper's whole point.

---

## References (incomplete; all [VERIFY] before submission)

1. Sakana AI Scientist v1/v2. arXiv 2408.06292 [VERIFY]. Also: Nature-published workshop proceedings [VERIFY full citation].
2. SafeScientist. arXiv 2505.23559 [VERIFY].
3. AISAC. arXiv 2511.14043 [VERIFY].
4. OmniScientist. arXiv 2511.16931 [VERIFY].
5. "Hallucination is Inevitable." Xu et al. arXiv 2401.11817 [VERIFY].
6. Adversarial hallucination in clinical decision support. PMC12318031 [VERIFY].
7. Compute divide / de-democratization of AI. arXiv 2010.15581 [VERIFY].
8. Workflow Run RO-Crate. PLOS One 10.1371/journal.pone.0309210 [VERIFY].
9. W3C PROV. 2013. [VERIFY canonical URL/citation].
10. C2PA / Content Credentials. 2021. [VERIFY canonical citation, Adobe/BBC/Microsoft/Intel consortium].
11. Fractal Merkle Tree. Jakobsson, Leighton, Micali, Szydlo. CT-RSA 2003 [VERIFY].
12. Ollama (local LLM inference on Apple Silicon). [VERIFY canonical citation/URL].
13. MLX (Apple machine-learning framework). [VERIFY canonical citation/URL].
14. "Defeating Nondeterminism in LLM Inference." Thinking Machines / relevant authors. [VERIFY arXiv/URL].
15. LLM-42 determinism study. arXiv 2601.17768 [VERIFY].
16. "Numerical Sources of Nondeterminism in LLM Inference." arXiv 2506.09501 [VERIFY].
17. PACT (Prediction of Amyloid Cross-interaction by Threading). bioRxiv 2022.07.07.499150 [VERIFY].
18. Chia et al. cross-seeding APR homology. Nature Communications 2022. PMC8924238 [VERIFY].
19. metapredict. PMID 34480923 [VERIFY].
20. DISPROTBENCH. arXiv 2507.02883 [VERIFY].
21. bAIes (AF2 + force-field Bayesian ensembles). [VERIFY full citation].
22. AlphaFold-Metainference. [VERIFY full citation].
23. AFflecto. [VERIFY full citation].
24. Apache Parquet. [VERIFY canonical citation].
25. Antigence (Zenodo preprint). DOI 10.5281/zenodo.18109862 [VERIFY].
26. OSF preregistration. [VERIFY canonical reference].
27. GRADE evidence framework. [VERIFY canonical reference; Guyatt et al., BMJ 2008].
28. Reproducibility: The New Frontier in AI Governance. arXiv 2510.11595 [VERIFY].
29. KSR International Co. v. Teleflex Inc. 550 U.S. 398 (2007). [Legal citation, verify before filing; not a journal reference].
30. Guardrails AI provenance validators. [VERIFY URL/version/citation].
31. Neurosymbolic guardrails intercepting tool calls. [VERIFY primary reference].
32. Multi-agent debate / DEBATECODER. [VERIFY primary reference].

---

**END OF ROUGH DRAFT**

*Claim ceiling reminder: this document is a methods/experience/boundary paper. All biology stays at hypothesis ceiling. Patent-first hold items are not disclosed here. All [VERIFY] citations must be spot-checked against canonical sources before submission. No sequences, no candidate rankings, no private payload.*
