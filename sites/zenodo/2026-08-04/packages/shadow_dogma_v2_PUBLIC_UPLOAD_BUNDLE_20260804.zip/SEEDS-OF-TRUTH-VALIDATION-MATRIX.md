# Seeds Of Truth / Atom Trace Validation Matrix

Date: 2026-06-12T21:39:18Z  
Run: `EXP-011-RUN-20260612T213918Z`  
Status: source-seed validation matrix, not a promoted truth layer  
Claim ceiling: traceability and drafting only.

## Rule

A seed is not a knowledge atom or publication atom unless a custody-bearing artifact exists, such as `publication.atomic.json` or a governed equivalent. If the evidence is strong but not atomized, mark it as `validated_source_seed` or `estimated`. If the evidence is missing, stale, license-gated, or source-gated, mark it `blocked`.

## Current SeedGraph State

- No `publication.atomic.json` or `*.atomic.json` exists inside the current Shadow Seeds checkout.
- Five read-only sibling SeedGraph atomic proofs exist under `/Users/byron/projects/active/seedgraph/.planning/artifacts/*-atomic-2026-05-13/`.
- Those five may support source-custody statements for their own publication packages, but they do not automatically atomize the current Paper 1-3 drafts.
- Live SeedGraph/Overwatch/ProtAtlas/ProTHub writeback was not performed.

## Validation Labels

| Label | Meaning |
|---|---|
| `atomic_proof_available_read_only` | A sibling SeedGraph `publication.atomic.json` exists and was read/hash-checked without mutation. |
| `validated_source_seed` | Citation/local artifact has source identity or verified metadata but no local publication atom for this draft. |
| `estimated` | Plausible from current notes, but requires verification, calibration, or source freeze before manuscript use. |
| `blocked` | Missing proof, open gate, source freeze failure, license issue, or claim-ceiling conflict. |

## Seed Matrix

| Seed | Paper home | Current evidence | Validation label | Allowed use now | Next gate |
|---|---|---|---|---|---|
| Lehallier 2019 plasma aging waves | Paper 1 / Paper 3 background | Read-only SeedGraph atomic proof exists: `/Users/byron/projects/active/seedgraph/.planning/artifacts/lehallier-2019-PMID-31806903-atomic-2026-05-13/publication.atomic.json`, SHA-256 `3ea72760da70f2e612d8b78aa1f43e90e7cf790da3c92aaed5363eb4d41a196d`, verification status `verified` | `atomic_proof_available_read_only` | Structured plasma-proteome aging-wave background; do not overstate exact ages without source text check | Pull claim-specific sentence atoms or cite source manually before camera-ready |
| Oh 2023 organ-aging plasma signatures | Paper 1 / Paper 3 background | Read-only SeedGraph atomic proof exists, SHA-256 `0b039463d09a7cf1123db3a436e9740b48db18c0c4445a8c92b2b115c90034ca` | `atomic_proof_available_read_only` | Organ-aging / plasma-signature background | Claim-specific source audit |
| Fornasiero 2018 long-lived proteins | Paper 1 background | Read-only SeedGraph atomic proof exists, SHA-256 `09711fd456a720d46e5c8e432428375728249a7b3c9e5255900e7fc08d1822ac` | `atomic_proof_available_read_only` | Long-lived protein substrate background | Claim-specific source audit |
| Brodin 2015 immune variation | Paper 1 immune background | Read-only SeedGraph atomic proof exists, SHA-256 `04f31c6d0f33ecd5089f0bd6549c51dc84bba9aab3b6fe486d47a4e3f65efae9` | `atomic_proof_available_read_only` | Immune variation/context background only | Claim-specific source audit |
| Nobs 2026 | Paper 1 / Paper 3 background if used | Read-only SeedGraph atomic proof exists, SHA-256 `495b95d5a5da255235874adb57425c84346bf681e140381933fcdf43c02c63f9` | `atomic_proof_available_read_only` | Background only until mapped to an exact manuscript claim | Decide whether it belongs in Papers 1-3 |
| Ding 2025 source-family custody | Paper 3 benchmark source preflight | Read-only Cellico-bio EXP089 reports `PASS_DING2025_DETERMINISTIC_PLAYTHROUGH_RERUN_SOURCE_BOUND_REDACTED`, source member hash root `c737f018728b362521be3bd3812c1e412e1ed302251ffaffe331b7b2b0ece551`, and `REPLAY_PASS` in repo-safe redacted artifacts | `validated_source_seed` | Source-custody and replay-readiness statement only; no row-level values, identifiers, aging-wave signal, or biological validation | Create Shadow Seeds processed age/tissue metric contract and matched-null benchmark bundle |
| Draft-only atom alias coverage | Papers 1-2 traceability | Full-draft trace audit found draft tags not present in seed registries and added alias rows for AGING-HALLMARKS-IMMUNE-AGING, SENESCENCE-SASP, SD-JOINT-MEASUREMENT-GAP, DISORDER-CLOUD-FRAMING, DISORDER-CLOUD-CLAIM, IDR-IDP-GAP-AND-HONEST-NEGATIVE, CELLICO-BIO-KEY-POINTS-INTEGRATION, XENODISORDER-FOLLOWUP, SUBSTRATA-FRAGMENTUM-PLAN, BIOCIRCUIT-SHAPE-PLAN, MATERNAL-GRANDMOTHER-MICROCHIMERISM, and TRAINED-IMMUNITY | `estimated` / `validated_source_seed` / `blocked` mixed | Prevent orphan `[ATOM: ...]` tags; use only per-row claim ceilings in `SEEDS-OF-TRUTH.md` | Promote only after source-sentence audit or owner-lane source freeze |
| Lidsky and Andino 2022 pathogen-control aging | Paper 1 | `research_hub/literature/PMID-36096982-lidsky-andino-2022.json` and EXP-009 local intake | `validated_source_seed` | Conceptual pathogen-control background only | Publication atomization and claim lint |
| Prion / prion-like conformational templating | Paper 1 | Component table marks foundation as measured but exact references remain partly verify-gated | `estimated` | Established-base paragraph with citations verified before final | SD-A1 exact PMID/DOI verification |
| Yeast asymmetric aggregate inheritance | Paper 1 | Component table marks DRAFT-READY on verification | `estimated` | Use as proposed foundation only with verification tags | Exact citation verification |
| Microchimerism and maternal-grandmother overlap | Paper 1 | Local component table has live-checked PMIDs/DOIs but formal SD-A1 atom pending | `validated_source_seed` | Supports immune-overlap substrate, not fragment inheritance | Claim-specific attribution check |
| Oocyte proteostasis / ovarian protein longevity | Paper 1 | Local component table has live-checked PMIDs/DOIs but formal SD-A1 atom pending | `validated_source_seed` | Supports long-lived oocyte substrate only | Claim-specific attribution check |
| Disorder-cloud representation | Paper 1 / Paper 3 | Current project artifacts define the representation; calibration gate open | `estimated` | Method-framing / representation only | CAID/DisProt calibration and reliability curves |
| XenoDisorder EXP-137 ncAA predictor | Paper 2 | Paper 2 draft reports EXP-137 metadata and LOO metric; calibration and label-provenance gates remain open | `estimated` | Software/method feasibility claim only | Reconcile report/JSON, CAID/DisProt, CIs |
| XenoDisorder first-of-kind / novelty wording | Paper 2 | Paper 2 was lowered from "first" / "to our knowledge" language to prototype language pending prior-art re-check | `blocked` | Current draft may say prototype/method feasibility only | Re-run prior-art search and close AAindexNC/Brown 2026 gates before any first-of-kind assertion |
| EXP-144 metal-modified extension | Paper 2 | Draft reports P1-P7 predictions | `estimated` | Predictions/falsifiable hypotheses only | Wet-lab or higher-tier validation before result language |
| Canonical predictor modification-invariance gap | Paper 1 / Paper 2 | Analysis design present; numbers marked TO-COMPUTE; EXP_019 null gate open | `estimated` | Describe representational gap and planned statistic | Compute gap statistic and close null gate |
| Paper 2 predictor-blindness language | Paper 2 | Draft wording lowered from completed-result language to planned by-construction representational-gap test; numbers remain TO-COMPUTE | `blocked` | Planned/statistical design language only | Close EXP_019 matched nulls before result language |
| EXP-011 visual-math surrogate benchmark | Paper 3 | Design and test matrix exist; Ding Stage-0 source preflight produced `BLOCKED_SOURCE_CONTRACT_REQUIRED` because the processed age/tissue metric contract and matched-null bundle are missing in Shadow Seeds | `blocked` | Design/core experiment plan plus governed source-contract block | Create benchmark bundle, freeze hardware ladder receipts, then execute numeric benchmark with nulls |
| CIRBP EXP-012 ortholog switch embodiment | Paper 3 appendix / patent packet | Gate receipt exists; three-way ortholog freeze incomplete | `blocked` | Governance/provenance blocked embodiment only | Freeze NMR accession/source/hash and redacted alignment |
| PMEL / GLP-1 / ice nucleation peptide families | Patent/research appendix | Portfolio register marks exploratory, source-gated, and not validation evidence | `blocked` | Mention only as examples of gated embodiment families if counsel-safe | Source freeze, novelty search, validation gates |
| Original CytoClock preprint lineage | Paper 1 lineage | EXP-010 correction: pre-SeedGraph lineage, not atomized | `validated_source_seed` | Historical lineage / expansion context | Do not call original lineage SeedGraph-backed |
| TOOL-PEPFUNN peptide informatics prior art | Paper 2 / Paper 3 / EXP-011 | `research_hub/literature/PMC11706630-pepfunn-2025.xml`, SHA-256 `ec4799ccaad3b224b7edae95e85a1e1ed013b40a22b7f91c7aad96965e2ace80`; curated note `research_hub/literature/curated/260613-pepfunn-notes.md`; comparison artifact `.planning/publication/260610-shadow-dogma-fast-track-goal/PMC11706630-PEPFUNN-SHADOW-SEEDS-COMPARISON.md` | `validated_source_seed` | Cite-and-use prior art for peptide property/similarity/clustering/library/matched-pair/ncAA monomer-dictionary workflows; use as EXP-011 baseline/control candidate; not disorder, aging, cross-seeding, governance, or biological validation evidence | Run MacBook/local install-test benchmark and add as baseline feature-control in EXP-011 before claiming local hardware compatibility or surrogate added value |

## Practical Drafting Rule

For the next human edit, every paragraph should end up with one of these tags:

- `[ATOM]` only for claim-specific use of the five read-only SeedGraph atomic proofs after source-sentence audit.
- `[SOURCE-SEED]` for verified metadata or curated local notes without publication atom.
- `[ESTIMATE]` for plausible but incomplete rows.
- `[BLOCKED]` for claims that cannot be used yet.

## Stop Conditions

- Do not call any seed a "truth" in manuscript prose unless it is converted to a custody-bearing atom or explicitly framed as operator shorthand.
- Do not use source-seed status to claim biological validation.
- Do not import row-level supplement, sequence, patient/sample, cohort, or protected payloads into this matrix.
- Do not write to SeedGraph or Overwatch from Shadow Seeds.
