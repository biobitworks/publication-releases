# Paper 2 — HUMAN-READABLE ROUGH DRAFT
## For human editing: all claims traced to seed atom IDs; [NEEDS-VERIFICATION] tags intact; [TO-COMPUTE] placeholders intact

**Status:** DRAFT — patent-first gate; no submission before operator/counsel confirms filing/priority.
**Claim ceiling:** SOFTWARE_EVIDENCE / SIMULATION_EVIDENCE / LITERATURE_GROUNDED_HYPOTHESIS. Not clinically validated.
**Draft assembled:** 2026-06-12 from governed source sections and seed atoms.

---

# A Peptide-First Disorder Predictor for Non-Canonical and Metal-Modified Amino Acid Residues

*Short title:* Peptide-first ncAA disorder scoring

---

## Abstract

Intrinsic protein disorder governs how peptides and protein fragments fold, aggregate, and form interfaces — yet every widely-used disorder predictor is defined over only the twenty canonical amino acids. Aging chemistry and engineered biology routinely introduce non-canonical amino acids (ncAAs) and post-translational modifications, so the residues that may carry the most aging-relevant conformational signal fall outside the input alphabet of current tools.

We address this gap with a peptide-first, residue-resolved prototype disorder predictor for ncAAs [ATOM: NCAA-PRED-LOO; SOFTWARE_EVIDENCE]. A gradient-boosting regression model is trained on eight public, interpretable amino-acid property features (hydrophobicity, charge, flexibility, hydrogen-bond capacity, volume, polarity, backbone phi preference, beta-sheet propensity) [ATOM: NCAA-PRED-FEATURES], drawn from AAindex (Kawashima 2008), Kyte-Doolittle (1982), Chou-Fasman (1978), Creighton (1993), the CHARMM36 ncAA extension (Croitoru et al. 2021, PMID 34009984 [ATOM: FF-NCAA]), and Forcefield_NCAA (Khoury 2014 [ATOM: FF-NCAA]). Disorder-propensity training labels are calibrated from metapredict v3 (Emenecker 2021, PMID 34480923 [ATOM: TOOL-METAPREDICT]) and IUPred2A [ATOM: NCAA-PRED-LABELS; IUPred2A = academic-license, see Limitations]. Any first-of-kind or novelty wording remains blocked until the prior-art re-check and AAindexNC/Brown 2026 reference gates close.

The model emits disorder scores for 36 ncAAs and reports leave-one-out cross-validation over its small training set (LOO r² = 0.76, RMSE = 0.00518, n = 20 training residues; training fit r² = 0.999 — reported as in-sample diagnostic only, not generalization) [ATOM: NCAA-PRED-LOO]. A metal-modified extension covers 14 metal-amino-acid pairs across 11 metals and yields seven pre-registered, falsifiable predictions (P1–P7) for downstream wet-lab testing [ATOM: METAL-PRED-P1-7; SIMULATION_EVIDENCE — predictions, not results]. A planned predictor-blindness demonstration will test the by-construction representational gap in canonical predictors; its numerical results remain [TO-COMPUTE] and blocked pending matched nulls [ATOM: PREDICTOR-BLINDNESS].

The disorder output is presented as a per-residue uncertainty surface (the "disorder cloud") — a computational interpretability layer over IDR predictions, not a validated conformational ensemble. This layer is positioned below Bayesian IDP ensemble methods (bAIes, AlphaFold-Metainference) [ATOM: SCORING-GAP; see IDR-IDP-GAP-AND-HONEST-NEGATIVE.md]. Prior ncAA-aware tools target solubility or property cataloguing, not disorder [ATOM: PRIOR-ART]. Not clinically validated.

---

## 1. Introduction

### 1.1 Disorder prediction is a twenty-letter discipline

Protein intrinsic disorder prediction has become load-bearing infrastructure across structural biology, proteomics, and the interpretation of the dark proteome — the substantial fraction of protein sequence space for which no experimental structure and, often, no confident structural model exists [ATOM: DB-DARKPROTEOME; Perdigao et al. 2015, PMID 26578815]. Modern predictors — metapredict (Emenecker et al. 2021, PMID 34480923 [ATOM: TOOL-METAPREDICT]), IUPred-3 (Erdos et al. 2021, PMID 34048569 [ATOM: TOOL-IUPRED3]), and feedforward predictors such as flDPnn (Hu et al. 2021, PMID 34290238) — assign a per-residue disorder propensity by reading a primary sequence drawn from a fixed twenty-letter alphabet. Their training labels are anchored to curated disorder repositories, including DisProt [ATOM: DB-DISPROT; PMID 41249866], and to structures built from the same canonical twenty: the Protein Data Bank (Berman et al. 2000, PMID 10592235), UniProt (PMID 36408920), and the AlphaFold pLDDT confidence signal now widely repurposed as a disorder proxy (Jumper et al. 2021, PMID 34265844).

The shared, almost universally unstated, assumption is that every residue a predictor will ever encounter is one of the twenty proteinogenic amino acids. This assumption is reasonable for a freshly translated polypeptide, and it is what lets these tools operate at proteome scale. But it is also a hard structural boundary: a modified or non-canonical residue is, by construction, invisible to a canonical predictor.

Crucially, this is not the field gap we are claiming to solve. The IDR/IDP ensemble problem — that all current tools treat disorder as a point estimate rather than a dynamic conformational ensemble [ATOM: SCORING-GAP] — is a well-documented, actively-researched limitation [see IDR-IDP-GAP-AND-HONEST-NEGATIVE.md]. What we address is the narrower, more tractable sub-problem: the complete absence of any disorder predictor for non-canonical residue chemistry.

### 1.2 Aging rewrites residue chemistry below the level the canonical alphabet can represent

The twenty-letter assumption holds at the moment of translation. It does not hold over a lifespan. Aging is, in large part, a chemistry problem at the residue level: long-lived peptides and the fragments derived from them accumulate spontaneous and post-translational modifications that convert canonical residues into chemically distinct, non-canonical species [ATOM: PTM-SET; NEEDS-VERIFICATION: primary-literature PMIDs for each aging-PTM class]. The most durable substrates for this drift are long-lived proteins — eye-lens crystallins, collagen, myelin components, nuclear-pore and histone subunits — whose peptides persist for years to decades and therefore integrate a lifetime of slow chemistry (Savas et al. 2012; Toyama et al. 2018; Fornasiero et al. 2018 [NEEDS-VERIFICATION: exact PMIDs]).

On those long-lived substrates, a recurring set of modifications has direct literature support: spontaneous asparagine deamidation and aspartate isomerization generate isoaspartate, whose accumulation is normally counteracted by the PIMT/PCMT1 isoaspartyl repair methyltransferase [ATOM: PTM-ISOASP; NEEDS-VERIFICATION: exact PMID]. Glycation produces advanced glycation end-products and carboxymethyl-lysine (CML/AGE) [ATOM: PTM-SET; NEEDS-VERIFICATION]. Carbamylation converts lysine to homocitrulline [NEEDS-VERIFICATION], and oxidation generates methionine sulfoxide (MetO) and related species [NEEDS-VERIFICATION]. Metal coordination adds a further distinct class of modification.

Each of these events changes the side-chain chemistry — hydrophobicity, charge, hydrogen-bonding capacity, volume, polarity, local backbone preference — that disorder propensity ultimately depends on. The biologically relevant unit is the modified peptide or fragment, and the relevant question is what disorder propensity that peptide carries *given* its non-canonical residues: precisely the question a twenty-letter predictor is not equipped to ask [ATOM: SCORING-GAP].

### 1.3 Canonical predictors are modification-invariant: the representational gap

The consequence is not that canonical predictors are inaccurate in the usual sense. It is that they are *invariant* to the chemistry that aging introduces. When a sequence-centric tool encounters a modified residue, one of three things happens: (a) the modification is collapsed to its canonical parent — isoaspartate reads as aspartate, methionine sulfoxide as methionine, homocitrulline as lysine; (b) the residue is skipped, breaking the local window; or (c) the residue is undefined and cannot be entered at all [ATOM: PREDICTOR-BLINDNESS; ATOM: SCORING-GAP]. In every case the predictor's output is unchanged by the modification.

This is a categorical limitation, not a tunable one. It is not addressed by larger training sets, deeper networks, or better canonical labels, because the missing information was never representable in the input alphabet. The tools are excellent within their design envelope; they are structurally silent outside it. And because this drift concentrates on long-lived, slowly-resolved peptides — the same peptides over-represented in the dark proteome [ATOM: DB-DARKPROTEOME], where structural ground truth is already scarce — the blind spot falls exactly where independent verification is hardest.

### 1.4 A tractable path: scoring from physicochemical properties

The tractable path to closing this representational gap is to score disorder from the *physicochemical properties* of a residue rather than from its canonical identity. Hydrophobicity, charge, flexibility, hydrogen-bonding capacity, volume, polarity, backbone phi preference, and beta-sheet propensity [ATOM: NCAA-PRED-FEATURES] are defined for non-canonical residues just as they are for canonical ones. Public property scales and parameter sets already exist: the AAindex property database (Kawashima et al. 2008), Kyte-Doolittle hydropathy scale (1982), Chou-Fasman secondary-structure propensities (1978), Creighton residue volumes (1993), and force-field parameterizations that explicitly cover non-canonical amino acids — the CHARMM36 ncAA extension (Croitoru et al. 2021, PMID 34009984 [ATOM: FF-NCAA]) and Forcefield_NCAA (Khoury et al. 2014 [ATOM: FF-NCAA], covering 147 non-canonical amino acids).

Existing modification-aware tools confirm both the demand and the remaining gap. CamSol-PTM extends *solubility* prediction to post-translationally modified residues (Oeller et al. 2023, PMID 37978172 [ATOM: PRIOR-ART; verified]) but does not predict intrinsic disorder. AAindexNC catalogues physicochemical properties for non-canonical residues (Milchevskiy et al. 2024 **[ESTIMATE — seed needs verification; previously cited PMID 39684773 was incorrect, resolves to an unrelated bamboo-genetics paper; real reference not yet confirmed] [ATOM: PRIOR-ART]**) — a property resource, not a disorder predictor. A recent preprint addressing xeno amino-acid secondary structure (Brown et al., bioRxiv 2026 **[ESTIMATE — seed needs verification: exact DOI/identifier for Brown et al. bioRxiv 2026] [ATOM: PRIOR-ART]**) targets secondary structure rather than disorder. **The novelty differentiator must not lean on the AAindexNC citation until its reference is confirmed.**

This paper addresses the gap directly as a bounded software prototype: a gradient-boosting regression model scoring disorder propensity from eight public physicochemical features, evaluated under leave-one-out cross-validation (LOO r² = 0.76, RMSE = 0.00518, n = 20) [ATOM: NCAA-PRED-LOO], extended to metal-modified residues with seven falsifiable predictions [ATOM: METAL-PRED-P1-7], and accompanied by a planned demonstration that canonical predictors are modification-invariant [ATOM: PREDICTOR-BLINDNESS]. The disorder output is presented as an interpretability surface (the disorder cloud) positioned explicitly *below* Bayesian IDP ensemble methods, not as a competitor to them. The stronger claim that this is the first disorder predictor for non-canonical amino acids is a gated prior-art claim, not asserted by the current draft.

---

## 2. Methods

### 2.1 Peptide-first design rationale

The unit of analysis throughout this work is the **peptide** and its constituent residues, not the intact full-length protein. We score short peptides and individual residue positions for disorder propensity, and we treat each chemically modified residue as a distinct non-canonical amino acid (ncAA) occupying a defined position within a peptide. This peptide-first framing is deliberate: aging chemistry acts at the level of individual residues and the local peptide context surrounding them, and the disorder consequences of modifications are local. Working at the peptide and residue level keeps the prediction target matched to the chemistry that motivates it.

### 2.2 Feature representation: eight public physicochemical features

Each amino acid — canonical or non-canonical — is represented by an 8-dimensional vector of public physicochemical property features [ATOM: NCAA-PRED-FEATURES]:

1. **Hydrophobicity** — from AAindex (Kawashima 2008) and Kyte-Doolittle (1982)
2. **Charge** — from AAindex
3. **Flexibility** — from AAindex
4. **Hydrogen-bond capacity (h_bond_capacity)** — from AAindex
5. **Volume** — from Creighton (1993)
6. **Polarity** — from AAindex
7. **Backbone phi preference (backbone_phi_pref)** — from Chou-Fasman (1978)
8. **Beta-sheet propensity** — from Chou-Fasman (1978)

These eight features were chosen because each is a well-established, residue-level physicochemical descriptor with published provenance, and each is computable or estimable for non-canonical residues from published parameter sets. Non-canonical feature values are sourced from the CHARMM36 ncAA extension (Croitoru et al. 2021, PMID 34009984 [ATOM: FF-NCAA]) and Forcefield_NCAA (Khoury et al. 2014 [ATOM: FF-NCAA]), which supply the physicochemical parameters from which feature values can be assigned to modified residues absent from classical amino-acid property tables. No feature in the model is derived from a private or unpublished source.

### 2.3 Training labels and calibration

The regression target — the disorder propensity each residue's feature vector is trained to predict — is a **calibrated label derived from metapredict v3 and IUPred2A** disorder propensities [ATOM: NCAA-PRED-LABELS].

metapredict (Emenecker et al. 2021, PMID 34480923 [ATOM: TOOL-METAPREDICT]; v3 release used for label generation) provides the primary canonical-residue disorder signal and is MIT-licensed. **[NEEDS-VERIFICATION: the v3-specific release (Emenecker et al. 2022, Protein Sci, DOI 10.1002/pro.4466) is not PubMed-indexed; PMID 34480923 is the original 2021 Biophys J paper. Confirm v3 DOI via CrossRef before camera-ready.]**

IUPred2A is used to calibrate the disorder-propensity labels for the training residues [ATOM: TOOL-IUPRED3]. **License flag:** IUPred is distributed under an academic-only license. Because IUPred2A is used in constructing the training labels, its license terms may propagate to any commercial or non-academic release of a model trained on those labels. This dependency is flagged as a gate; see Limitations.

### 2.4 Model and training (EXP-137)

The predictor is a **gradient-boosting regression (GBR)** model mapping the 8-feature vector of a residue to its calibrated disorder propensity. The model was trained on **n = 20** labeled amino-acid residues and then used to predict disorder propensities for **36 non-canonical amino acids** not directly labeled [ATOM: NCAA-PRED-LOO].

**Reported performance (verbatim from EXP-137 run metadata):**

| Metric | Value | How to read it |
|--------|-------|----------------|
| LOO cross-validated r² (n = 20) | **0.760** | **Headline generalization metric [ATOM: NCAA-PRED-LOO]** |
| RMSE (LOO) | 0.00518 | Generalization error on calibrated propensity scale |
| Training-fit r² | 0.9988 | **In-sample diagnostic only — not generalization; overfit-prone at n = 20** |
| Training residues n | 20 | Small-n limitation |
| ncAAs scored | 36 | Inference targets |

We report LOO r² = 0.76 as the headline performance figure because, with only twenty training residues against a flexible boosted-tree learner, in-sample fit is overfit-prone and is not a credible estimate of out-of-sample behavior. The gap between training fit (0.9988) and LOO (0.76) is itself the expected signature of a small-n, high-capacity regressor.

### 2.5 The disorder cloud as an interpretability layer

The predictor's per-residue output is presented as a **disorder cloud** — a per-residue map of predicted disorder mean, uncertainty width, predictor disagreement, and local context sensitivity, rather than a single point estimate [ATOM: SCORING-GAP; DISORDER-CLOUD-CLAIM.md].

**The disorder cloud is a computational interpretability layer, not a validated conformational ensemble.** It does not provide atomic IDP dynamics or multi-state conformational sampling. It must be positioned *below* Bayesian IDP ensemble methods — bAIes (AF2 + force-field Bayesian ensembles), AlphaFold-Metainference, AFflecto — that generate genuine conformational ensembles. The disorder cloud is useful precisely because it preserves predictor disagreement and flank-dependent uncertainty instead of collapsing them to a single number; it does not solve the IDR/IDP ensemble problem that those methods address [ATOM: SCORING-GAP; IDR-IDP-GAP-AND-HONEST-NEGATIVE.md].

**[NEEDS-VERIFICATION: bAIes, AlphaFold-Metainference, AFflecto, DISPROTBENCH (arXiv 2507.02883) — confirm citations before camera-ready.]**

Multi-predictor comparison/consensus is prior art (D2P2, PMID 23203878; CAID Portal **[NEEDS-VERIFICATION: Del Conte et al., NAR 2023]**). The disorder cloud does not claim novelty for using multiple predictors; its narrow, defensible wedge is *modification-aware, fragment-level, in-context disorder uncertainty for ncAA/PTM positions* specifically, where canonical predictors flatten residue identity.

### 2.6 Metal-modified extension (EXP-144): predictions only

EXP-144 extends the EXP-137 scoring approach to **metal-coordinated residues**, treating a residue bound to a given metal ion as a distinct non-canonical residue with its own feature vector [ATOM: METAL-PRED-P1-7]. The extension covers **14 metal-modified amino acids across 11 metal species**: As³⁺, CH₃Hg⁺ (methylmercury), Ca²⁺, Cd²⁺, Cu²⁺, Cu⁺, Fe²⁺, Fe³⁺, Hg²⁺, Pb²⁺, and Zn²⁺.

EXP-144 is **Phase 1 (computational)** only. Everything reported for EXP-144 is a **falsifiable computational prediction for downstream experimental validation — not a result, not a validated interaction, not a mechanism.** The seven predictions are stated in Results §3.

**[NEEDS-VERIFICATION: primary-literature PMIDs for the MAPT/tau C322, amyloid-beta His13/His14, and APOE3 C112 metal-coordination site annotations used as prediction targets.]**

### 2.7 Predictor-blindness demonstration design

To make the representational gap concrete and quantifiable, we designed a controlled **predictor-blindness demonstration** contrasting a canonical-alphabet disorder predictor against the ncAA predictor on the same aging-relevant peptides [ATOM: PREDICTOR-BLINDNESS].

**Inputs.** A set of aging-relevant peptides carrying documented modification sites — positions for which the published literature reports a specific chemical modification (deamidation/isomerization, oxidation, glycation, carbamylation, or metal coordination). Each peptide enters in two forms: a **canonical** form and a **modified** form (the documented modification represented as the corresponding non-canonical residue at the same position). **[NEEDS-VERIFICATION: the specific peptides, modification types, and site positions, with primary-literature PMIDs/DOIs, to be enumerated in the supplement.]**

**Contrast.** For each peptide: (1) a canonical disorder predictor (e.g. metapredict v3 [ATOM: TOOL-METAPREDICT]) is run on both forms — because the modified residue has no canonical representation, it is collapsed to its canonical parent or skipped, and the expected change in predicted disorder is **zero or near-zero**; (2) the ncAA predictor (EXP-137/EXP-144) is run on the modified form with the modification represented as its non-canonical residue, and can return a non-zero disorder shift.

The reported quantity is the **gap** between the two predictors' responses to the same documented modification. We do not claim that the ncAA predictor's shift is the biologically correct disorder change; the demonstration's claim is restricted to the existence and magnitude of the **representational gap**.

**Matched null controls.** Each modified peptide is compared against matched null peptides constructed to control for length, net charge, mass, and amino-acid composition while not carrying the documented modification [ATOM: PREDICTOR-BLINDNESS]. **Note: the expanded-null gate (EXP_019) is OPEN; all demonstration numbers are TO-COMPUTE and provisional pending gate closure.**

**All demonstration numbers are [TO-COMPUTE]:** canonical-predictor per-residue disorder delta under modification (expected ≈ 0); ncAA/metal-predictor per-residue disorder delta; matched-null distribution; and the gap statistic between the two tracks.

### 2.8 Reproducibility

The EXP-137 predictor and EXP-144 extension were produced as governed experiment runs with recorded identifiers, timestamps, and provenance signatures (EXP-137 provenance: EXP-137 / EXP-129b, INSIGHT-008; EXP-144 Phase 1 computational). All model metadata reported (model type, 8 feature names, performance metrics, 11 metals, 7 predictions) is taken verbatim from run metadata artifacts. All input feature scales and ncAA force-field parameter sources are public and cited above, enabling independent reconstruction of the feature matrix.

---

## 3. Results

### 3.1 A residue-level disorder predictor for non-canonical amino acids

EXP-137 is a disorder-scoring prototype parameterized for non-canonical amino acids [ATOM: NCAA-PRED-LOO; SOFTWARE_EVIDENCE]. The model is a gradient-boosting regression over eight publicly-defined, per-residue physicochemical features [ATOM: NCAA-PRED-FEATURES], drawn from open property scales (AAindex [Kawashima 2008], Kyte-Doolittle [1982], Chou-Fasman [1978], Creighton [1993]) with non-canonical residue parameters from CHARMM36-ncAA (Croitoru 2021, PMID 34009984 [ATOM: FF-NCAA]) and Forcefield_NCAA (Khoury 2014 [ATOM: FF-NCAA]). No proprietary descriptor enters the model. The possible first-of-kind position is reserved for the prior-art gate.

Training labels are calibrated against metapredict v3 (PMID 34480923 [ATOM: TOOL-METAPREDICT]) and IUPred2A [ATOM: NCAA-PRED-LABELS]. The trained model emits a per-residue disorder propensity for each of **36 ncAAs**. The IUPred2A calibration dependency in the training labels is an academic-license component (see Limitations); the public-feature inference path itself is license-clean.

The intended interpretation is narrow: the predictor extends residue-level disorder scoring across a chemically modified residue alphabet that canonical-only predictors do not represent. It does not assert that any specific modified peptide is disordered *in vivo*, nor that any predicted disorder shift produces a biological consequence. All predicted disorder is SOFTWARE_EVIDENCE for downstream hypothesis generation.

### 3.2 Generalization performance: LOO r² = 0.76, n = 20

The honest generalization metric for EXP-137 is the **leave-one-out (LOO) cross-validated r² = 0.760** (n = 20 training residues, RMSE = 0.00518 on the calibrated disorder-propensity scale) [ATOM: NCAA-PRED-LOO]. We report LOO as the headline performance figure.

For transparency we also report the **training fit, r² = 0.9988**. This number reflects the model reproducing its own training labels and is **not** a generalization estimate; it must not be read as accuracy on unseen residues. It is reported only as a training-fit diagnostic alongside the LOO value. The gap between training fit (0.9988) and LOO (0.76) is the expected signature of a small-n, high-capacity regressor and is the reason LOO governs every performance claim in this paper.

LOO r² = 0.76 on n = 20, while encouraging for a prototype over an under-modeled residue class, is an estimate from a small sample with a correspondingly wide confidence interval. The metric should be treated as a proof-of-feasibility for ncAA disorder regression, not as a settled accuracy figure. The small-n caveat is carried into Limitations and is not relaxed anywhere.

### 3.3 Feature importance

The eight public physicochemical features contribute jointly to the GBR fit. Their relative importances — described qualitatively here as a SOFTWARE_EVIDENCE characterization of which residue properties the model weights most — are consistent with established physicochemical determinants of intrinsic disorder: low hydrophobicity, high net charge, and high backbone flexibility favor disorder; high beta-sheet propensity and large hydrophobic volume favor order. The exact per-feature gain values are **[TO-COMPUTE: extract relative feature importances from the trained EXP-137 GBR model]** and will be tabulated before submission. Because the feature set is exactly the public scale set described above, every importance value is auditable against an open source.

### 3.4 Differentiation from prior art

EXP-137 predicts *disorder* for non-canonical residues — a target not covered by any prior published tool [ATOM: PRIOR-ART]. Three lines of prior art are the nearest neighbors; each predicts a different property:

- **CamSol-PTM** (Oeller 2023, PMID 37978172 [ATOM: PRIOR-ART; primary-record verified]) predicts **solubility** for post-translationally modified sequences — a related but distinct property. Not a disorder predictor.
- **AAindexNC** (Milchevskiy 2024 **[ESTIMATE — seed needs verification; cited PMID 39684773 was incorrect; real reference not yet confirmed] [ATOM: PRIOR-ART]**) catalogues physicochemical properties for non-canonical residues — a property resource, not a disorder predictor. **The novelty differentiator must not rely on this entry until its reference is confirmed.**
- **Brown et al., bioRxiv 2026** **[ESTIMATE — seed needs verification: exact DOI/identifier] [ATOM: PRIOR-ART]** addresses **secondary structure** of xeno amino acids, not intrinsic disorder.

The differentiation is on prediction target (residue-level disorder propensity), not merely on input alphabet. Any first-of-kind claim must be **re-verified against the current literature at submission time**, as the modified-residue prediction space is active.

### 3.5 Metal-modified extension (EXP-144): seven falsifiable predictions, not results

EXP-144 extends the residue alphabet to metal-coordinated residues — 14 metal-amino-acid species spanning 11 metals (As³⁺, CH₃Hg⁺, Ca²⁺, Cd²⁺, Cu²⁺, Cu⁺, Fe²⁺, Fe³⁺, Hg²⁺, Pb²⁺, Zn²⁺) [ATOM: METAL-PRED-P1-7]. Everything reported for EXP-144 is a **prediction / falsifiable computational hypothesis (Phase 1, computational)**, classified SIMULATION_EVIDENCE. None of P1–P7 is a measured result, a validated interaction, a binding claim, or a mechanism; each is a forward-stated, testable expectation for downstream experimental falsification at the peptide level.

**The seven predictions are:**

- **P1.** Hg²⁺ coordinated at the MAPT/tau cysteine C322 site is predicted to **increase** disorder propensity of the surrounding peptide. *(Prediction.)* **[NEEDS-VERIFICATION: primary PMID for MAPT/tau C322 metal-coordination site annotation.]**
- **P2.** Cu²⁺ at the amyloid-beta His13/His14 site is predicted to **accelerate aggregation kinetics** of the Aβ peptide. *(Prediction; aggregation kinetics = hypothesis to test, not an observed rate.)* **[NEEDS-VERIFICATION: primary PMID for Aβ His13/His14 annotation.]**
- **P3.** Zn²⁺ at the amyloid-beta His13/His14 site is predicted to produce a **biphasic** disorder/aggregation response (low Zn inhibits; high Zn promotes). *(Prediction.)*
- **P4.** The KLVFFA peptide, which carries **no metal-coordination sites**, is predicted to show **no** metal-induced disorder shift — a negative/specificity control. *(Prediction/control.)*
- **P5.** The APOE3 hinge region (no Cys) is predicted to be **Hg-resistant**, whereas the C112-containing region is predicted to be **Hg-sensitive**. *(Prediction.)* **[NEEDS-VERIFICATION: primary PMID for APOE3 C112 annotation.]**
- **P6.** Cd²⁺ is predicted to **mimic** Zn²⁺ disorder effects at shared coordination sites, with greater aggregation promotion. *(Prediction.)*
- **P7.** Metal-induced disorder shifts are predicted to **correlate with binding affinity** (log K) across the metal panel. *(Prediction; binding affinity appears here only as the independent variable of a falsifiable correlation hypothesis — no binding is asserted to have been measured.)*

The protein-context labels (MAPT/tau C322, Aβ His13/14, APOE3 C112) name the sequence contexts of the peptides under prediction. They are not assertions that the modification occurs, binds, or has any consequence in tissue. EXP-144 is BLOCKED from any results-level reading until experimental or higher-tier computational validation is performed.

### 3.6 Predictor-blindness demonstration: planned representational-gap test

The motivating design claim is that **canonical-residue disorder predictors are modification-invariant by input representation** — they cannot directly encode a non-canonical or metal-modified residue because such predictors are defined over the canonical twenty residues [ATOM: PREDICTOR-BLINDNESS]. The draft does not claim completed blindness statistics.

The demonstration compares, on matched aging-relevant peptide contexts: (i) the disorder profile returned by a canonical predictor (e.g. metapredict v3 [ATOM: TOOL-METAPREDICT]) for the unmodified versus nominally modified sequence; against (ii) the disorder profile returned by the ncAA/metal-modified predictor (EXP-137/EXP-144). The expected structure:

- **Canonical predictor:** disorder output is **unchanged** by the modification — the canonical track's gap is, by construction, **zero or near-zero**, because the modified residue is not representable.
- **ncAA/metal-modified predictor:** disorder output **differs** between unmodified and modified residue context, exposing a disorder signal the canonical track cannot register.

**All specific numbers are [TO-COMPUTE]:** canonical-predictor per-residue disorder delta under modification; ncAA/metal-predictor per-residue and per-peptide disorder delta; matched-null distribution (length/charge/mass/composition-controlled); and the gap statistic between the two tracks. The matched-null gate (EXP_019 expanded-null) is **OPEN**; results are provisional pending gate closure.

This demonstration makes **no interaction, binding, or mechanism claim.** It quantifies only a *representational* gap — what canonical disorder scoring can and cannot encode about a modified residue — and any peptide flagged by the modification-aware track is a candidate computational hypothesis for downstream validation only.

### 3.7 Comparison with CAID/DisProt

The disorder cloud's accuracy claims are deferred to a clean CAID/DisProt calibration rerun. **[NEEDS-VERIFICATION: the prior E1 calibration run had a NANOG accession error and a PRNP mask bug; see CHAIN-OF-CUSTODY-NANOG.md. No accuracy claim from that run should be carried forward until the clean rerun is complete.]** We do not report a CAID number here; we report only the LOO r² = 0.76 on the 20-residue training set as the performance metric for the ncAA predictor specifically [ATOM: NCAA-PRED-LOO].

---

## 4. Discussion

### 4.1 Scoring the residues the canonical alphabet cannot represent

The central contribution of this work is methodological. EXP-137 is a bounded disorder-scoring prototype parameterized for non-canonical amino acids (ncAAs), and EXP-144 extends that scoring engine to an initial set of metal-modified ncAAs. We frame the result deliberately at the level of the peptide and the fragment rather than the full folded protein: the unit that matters for this predictor is the residue and the short peptide context in which it sits, because that is the unit on which a disorder propensity is defined and on which aging chemistry acts [ATOM: SCORING-GAP]. The possible first-of-kind wording is not used as a current claim.

Established disorder predictors are defined over the 20 canonical amino acids. A modified or non-canonical residue is, in practice, collapsed onto its canonical parent, skipped, or left undefined, making the predictor output approximately invariant to the modification [ATOM: PREDICTOR-BLINDNESS]. The practical consequence is a **coverage gap** rather than a wrong answer: where aging chemistry has converted a residue into something outside the canonical alphabet, the canonical predictor cannot register that the local disorder propensity may have changed. EXP-137 addresses exactly this gap by learning a disorder propensity from the eight public amino-acid property features described in Methods — features that are defined for any residue for which published property values exist, canonical or not [ATOM: NCAA-PRED-FEATURES].

We interpret the predictor as enabling two downstream uses, both bounded as computational hypotheses: **peptide discovery** (surfacing fragments whose disorder character is governed by a modified residue that canonical-only scoring would score as if unmodified) and the **flagging of candidate novel interactions** (co-localized or compositionally plausible fragment pairings a canonical-only landscape would not distinguish). These are candidate interactions in the strict sense — computational hypotheses generated to prioritize downstream experimental validation. Nothing in this work measures a binding event, demonstrates a physical interaction, establishes a mechanism, or assigns disease, diagnostic, or therapeutic meaning to any flagged peptide.

### 4.2 Differentiating from prior art: solubility is not disorder

The gated novelty hypothesis is that no prior tool predicts *disorder* for non-canonical residues. The closest published work occupies adjacent but distinct problems [ATOM: PRIOR-ART]. This remains a claim to test, not a settled manuscript assertion.

**CamSol-PTM** (Oeller 2023, PMID 37978172; primary-record verified) scores solubility, including post-translationally modified residues, but does not predict intrinsic disorder. This differentiation is clean and verified: CamSol-PTM is a solubility-not-disorder tool.

**AAindexNC** (Milchevskiy 2024 **[ESTIMATE — seed needs verification; cited PMID 39684773 was incorrect; real reference not yet confirmed] [ATOM: PRIOR-ART]**) compiles property values for non-canonical amino acids — a property resource we regard as complementary — but it is a property catalogue, not a disorder predictor. **Important discipline:** the novelty claim must not lean on this differentiator until the AAindexNC reference is confirmed; an incorrect citation could undermine the entire prior-art argument.

**Brown et al., bioRxiv 2026** **[ESTIMATE — seed needs verification: DOI and author list] [ATOM: PRIOR-ART]** addresses secondary structure rather than disorder. These differentiations should be re-verified against current literature at the time of submission, because the field is moving and a 2026 entrant could narrow the gap; the novelty claim is contingent on that re-check.

### 4.3 Honest performance framing: competitive, not leading

LOO r² = 0.76 on n = 20 is the honest center of the results [ATOM: NCAA-PRED-LOO]. The training fit (r² = 0.999) is reported only as a training-fit diagnostic; with n = 20 it is overfit-prone and should not be read as a generalization claim. The LOO value itself carries a wide confidence interval at n = 20 and should be treated as a proof-of-feasibility rather than a settled accuracy figure.

**The honest placement of this predictor is competitive with canonical predictor benchmarks (approximately r² ~ 0.68 for the comparable calibrated canonical regime), not leading them.** EXP-137 is a prototype instrument for an under-addressed residue class; it is not a state-of-the-art accuracy advance over existing canonical predictors within the canonical domain. Its value is the residue class it attempts to cover, not superior accuracy on canonical residues.

### 4.4 The disorder cloud: interpretability layer, not a conformational ensemble

The disorder cloud is a per-residue computational interpretability surface — it preserves predictor disagreement and flank-dependent uncertainty rather than collapsing them to a point estimate. This is useful precisely because IDPs are understood as flexible, context-dependent ensembles and not fixed structures; any single-point disorder prediction is already a significant simplification.

**The disorder cloud does not close the IDR/IDP ensemble problem.** It must be positioned *below* Bayesian IDP ensemble methods — bAIes, AlphaFold-Metainference, AFflecto **[NEEDS-VERIFICATION: citations for each]** — in any presentation. Those methods generate genuine atomic-resolution conformational ensembles, which is the correct approach to the IDR/IDP problem for systems where computational resources permit. The disorder cloud is a low-resource **triage and interpretability layer** useful specifically where canonical predictors flatten ncAA/PTM identity or miss flank effects; it does not compete with ensemble methods on their own terms.

As stated in the canonical wording [DISORDER-CLOUD-CLAIM.md]: *"We do not treat the cloud as an experimentally determined conformational ensemble. Instead, it is a computational interpretability layer over IDR predictions: a per-residue map of predicted disorder mean, uncertainty width, predictor disagreement, and local context sensitivity. Its role is to guide hypotheses about robust versus conditional disorder, with accuracy claims deferred to CAID/DisProt calibration."*

### 4.5 Metal-modified predictions as falsifiable hypotheses

The metal-modified extension covers 14 metal-amino-acid combinations across 11 metals and yields seven explicitly falsifiable predictions [ATOM: METAL-PRED-P1-7]. We restate their status plainly: P1–P7 are PREDICTIONS — computational hypotheses generated by the scoring engine for downstream experimental falsification. None is a measured result, and none should be cited as a finding about tau, amyloid-beta, APOE, or any disease process. Their value is that they are stated precisely enough to be wrong: a wet-lab or higher-fidelity simulation program can test each and report back. P4 (KLVFFA as negative control) is particularly important as it provides an internal specificity check that, if falsified, would impeach the entire metal-binding signal.

### 4.6 Connection to the Shadow Dogma companion paper

This predictor is the methodological half of a two-paper pairing. The companion work (Paper 1, *Shadow Dogma*; companion preprint **[NEEDS-VERIFICATION: companion DOI on co-deposit]**) frames a hypothesis: that conformational information relevant to aging is carried, in part, on the peptide-to-peptide channel — the residues that sequence-centric tooling is structurally least equipped to read. Aging is known to generate non-canonical residues at scale through spontaneous and enzymatic chemistry [ATOM: PTM-SET; ATOM: PTM-ISOASP; NEEDS-VERIFICATION: exact primary-literature PMIDs], and the modifications accumulate preferentially on long-lived peptides and proteins (Savas 2012; Toyama 2018; Fornasiero 2018 [NEEDS-VERIFICATION: exact PMIDs]).

The intended relationship is precise. The companion paper identifies the gap; EXP-137 is offered as the first concrete evidence that the gap is *addressable* — a disorder score can be defined for non-canonical residues from public features alone. The predictor is the method that begins to read the conformational channel the companion paper describes; it does not prove the companion hypothesis. The deep-time and origin-of-life framings invoked in the companion paper (GADV hypothesis, prion-first precedents) are conceptual context for that paper and are not load-bearing for any claim made here.

---

## 5. Limitations

This section enumerates all discipline gates. Every limitation below must be stated in any public version of this manuscript.

**1. Small training set (n = 20). [ATOM: NCAA-PRED-LOO]**
The model is calibrated on 20 labeled residues. This is the dominant limitation. It constrains the reliability of extrapolation to the 36 predicted ncAAs and to all metal-modified residues, and it is the reason LOO, not training fit, is the reported metric. The predictor should be treated as a proof-of-concept method, not a saturated benchmark.

**2. LOO r² = 0.76 is the honest metric; training r² = 0.9988 is not. [ATOM: NCAA-PRED-LOO]**
The training r² is an overfit-prone training-fit diagnostic at n = 20. Generalization claims rest solely on LOO r² = 0.76 (RMSE 0.00518). Any comparison that cites the training r² as performance is incorrect.

**3. Training labels derive from calibrated predictors, not experimental disorder measurements.**
Disorder labels derive from metapredict v3 (MIT-licensed; PMID 34480923 [ATOM: TOOL-METAPREDICT]) and IUPred2A-calibrated disorder propensities [ATOM: NCAA-PRED-LABELS]. The model inherits any systematic bias of those upstream tools; the ground truth is itself predicted, not experimentally measured disorder. The predictor learns to reproduce a calibrated propensity rather than a direct observable. This is a **label-circularity** limitation: the LOO result is fit-to-predictors, not fit-to-ground-truth.

**4. EXP-144 predictions are unvalidated. [ATOM: METAL-PRED-P1-7]**
P1–P7 are falsifiable computational hypotheses (SIMULATION_EVIDENCE), not results. No metal-induced disorder shift, binding event, aggregation outcome, or disease association reported here has been experimentally confirmed. EXP-144 is Phase 1 computational only.

**5. IUPred2A licensing (academic license). [ATOM: NCAA-PRED-LABELS; ATOM: TOOL-IUPRED3]**
IUPred is distributed under an academic-only license. Its use in generating training/calibration labels carries license implications for any commercial release. Before commercial use or non-academic distribution, the IUPred2A dependency must either be removed and replaced with a commercial-safe calibration source, or the dependency must be explicitly disclosed and licensed. metapredict v3 (MIT) is unencumbered by this flag.

**6. EXP_019 expanded-null gate is OPEN. [ATOM: PREDICTOR-BLINDNESS]**
The statistical gate that would test whether discovery signal is explained away by length, charge, mass, coverage, activation method, or search-space size is not yet closed. Until it is, any peptide-discovery or candidate-interaction signal from the blindness demonstration must be read as provisional. The blindness-demonstration numbers are explicitly [TO-COMPUTE].

**7. Demonstration, not benchmark.**
The comparison against canonical predictors illustrates that they are modification-invariant; it is a demonstration of a coverage gap, not a head-to-head accuracy benchmark on a shared labeled disorder set for non-canonical residues, because no such gold-standard set exists. We do not claim the ncAA predictor is more accurate than canonical predictors on canonical residues.

**8. Novelty claim is time-bounded.**
"First ncAA disorder predictor" is asserted against the prior art surveyed (CamSol-PTM, AAindexNC **[NEEDS-VERIFICATION]**, Brown 2026 **[NEEDS-VERIFICATION]**) and must be re-verified at submission against any 2026 entrants. The claim is contingent on the AAindexNC reference being confirmed; if the confirmed reference also predicts disorder, the differentiator fails.

**9. Disorder cloud is not a validated ensemble.**
The disorder cloud is a computational interpretability layer. It has not been validated against CAID/DisProt in a clean run. Accuracy claims are deferred to a clean calibration rerun [DISORDER-CLOUD-CLAIM.md]. The cloud must be positioned below bAIes/AlphaFold-Metainference in any public presentation.

**10. CAID/DisProt calibration run has known data errors (OPEN).**
The prior CAID calibration run (E1) had a NANOG accession error and a PRNP mask bug. No accuracy number from that run should be cited. A clean rerun is required before CAID-based accuracy claims.

**11. Patent-first timing.**
ncAA/xenodisorder scoring is the patent lane for this program. This is a DRAFT; no submission or public disclosure should occur before patent filing/priority is confirmed by the operator and counsel.

**12. Aging-PTM primary citations pending verification. [ATOM: PTM-ISOASP; ATOM: PTM-SET]**
The aging-modification literature invoked in the companion-paper connection must be cited from verified primary literature at submission; exact PMIDs are tagged [NEEDS-VERIFICATION] throughout.

**13. Lane hygiene: no SIDS/SUDC content.**
This is the ncAA/xenodisorder lane, strictly separate from the SIDS/SUDC lane. No SUDC-derived cohort data is used as a claim here.

---

## 6. Claim Ceiling Summary

All claims in this work are bounded to:

- **SOFTWARE_EVIDENCE** — the predictor exists, is reproducible from public features, and reports LOO r² = 0.76 (n = 20) [ATOM: NCAA-PRED-LOO].
- **SIMULATION_EVIDENCE** — disorder propensities and metal-modified scores are model outputs; EXP-144 P1–P7 are computational predictions [ATOM: METAL-PRED-P1-7].
- **LITERATURE_GROUNDED_HYPOTHESIS** — the connection to aging biology, the Shadow Dogma framing, and the EXP-144 predictions are hypotheses grounded in cited literature, for downstream validation only [ATOM: PTM-SET; ATOM: PTM-ISOASP; ATOM: PRION-CHANNEL].
- **BLOCKED** — any biological, clinical, diagnostic, therapeutic, aging-reversal, validated-interaction, or candidate-promotion claim is blocked and is not made here.

**Not clinically validated.** This is a computational methods contribution. It makes no clinical, diagnostic, therapeutic, or aging-reversal claim. None of its outputs should be used for any such purpose.

---

## Atom-ID Traceability Index

| Atom ID | Statement summary | Source file |
|---------|-------------------|-------------|
| NCAA-PRED-LOO | LOO r²=0.76, training 0.9988, RMSE 0.00518, n=20, 36 ncAAs | paper2_seeds.jsonl |
| NCAA-PRED-FEATURES | 8 public features (hydrophobicity, charge, flexibility, h_bond, volume, polarity, phi, beta) | paper2_seeds.jsonl |
| NCAA-PRED-LABELS | Training labels = metapredict v3 + IUPred2A; IUPred2A = academic-license flag | paper2_seeds.jsonl |
| METAL-PRED-P1-7 | EXP-144: 7 falsifiable predictions, 11 metals; Phase 1 computational only | paper2_seeds.jsonl |
| PREDICTOR-BLINDNESS | Canonical predictors modification-invariant vs ncAA predictor; numbers TO-COMPUTE | paper2_seeds.jsonl |
| TOOL-METAPREDICT | metapredict (MIT); v3 used for label generation; PMID 34480923; v3 DOI NEEDS-VERIFICATION | paper2_seeds.jsonl |
| TOOL-IUPRED3 | IUPred-3 (academic license); PMID 34048569 | paper2_seeds.jsonl |
| DB-DISPROT | DisProt curated disorder database (CC-BY); PMID 41249866 | paper2_seeds.jsonl |
| DB-DARKPROTEOME | Dark proteome; Perdigao 2015 PMID 26578815 | paper2_seeds.jsonl |
| FF-NCAA | CHARMM36-ncAA PMID 34009984 (Croitoru 2021); Forcefield_NCAA (Khoury 2014) | paper2_seeds.jsonl |
| PRIOR-ART | CamSol-PTM (PMID 37978172, verified); AAindexNC (NEEDS-VERIFICATION); Brown 2026 (NEEDS-VERIFICATION) | paper2_seeds.jsonl |
| PTM-ISOASP | isoAsp/PCMT1/PIMT in long-lived proteins; NEEDS-VERIFICATION | paper2_seeds.jsonl |
| PTM-SET | deamidation/glycation/carbamylation/MetO in aging; NEEDS-VERIFICATION | paper2_seeds.jsonl |
| SCORING-GAP | Canonical tools blind to analog-like modulators (ncAA/PTM) → gap | paper2_seeds.jsonl |
| CODON-YIN-YANG | Synonymous codon silent layer; Komar 2016 PMID 27354349 | paper2_seeds.jsonl |
| PRION-CHANNEL | Prion templating = conformational transfer, NA-independent | paper2_seeds.jsonl |

---

## Open Actions for Human Editor

The following items require human judgment or data retrieval before submission:

1. **[TO-COMPUTE]** Feature importance table — extract relative importances from trained EXP-137 GBR model.
2. **[TO-COMPUTE]** Predictor-blindness demonstration numbers — canonical delta, ncAA delta, matched-null distribution, gap statistic.
3. **[NEEDS-VERIFICATION]** metapredict v3 DOI (10.1002/pro.4466) — confirm via CrossRef.
4. **[NEEDS-VERIFICATION]** AAindexNC real reference (Milchevskiy 2024) — cited PMID 39684773 is WRONG; find real identifier before citing as differentiator.
5. **[NEEDS-VERIFICATION]** Brown et al. bioRxiv 2026 — confirm exact DOI, author list, title.
6. **[NEEDS-VERIFICATION]** bAIes, AlphaFold-Metainference, AFflecto citations — confirm before positioning disorder cloud relative to them.
7. **[NEEDS-VERIFICATION]** CAID Portal citation (Del Conte et al., NAR 2023).
8. **[NEEDS-VERIFICATION]** DISPROTBENCH (arXiv 2507.02883) — confirm identifier.
9. **[NEEDS-VERIFICATION]** Primary PMIDs for MAPT/tau C322, Aβ His13/His14, APOE3 C112 metal-coordination site annotations (EXP-144 prediction targets).
10. **[NEEDS-VERIFICATION]** Primary PMIDs for aging-PTM literature: isoAsp/PCMT1/PIMT repair decline; glycation/CML/AGE accumulation; carbamylation; MetO accumulation.
11. **[NEEDS-VERIFICATION]** Savas 2012, Toyama 2018, Fornasiero 2018 — exact PMIDs for long-lived protein references.
12. **[NEEDS-VERIFICATION]** EXP_019 expanded-null gate closure criteria and status.
13. **[OPEN GATE]** CAID/DisProt clean calibration rerun (NANOG + PRNP mask bug) — no CAID accuracy claim until complete.
14. **[PATENT GATE]** No submission or public disclosure before filing/priority confirmed by operator and counsel.
15. **[LICENSE GATE]** Assess IUPred2A dependency for any non-academic distribution; metapredict v3 (MIT) is clean.
