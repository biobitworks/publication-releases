# Summary v2

## Per-Repo Records Reviewed

|root|status|files seen|content scanned|relevant hits|identifier files|
|---|---|---|---|---|---|
|shadow-seeds|deeply_reviewed|446|446|436|82|
|cellico-bio|deeply_reviewed|251|41|37|0|
|cellico|deeply_reviewed|8438|7479|4535|1953|
|tf-cellico|deeply_reviewed|150|139|139|10|
|fractal-waves|deeply_reviewed|8517|7941|7941|58|
|xenodisorder|deeply_reviewed|818|787|787|22|
|research-program|deeply_reviewed|218|188|139|19|
|mater|deeply_reviewed|6|3|3|1|
|MATER|deeply_reviewed|6|3|3|1|
|sids-proteome-validation|deeply_reviewed|929|675|315|66|
|substrata|deeply_reviewed|89|89|89|12|
|biocircuit|deeply_reviewed|77|71|71|3|
|seedgraph|deeply_reviewed|563|552|552|76|
|overwatch|deeply_reviewed|1694|1608|1608|291|
|watchtower|deeply_reviewed|238|199|141|5|
|gettingsciencedone|deeply_reviewed|694|685|569|100|
|MATER|deeply_reviewed|3246|2350|2350|216|
|CASP|deeply_reviewed|805|638|638|103|
|prothub|shallowly_scanned|4|4|4|0|
|volume:magicDATAbox|shallowly_scanned_limit_3000|3000|0|0|0|
|volume:magicTIMEbox|shallowly_scanned|1|0|0|0|

## Counts

- v1 rows: 1178
- net-new v2 candidate rows: 8652
- v2 superset rows: 9830
- proposed publication candidate count: 132 (delta from 57: 75)
- SeedGraph proofs generated: 0
- Overwatch writeback queued but not executed: 50

## Identifier Coverage In Superset

- with DOI: 2178
- with PMID: 1394
- with PMCID: 810
- without any identifier: 7198

## Net-New Classification Breakdown

|classification|count|
|---|---|
|exclude|139|
|include_background|417|
|include_main|112|
|include_methods|2474|
|lineage_only|5478|
|restricted_internal|32|

## Missing Identifier Reasons

|reason|count|
|---|---|
|no identifier surfaced from local source pool|1847|
|non-public/internal|5287|

## Recommendation

- Zenodo v1.0.2: GO_WITH_WARNINGS because it can remain a concept/staging package with explicit corpus limitations.
- bioRxiv v1.0.2: BLOCK until operator review, canonical JSON, SeedGraph proof readiness, source/citation audit, and claim audit complete.

## Exact Remaining Blockers

1. Operator review of selected references and manuscript patches.
2. Canonical JSON staging for selected publication/source packages.
3. SeedGraph `publication.atomic.json` and Merkle proof generation.
4. Targeted deep scan of mounted external-drive mirrors if they are source-of-truth.
5. No row-level restricted supplement extraction without explicit approval.
