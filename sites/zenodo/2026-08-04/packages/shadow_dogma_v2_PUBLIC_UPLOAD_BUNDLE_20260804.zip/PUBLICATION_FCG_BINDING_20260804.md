# Publication FCG Binding — Shadow Dogma v2

- Status: `PASS_WITH_NONSHIPPING_LIMITATIONS`
- Binding leaf: `sha256:0b5c646a44d77540964b93ceed700b2a9679012c0fb415b2e2a3bfc4db9df196`
- Claim ceiling: `HYPOTHESIS_AND_COMPUTATIONAL_PROXY_ONLY`
- Live KG writeback: `False`
- External upload: `False`
- New scientific claims authored: `False`

## Copied Source Assets

- `SEEDS-OF-TRUTH.md` ← `/Users/byron/projects/active/shadow-seeds/.planning/publication/260610-shadow-dogma-fast-track-goal/SEEDS-OF-TRUTH.md` sha256 `7c146a27a8776b49380f058e18b590557b023fda91f928002a199fb5f76102e3`
- `SEEDS-OF-TRUTH-VALIDATION-MATRIX.md` ← `/Users/byron/projects/active/shadow-seeds/.planning/publication/260610-shadow-dogma-fast-track-goal/SEEDS-OF-TRUTH-VALIDATION-MATRIX.md` sha256 `f5e8379658f21c4f3ecda278e463f164bfeac26dd4e3bd466dd79a50900a6b9f`
- `VERIFIED-REFERENCE-MATRIX-vA1.json` ← `/Users/byron/projects/active/shadow-seeds/.planning/publication/260610-shadow-dogma-fast-track-goal/VERIFIED-REFERENCE-MATRIX-vA1.json` sha256 `fc2ef598ab168f37d86539f675dd353bca20c92bd1986b6292bdced41baac765`
- `SEEDS_OF_TRUTH_SENTENCE_LOGIC_REPORT.json` ← `/Users/byron/projects/active/shadow-seeds/.planning/publication/260610-shadow-dogma-fast-track-goal/SENTENCE_LOGIC_REPORT.json` sha256 `4f697822c59518b40456db347d5e88fa705a3ac76907b22c022990bd18a76803`

## Limitation Handling

- `estimate-conflict-blocked-seeds`: ESTIMATE/CONFLICT/BLOCKED rows in seed docs remain non-shipping until exact source verification
- `aging-wave-age-conflict`: 40/44/60 age figure language must be schematic or corrected; not shipped as direct Lehallier/Oh support
