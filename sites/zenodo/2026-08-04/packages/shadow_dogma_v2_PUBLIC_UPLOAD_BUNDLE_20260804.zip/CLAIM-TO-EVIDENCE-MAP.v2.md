# Claim To Evidence Map v2

|id|class|claim|custody/proof|public ceiling|
|---|---|---|---|---|
|C33|STATUS_DISCLOSURE|The v2 corpus shows Shadow Dogma v1.0.1 under-reconciled local EXP/PROMPT/lab-note/result surfaces across active, legacy, mounted external, and KG/writeback-adjacent roots.|metadata_inventory_only_no_merkle|corpus coverage status; no biological validation claim|
|C34|HYPOTHESIS / INTERNAL_METHOD_WITH_NEGATIVE_RESULT_DISCLOSURE|The primary public-safe driver remains fragmentation/disorder-ratio/self-cross/higher-order cross-protein comparison; 24D remains a non-primary negative comparator.|internal_metadata_only_no_public_claim_promotion|procedural framing only; no formulas/panels/candidates|
|C35|REMEDIATION_STATUS|Additional local methods/background citations should be staged as metadata-only candidates before any manuscript promotion.|metadata_only_no_publication_atomic_json|bibliographic expansion proposal|
