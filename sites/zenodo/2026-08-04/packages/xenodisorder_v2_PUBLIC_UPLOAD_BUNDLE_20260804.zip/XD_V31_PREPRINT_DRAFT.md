# XenoDisorder: bounded PTM-aware disorder scoring with exact modified-row evidence and a standalone local software surface

Status: draft for author review.

## Abstract

XenoDisorder is a governed bioinformatics package for sequence- and PTM-aware
disorder scoring that now ships as a standalone local product surface with an
installable Python package, FASTA-first CLI workflow, local JSON API, and local
web app. The current evidence surface has expanded exact modified-row coverage
beyond the original citrullination-centered family to include anchored `pSer`,
`pThr`, and bounded `pTyr` rows, while a wider direct measured peptide packet
now separates direct disorder, ordered-condition, and binding-context evidence.
At the same time, the support matrix remains intentionally conservative: no PTM
yet satisfies both exact-row evidence and validated template-path overlap, and
protein-level matched evidence remains a blocker for wider scientific claims.
This preprint package therefore presents XenoDisorder as a bounded local
research tool and validated reanalysis surface rather than as a hosted
deployment or fully generalized protein-level predictor.

## Introduction

Many noncanonical residue and PTM disorder workflows fail at the point where
software delivery, exact sequence evidence, and claim discipline diverge. A
package may be installable but still unsupported scientifically, or it may
collect literature anchors without exposing a coherent local workflow. The
XenoDisorder project has approached this problem by freezing bounded claim
ceilings, exact-row evidence gates, and reproducible release artifacts before
widening software surfaces.

The project now reaches a useful publication boundary. First, exact PTM-first
modified-row coverage has been widened beyond the original `Cit` example family
to include exact local rows for `pSer`, `pThr`, and bounded `pTyr` contexts.
Second, a direct measured peptide packet now captures more real examples while
keeping direct disorder, ordered-condition, and binding-only evidence classes
separate. Third, the standalone package, CLI, API, and local web app surface
can now be exercised without runtime dependence on `cellico-bio`.

This manuscript is intentionally bounded. It does not claim that modified-
residue atomistic support is solved, that protein-level generalization has been
proven, or that the software already operates as a public hosted service. The
goal here is narrower: define and release a governed local software and evidence
surface that is suitable for research use, replication, and external review.

## Results

### Exact modified-row evidence now extends beyond a single PTM family

The exact modified-row packet is no longer limited to one strong `Cit` family.
The current staged exact-row surface includes anchored `Cit`, `pSer`, `pThr`,
and `pTyr` rows, with `pTyr` still constrained to binding-context only use
rather than direct disorder truth. This widens the exact evidence base while
preserving evidence-class boundaries instead of collapsing heterogeneous
measurements into one support label.

### Direct measured peptide coverage is broader but remains bounded

The direct measured peptide packet now spans more peptides and conditions than
the early narrow direct-assay surface. However, the package still treats this as
peptide-heavy evidence. Protein-level matched evidence remains a blocker for
wider generalization claims, and readiness or support views are not treated as
validation substitutes.

### The evidence-template overlap gap remains explicit

The exact-row widening does not remove the template-support gate. The current
gap map still shows that no PTM yet satisfies both exact-row evidence and a
validated template pathway at the same time. This is a deliberate strength of
the release discipline: rows are imported when anchored, but structure-aware
claims stay blocked until both evidence gates are open.

### The public software surface is now standalone and locally reproducible

XenoDisorder now exposes a coherent local software surface through an
installable package, a FASTA-first CLI, a local JSON API, and a local web app.
These surfaces share the same bounded score and evidence summaries and do not
depend on `cellico-bio` at runtime. The software surface is therefore suitable
for external review as a local research tool, but it is not a hosted
deployment.

## Methods

The publication package is grounded in the repo's existing governed artifacts.
Exact modified-row evidence is sourced from locally staged literature notes and
phase-specific extraction packets. Direct measured peptide evidence is sourced
from the widened measured packet that separates direct disorder from ordered or
binding contexts. Public software behavior is taken from the standalone package
contract, the runtime-independence check, the FASTA CLI packet, the API and web
surface packets, and the cross-surface validation artifacts.

The manuscript, supplement, reproducibility packet, release-sync packet, and
submission checklist are all generated against these already validated repo
artifacts rather than from new unvetted analyses. This keeps the publication
package coupled to actual shipped software and accepted evidence boundaries.

## Limitations

This release does not solve the main remaining science blockers. Protein-level
matched evidence remains a blocker. No PTM yet has both exact-row and validated
template-path overlap. `pTyr` exact rows remain binding-context only. The local
web app is a local web app and not a hosted deployment. The package therefore
supports bounded research and review workflows rather than broad mechanistic or
deployment claims.

## Code Availability

The codebase is maintained in the XenoDisorder repository and is packaged as
`xenodisorder` for local installation. The public software surface referenced by
this manuscript is the standalone local package, CLI, API, and local web app;
it is not a hosted deployment.

## Data Availability

The publication package points to machine-readable artifacts already staged in
the repository, including the exact modified-row packet, direct measured packet,
gap map, release packet, validation packet, and red-team remediation packet.
Unpublished corpora, raw research_hub internals, private notebook content, and
proprietary prompts are excluded from the public package.

## Competing Interests

Final competing-interest language requires author review before submission.

## Funding

Funding details require author review before submission.

## Author Contributions

Author contributions require author review before submission.

## Submission Notes

This draft is ready for author review and external submission preparation, but
manual completion is still required for author metadata, funding, competing
interests, and final repository or release URLs.
