# Package Ready Receipt — XenoDisorder v2

- Status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:5bf57afc22bee8b8474e7d6b283828a1831f089b7dda1766f0d0280b4647ab8f`
- Stats: `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/evidence/PACKAGE_CONTENT_SOURCE_STATS_20260804.json`
- Upload bucket: `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready`
- Evidence bucket: `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/evidence`
- Metadata bucket: `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/metadata`
- Boundary: private/staged only; operator controls public upload and visibility.

## Warnings

- None.
