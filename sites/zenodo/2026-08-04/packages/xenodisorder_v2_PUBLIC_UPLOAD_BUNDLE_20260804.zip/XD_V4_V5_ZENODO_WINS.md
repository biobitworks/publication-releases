# XenoDisorder v4 / v5 — Zenodo wins under governance

Date: 2026-07-22  
Status: DRAFT operator milestone brief  
Ceiling: **unchanged** — software / benchmark / representation; HYPOTHESIS_STAGE_1;  
no clinical / diagnostic / therapeutic / aging-reversal / SIDS-mechanism claims.  
Failure-oriented banking stays mandatory (powered nulls = first-class wins).

Related: `docs/publication/biorxiv/` (v3.1), gtm RESULTS_UPDATE 2026-07-16,  
Cloudmer lock + track audit (Watchtower notes 2026-07-22).

---

## Principle

Zenodo updates must be **successful enough to cite**, not successful enough to
overclaim. Governance is the product: every deposit carries claim ceiling,
negative ledger, and recomputable hashes.

```text
banked PASS  +  banked powered NULL/FAIL  →  Zenodo version
untranslated win sitting in intake only  →  not a Zenodo bump
smoke / toy / unlabeled surrogate         →  NEVER primary Results
```

**Hard demotion (2026-07-22):** `fco_cloud_3arm_smoke_metrics.json`,
`results/2d_cloud_encoder_smoke/`, and `--mode smoke` / `--smoke` runs are
`SMOKE_NEVER_PRIMARY`. Primary v4 Results cite
`fco_cloud_powered_metrics.json` (de-circularized, K=15) under
`BINARY_TRACK_SURROGATE` disclosure + CAFA6 harness/negative packet — not
smoke AUROCs. Policy:
`docs/intake/fco_cloudencoder_2026-07-16/PRIMARY_OUTPUT_POLICY.json`.
gsigmad contract: `gettingsciencedone/docs/PRIMARY_VS_SMOKE_CONTRACT.md`.

---

## Version map (package ↔ deposit ↔ story)

| Milestone | Package (suggested) | Zenodo story (allowed) | Must include |
|---|---|---|---|
| **v3.1** (existing) | `0.3.1` | Local PTM/software surface preprint package | Exact-row bounds; no protein-level overclaim |
| **v4** | `0.4.0` | **Methods / representation** deposit: cloud encoder + CAFA6 de-circularized lift + CAID3 honesty + powered negatives | RESULTS_UPDATE atoms; ICF-Fmax naming; BINARY_TRACK_SURROGATE disclosure; PI harness/utility disposition |
| **v5** | `0.5.0` | **Cloudmer continuous-TSC** deposit: Metapredict-v3 tracks + fail-closed CloudRows + sealed panel smoke + Anticube *schema* (not science SS) | Continuous track table (new sha); no sequence-aware claim on binary surrogate; MDEC as discussion only |

Do **not** call the next deposit “preprint v2.” Prefer **v4 methods** / **v5 Cloudmer-TSC**.

---

## v4 — “successful enough” gate (Zenodo)

All required:

1. **Translate stranded wins** from magicstudio intake into `docs/publication/` manuscript spine (Lane B), with powered negatives co-equal to CAFA6 lift.  
2. **Metric hygiene:** no bare `wFmax`; use ICF-Fmax / class-balanced Fmax.  
3. **Track honesty:** label `eaf1ad10` as `BINARY_TRACK_SURROGATE` (audit receipt already exists); forbid continuous-TSC marketing on it.  
4. **CAFA6 disposition:** operator/PI sign `ADMIT_HARNESS_ONLY` and/or bankable utility under HYPOTHESIS_STAGE_1 — not “beats Metapredict on CAID3.”  
5. **Release sync:** version strings aligned (end `0.3.0` vs `0.3.1` mismatch); CITATION.cff or Zenodo metadata template filled.  
6. **Negative ledger** shipped in supplement (directional grid null; physics equivalence; gibbsfold abstain).  
7. **Tag + Zenodo:** GitHub tag `v0.4.0` (or agreed) → Zenodo version; DOI in CITATION.

**Explicit non-goals for v4:** Fragmentum Cloudmer census, Anticube science admit, wet, aging waves, MDEC proven.

### v4 work packages (keep gov)

| WP | Repo | Outcome |
|---|---|---|
| WP4.1 Manuscript fold | xenodisorder `docs/publication/` | Lane B draft + supplement negatives |
| WP4.2 Gap close T4-04/05-label/08 | xenodisorder | Naming + surrogate label + PI sign |
| WP4.3 Release packet | xenodisorder | version bump, CITATION, preprint-surface-check green |
| WP4.4 Zenodo | operator | new version DOI; no claim-ceiling edit |

---

## v5 — “successful enough” gate (Zenodo)

All required:

1. **P1 continuous tracks:** Metapredict-v3 per-residue regen → **new** table sha (parallel to `eaf1ad10`).  
2. **Fail-closed CloudRows:** `len==source_k`; continuous required unless `allow_binary_surrogate`.  
3. **Sealed Cloudmer panel** smoke receipt (CPU ok) with backbone hashes.  
4. **Anticube leaf schema** draft in FCO (BILN ‖ oracle ‖ context ‖ width-band) — schema-only.  
5. **Decline empty ESM2 stub** in writing (GAP-T4-06).  
6. Optional outlook: Cloudmer/c-mer/MDEC naming (Watchtower lock) in Discussion — not Results.  
7. Zenodo `v0.5.0` with same ceiling + negatives appendix update.

**Still forbidden at v5:** aging-reversal, clinical, Fragmentum full-universe rescoring, wet without Anticube SS.

---

## Governance that does **not** get relaxed

- Claim ceiling text on every Zenodo landing page / CITATION  
- Powered nulls remain wins  
- Approved variance on canon via FCO decision-bands + MMR append (no silent rewrite)  
- No Overwatch writeback required for Zenodo software deposit  

## Slight relax (plumbing only)

- Translate banked intake → manuscript without waiting for perfect Daytona K≥15  
- Pointer-only math-audit panels for fractal-waves later (not a v4 blocker)  
- Surrogate-labeled smoke allowed if disclosed  

---

## Success metric

| | Fail | Win |
|---|---|---|
| Zenodo | Another private draft with no DOI bump | Public version DOI citing **lift + nulls** under ceiling |
| Governance | Dropped negatives to look better | Negatives in supplement; ceiling unchanged |
| Drift | Agents rename CDC/CloudCode | Cloudmer/c-mer/TSC lock respected |

---

## Resume

1. Operator approve this brief → freeze as `XD_V4_V5_ZENODO_WINS.md` in-repo.  
2. Execute WP4.1–4.3 in xenodisorder.  
3. Operator Zenodo for v4.  
4. Only then Metapredict regen for v5.

Ceiling reminder: **wins under governance, not instead of it.**
