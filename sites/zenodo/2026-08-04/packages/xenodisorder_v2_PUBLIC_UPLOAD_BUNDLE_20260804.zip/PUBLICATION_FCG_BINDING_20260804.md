# Publication FCG Binding — XenoDisorder v2

- Status: `PASS_WITH_NONSHIPPING_LIMITATIONS`
- Binding leaf: `sha256:6ad3d6d0721119f240766c95ed693e2608b5ca641463fd0fb7e1223f26e929f2`
- Claim ceiling: `COMPUTATIONAL_PROXY_ONLY`
- Live KG writeback: `False`
- External upload: `False`
- New scientific claims authored: `False`

## Copied Source Assets

- `OVERWATCH_TRACEABILITY_REFERENCE.md` ← `/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/OVERWATCH_TRACEABILITY_REFERENCE.md` sha256 `6d84795f88a61fa46e18c0a6d0b6a543ace8d5e607203c15a659251bbb71a09c`
- `ROWAN_CITATIONS.json` ← `/Users/byron/projects/active/xenodisorder/.planning/rowan/ROWAN_CITATIONS.json` sha256 `f0ac786330c6f3dcec11cd1447a5196724bac67be4a5919af29a9fc4a7ca8c57`
- `XD_V2_BLOCKER_AUDIT_20260802.json` ← `/Users/byron/projects/active/xenodisorder/.planning/quick/260802-xd-v2-rowan-package-readiness/XD_V2_BLOCKER_AUDIT_20260802.json` sha256 `abeb2bc2622fd01b240f59a339238603786950e3f7b0ae7980f17b4805972190`
- `XD_V2_ROWAN_REMEDIATION_DELTA_20260802.json` ← `/Users/byron/projects/active/xenodisorder/.planning/quick/260802-xd-v2-rowan-package-readiness/XD_V2_ROWAN_REMEDIATION_DELTA_20260802.json` sha256 `9b2ef5b7595d479f93a229195ea4a35bc4982d2b0cf0e5c2c0f730995c65c637`
- `MAGICBLACKBOX_BOLTZ_CLOUDMER_BACKUP_RECEIPT.json` ← `/Users/byron/projects/active/xenodisorder/.planning/quick/260802-xd-v2-rowan-package-readiness/XD_V2_CLOUDMER_EXAMPLE_PACKAGE_HOLD_20260802/evidence/MAGICBLACKBOX_BOLTZ_CLOUDMER_BACKUP_RECEIPT.json` sha256 `559c3a4526a796d24115f74c195cd7d210790b818cb298642efe81df04ee8420`
- `cloudmer_boltz_continuous_VALIDATION_20260802.json` ← `/Users/byron/projects/active/xenodisorder/.planning/quick/260802-xd-v2-rowan-package-readiness/XD_V2_CLOUDMER_EXAMPLE_PACKAGE_HOLD_20260802/evidence/cloudmer_boltz_continuous_VALIDATION_20260802.json` sha256 `ca51e6aa28f1cfe6477b819267e4a27e8faa9164f0b6a95daa4b9bc10359a830`
- `cloudmer_unified_daisy_VALIDATION.json` ← `/Users/byron/projects/active/xenodisorder/.planning/quick/260802-xd-v2-rowan-package-readiness/XD_V2_CLOUDMER_EXAMPLE_PACKAGE_HOLD_20260802/evidence/cloudmer_unified_daisy_VALIDATION.json` sha256 `21419e5fc3fd9154e9ac68a121127d5d44cb6dd8ece26dd27fc0f58d501ff2fc`

## Limitation Handling

- `rowan-known-missing`: known missing/unresolved Rowan rows are listed as remediation, not hidden support
- `boltz-new-runs`: no new Boltz paid runs; package uses copied receipts/status only
