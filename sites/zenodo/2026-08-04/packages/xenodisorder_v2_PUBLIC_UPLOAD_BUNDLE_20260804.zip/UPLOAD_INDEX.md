# Upload Index

- Package: `xenodisorder_v2`
- Generated: `2026-08-04T03:13:51+00:00`
- Claim scope: partial/example coverage approved; no generated Rowan descriptors or new Boltz outputs
- Do not upload any `do_not_upload/` content.
- Claim promotion is limited to publication-version framing; forbidden scientific/capability claims remain blocked.

## Files

- `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready/XD_V31_PREPRINT_DRAFT.md`
- `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready/XD_V31_CITATION_METADATA.md`
- `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready/XD_V4_V5_ZENODO_WINS.md`
- `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready/PACKAGE_CONTENT_SOURCE_STATS_20260804.md`
- `/Users/byron/projects/active/xenodisorder/outbox/260802-xd-v2-cloudmer-example-hold/upload_when_ready/PACKAGE_READY_RECEIPT_20260804.md`
