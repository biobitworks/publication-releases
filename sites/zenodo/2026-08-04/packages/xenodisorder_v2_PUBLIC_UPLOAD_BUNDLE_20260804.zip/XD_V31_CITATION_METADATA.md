# XenoDisorder v3.1 Citation Metadata Template

Use this as the author-reviewed source for a future `CITATION.cff` or software
release citation.

- Software title: `XenoDisorder`
- Cited version for the preprint package: `0.3.1`
- Repository artifact: Git tag `v3.0`
- Preprint companion milestone: `v3.1 bioRxiv Submission Prep and Release Sync`
- Manual fields still required:
  - author list
  - affiliations
  - ORCID identifiers
  - public repository URL
  - preferred citation string
