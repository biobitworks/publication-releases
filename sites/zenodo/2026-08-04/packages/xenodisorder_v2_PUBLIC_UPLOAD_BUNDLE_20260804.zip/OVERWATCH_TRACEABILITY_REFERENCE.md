# XenoDisorder bioRxiv Reference: Overwatch Seed-To-Publication Traceability

## Purpose

This reference ties the XenoDisorder `v3.1` bioRxiv-prep package to the active
Overwatch seed-to-document traceability workflow so the route from source seed
to preprint packet is explicit and reviewable.

The governing Overwatch sources are:

- [TRACEABLE_SEED_TO_DOCUMENT_FACTORY_PROTOCOL_2026-03-22.md](/Users/byron/projects/active/overwatch/docs/governance/TRACEABLE_SEED_TO_DOCUMENT_FACTORY_PROTOCOL_2026-03-22.md)
- [HUMAN_REPLICABLE_SEED_TO_DOCUMENT_RUNBOOK_2026-03-22.md](/Users/byron/projects/active/overwatch/docs/governance/HUMAN_REPLICABLE_SEED_TO_DOCUMENT_RUNBOOK_2026-03-22.md)
- [EXP_066_SINGLE_PAPER_TRACEABILITY_WORKFLOW.md](/Users/byron/projects/active/overwatch/experiments/EXP_066_SINGLE_PAPER_TRACEABILITY_WORKFLOW.md)
- [KB_HOWTO_OVERWATCH_MCP_DATABASE_2026-03-07.md](/Users/byron/projects/active/overwatch/docs/governance/KB_HOWTO_OVERWATCH_MCP_DATABASE_2026-03-07.md)

## Canonical Overwatch Path

Overwatch defines the canonical path as:

`seed -> deterministic extraction -> normalization -> map generation -> compilation -> validation -> promotion`

For XenoDisorder publication prep, that path should be interpreted as follows.

## XenoDisorder Seed Types

### Publication Seeds

- DOI or PMID-backed papers staged in `research_hub`
- local curated notes in `/Users/byron/projects/research_hub/literature/curated/`
- local paper directories in `/Users/byron/projects/research_hub/literature/papers/`

### Experiment Seeds

- machine-readable benchmark and release packets in
  [benchmarks/results](/Users/byron/projects/active/xenodisorder/benchmarks/results)
- dataset packets in
  [benchmarks/datasets](/Users/byron/projects/active/xenodisorder/benchmarks/datasets)
- traceability notes in
  [docs/traceability](/Users/byron/projects/active/xenodisorder/docs/traceability)

### Product Surface Seeds

- package metadata in [pyproject.toml](/Users/byron/projects/active/xenodisorder/pyproject.toml)
- public quickstart in [README.md](/Users/byron/projects/active/xenodisorder/README.md)
- local web-app and API surface in [standalone_server.py](/Users/byron/projects/active/xenodisorder/src/xenodisorder/standalone_server.py)

## Stage Mapping

### 1. Seed Capture

Overwatch requirement:
- every source gets one stable seed identity and immutable raw pointer

XenoDisorder implementation:
- publication seeds are first captured in `research_hub`, not directly in the
  manuscript
- experiment/product seeds are the versioned repo artifacts already emitted by
  milestone phases

Current anchor examples:
- [XD_PHASE132_PTM_EXACT_ROW_EXPANSION.md](/Users/byron/projects/active/xenodisorder/docs/traceability/XD_PHASE132_PTM_EXACT_ROW_EXPANSION.md)
- [XD_PHASE133_DIRECT_MEASURED_PEPTIDE_PACKET.md](/Users/byron/projects/active/xenodisorder/docs/traceability/XD_PHASE133_DIRECT_MEASURED_PEPTIDE_PACKET.md)
- [XD_PHASE145_VALIDATION_AND_REDTEAM.md](/Users/byron/projects/active/xenodisorder/docs/traceability/XD_PHASE145_VALIDATION_AND_REDTEAM.md)

### 2. Deterministic Extraction

Overwatch requirement:
- deterministic extraction before AI enrichment
- preserve text, offsets, figures, citations, and run manifests

XenoDisorder interpretation:
- for paper-backed claims, use `research_hub` plus the Overwatch single-paper
  workflow rather than freehand manuscript prose
- the reusable reference run is
  [EXP_066_SINGLE_PAPER_TRACEABILITY_WORKFLOW.md](/Users/byron/projects/active/overwatch/experiments/EXP_066_SINGLE_PAPER_TRACEABILITY_WORKFLOW.md)

Expected publication-seed outputs:
- extracted text
- sentence index
- figure inventory
- citation inventory
- claim-evidence map
- red-team and remediation artifacts

### 3. Normalization

Overwatch requirement:
- convert extracted artifacts into reviewable objects and preserve source
  anchors

XenoDisorder interpretation:
- claims in the manuscript must map back to either:
  - a traced publication seed in `research_hub` / Overwatch
  - a versioned XenoDisorder result packet
- unanchored claims remain `HYPOTHESIS` and do not belong in the preprint’s
  main results framing

### 4. Map Generation

Overwatch requirement:
- generate sentence maps, logic maps, claim-evidence maps, and
  requirement-response maps where applicable

XenoDisorder implementation:
- the manuscript-facing map is the supplement crosswalk in
  [XD_V31_SUPPLEMENT.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_SUPPLEMENT.md)
- the publication contract is
  [xenodisorder_phase147_biorxiv_contract_v1.json](/Users/byron/projects/active/xenodisorder/benchmarks/contracts/xenodisorder_phase147_biorxiv_contract_v1.json)

Recommended extension before external submission:
- keep one per-paper Overwatch traceability pack for each paper used as a
  primary manuscript anchor

### 5. Compilation

Overwatch requirement:
- assemble a target-facing packet without breaking provenance

XenoDisorder compilation packet:
- manuscript:
  [XD_V31_PREPRINT_DRAFT.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_PREPRINT_DRAFT.md)
- supplement:
  [XD_V31_SUPPLEMENT.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_SUPPLEMENT.md)
- figure/table plan:
  [XD_V31_FIGURE_TABLE_PLAN.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_FIGURE_TABLE_PLAN.md)
- release sync:
  [XD_V31_RELEASE_SYNC.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_RELEASE_SYNC.md)
- submission checklist:
  [XD_V31_SUBMISSION_CHECKLIST.md](/Users/byron/projects/active/xenodisorder/docs/publication/biorxiv/XD_V31_SUBMISSION_CHECKLIST.md)

### 6. Validation

Overwatch requirement:
- every compiled claim traces to a seed and anchor
- every packet states what is not yet proven
- IP-sensitive or external packets face review

XenoDisorder validation surface:
- [xenodisorder_phase153_validation_v1.json](/Users/byron/projects/active/xenodisorder/benchmarks/results/xenodisorder_phase153_validation_v1.json)
- [xenodisorder_phase154_redteam_v1.json](/Users/byron/projects/active/xenodisorder/benchmarks/results/xenodisorder_phase154_redteam_v1.json)
- [xenodisorder_phase155_governance_closeout_v1.json](/Users/byron/projects/active/xenodisorder/benchmarks/results/xenodisorder_phase155_governance_closeout_v1.json)

### 7. Promotion

Overwatch requirement:
- promote only after validation

XenoDisorder current boundary:
- `v3.1` is ready for author review and manual submission steps
- actual bioRxiv submission is still manual
- actual PyPI publication is still manual
- public hosted deployment is not implied and is still out of scope

## Seed-To-Publication Checklist

For every primary manuscript claim:

1. Identify the seed class.
2. Confirm the raw source exists in `research_hub` or as a versioned repo artifact.
3. Confirm deterministic extraction or a governed result packet exists.
4. Confirm the claim is represented in a crosswalk or traceability note.
5. Confirm the manuscript language does not outrun the evidence class.
6. Confirm the claim survives red-team review without unresolved leakage or overclaiming.

## Current Gaps

- The `v3.1` supplement crosswalk is good at the packet level, but it is not a
  full sentence-level Overwatch traceability export.
- Primary publication anchors used in the manuscript are not yet bundled into a
  dedicated XenoDisorder-side per-paper traceability register.
- Actual Overwatch MCP writeback or KB promotion has not been executed from
  this repo.

## Practical Rule

If a statement in the preprint cannot be traced back to:

- a local `research_hub` paper plus Overwatch-compatible extraction path, or
- a versioned XenoDisorder artifact plus traceability note,

then it should be removed, downgraded, or explicitly labeled as a hypothesis.
