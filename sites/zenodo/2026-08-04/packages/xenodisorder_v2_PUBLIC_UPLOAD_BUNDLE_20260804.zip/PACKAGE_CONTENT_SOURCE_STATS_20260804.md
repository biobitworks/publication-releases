# Package Content Source Stats — XenoDisorder v2

- Generated: `2026-08-04T02:53:19+00:00`
- Package status: `PACKAGE_READY_PRIVATE_STAGED`
- Package leaf: `sha256:5bf57afc22bee8b8474e7d6b283828a1831f089b7dda1766f0d0280b4647ab8f`
- Files analyzed: `892`
- Nonblank lines: `122542`
- Knowledge-atom lines: `8572` (7.00%)
- Seed-of-truth lines: `23011` (18.78%)
- Frontier/inference prose lines: `90959` (74.23%)

## Deterministic Classification

- `knowledge_atom`: lexical evidence anchors such as hashes, receipts, EXP IDs, manifests, seals, PASS/FAIL/ABSTAIN rows, DOI/PMID/Zenodo/accession references.
- `seed_of_truth`: source/citation/provenance/SeedGraph/operator-decision lines that identify origin material but are not themselves the terminal atom.
- `frontier_inference`: unanchored explanatory prose, interpretation, recommendations, limitations, and Codex/assistant-authored synthesis.

## Deposit Boundary

- Local package is ready for operator review as a private/staged package.
- No public upload, live KG writeback, claim promotion, or visibility switch was performed by this script.

## Highest-Inference Files

| File | Nonblank | Atom | Seed | Inference |
|---|---:|---:|---:|---:|
| `.planning/boltz/prnp_c_vs_p/het_prnp_tpe/scorer_ablation_030_index.jsonl` | 4398 | 0 | 0 | 4398 |
| `.planning/boltz/waltz_prion_fxf/batches/A1_cohort_monomers.jsonl` | 831 | 0 | 0 | 831 |
| `.planning/boltz/shared_cloudmer_boltz_loop_ledger.jsonl` | 420 | 0 | 0 | 420 |
| `.planning/boltz/prnp_c_vs_p/het_prnp_tpe/scorer_ablation_030/FR_DELTA_RANKING.jsonl` | 400 | 0 | 0 | 400 |
| `.planning/boltz/prnp_c_vs_p/w0_scoreboard_20260726/HARVEST_CENSUS_STUDIO.json` | 383 | 0 | 0 | 383 |
| `.planning/boltz/burn_935_jul31/download_done_job_ids.txt` | 375 | 0 | 0 | 375 |
| `.planning/boltz/pipelines/prot_scr_TsYTWa9yhKPdSCGCpfZS.SUMMARY.json` | 300 | 0 | 0 | 300 |
| `.planning/boltz/waltz_prion_fxf/batches/B1_self_pairs.jsonl` | 300 | 0 | 0 | 300 |
| `.planning/boltz/waltz_prion_fxf/batches/B2_same_parent_amyxamy.jsonl` | 300 | 0 | 0 | 300 |
| `.planning/boltz/waltz_prion_fxf/batches/C1_self_x_self.jsonl` | 300 | 0 | 0 | 300 |
| `.planning/boltz/waltz_prion_fxf/batches/C2_prionlike_allo_amyxamy.jsonl` | 300 | 0 | 0 | 300 |
| `.planning/boltz/waltz_prion_fxf/batches/C2_prnp_x_prionlike.jsonl` | 300 | 0 | 0 | 300 |
